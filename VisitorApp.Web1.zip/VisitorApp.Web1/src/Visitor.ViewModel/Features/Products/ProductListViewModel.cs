using CommunityToolkit.Mvvm.Input;
using Visitor.Model.Common;
using Visitor.Model.Features.Products.Requests;
using Visitor.Model.Features.Products.Responses;
using Visitor.Model.Services.Dispatcher;
using Visitor.ViewModel.Common;
using Visitor.ViewModel.Common.Services;

namespace Visitor.ViewModel.Features.Products;

/// <summary>
/// ViewModel لیست محصولات
/// </summary>
public sealed partial class ProductListViewModel : PaginatedViewModelBase<ProductDto, GetPaginatedProductsRequest, ProductFilter>
{
    public ProductListViewModel(
        IApiDispatcher dispatcher,
        INavigator navigator,
        IToastService toast,
        IApiLogger logger,
        IApiResultPolicy resultPolicy)
        : base(dispatcher, navigator, toast, logger, resultPolicy)
    {
        PageSize = 20;
    }
    
    protected override GetPaginatedProductsRequest CreateRequest()
    {
        return new GetPaginatedProductsRequest();
    }
    
    [RelayCommand]
    private void CreateProduct()
    {
        NavigateToAsync("/products/create");
    }
    
    [RelayCommand]
    private void EditProduct(Guid productId)
    {
        NavigateToAsync($"/products/edit/{productId}");
    }
    
    [RelayCommand]
    private async Task DeleteProductAsync(Guid productId)
    {
        await RunBusyAsync(async () =>
        {
            var request = new DeleteProductRequest { ProductId = productId };
            var result = await SendAsync<DeleteProductRequest, bool>(request);
            
            if (result.IsSuccess)
            {
                NotifySuccess("محصول با موفقیت حذف شد");
                await RefreshAsync();
            }
            else if (result.IsFailure)
            {
                await ResultPolicy.HandleErrorAsync(result.Error!);
            }
        });
    }
    
    [RelayCommand]
    private void ViewProduct(Guid productId)
    {
        NavigateToAsync($"/products/{productId}");
    }
} 