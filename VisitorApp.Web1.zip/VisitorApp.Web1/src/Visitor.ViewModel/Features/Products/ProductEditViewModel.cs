using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Visitor.Model.Features.Products.Requests;
using Visitor.Model.Features.Products.Responses;
using Visitor.Model.Services.Dispatcher;
using Visitor.Model.Services.Uploads;
using Visitor.ViewModel.Common;
using Visitor.ViewModel.Common.Services;

namespace Visitor.ViewModel.Features.Products;

/// <summary>
/// ViewModel ویرایش/ساخت محصول
/// </summary>
public sealed partial class ProductEditViewModel : ViewModelBase
{
    [ObservableProperty]
    private Guid? _productId;
    
    [ObservableProperty]
    private string _name = string.Empty;
    
    [ObservableProperty]
    private string? _description;
    
    [ObservableProperty]
    private decimal _price;
    
    [ObservableProperty]
    private int _stock;
    
    [ObservableProperty]
    private string? _category;
    
    [ObservableProperty]
    private bool _isActive = true;
    
    [ObservableProperty]
    private string? _imageUrl;
    
    [ObservableProperty]
    private IUploadFile? _imageFile;
    
    [ObservableProperty]
    private Dictionary<string, string> _validationErrors = new();
    
    public bool IsEditMode => ProductId.HasValue;
    public string Title => IsEditMode ? "ویرایش محصول" : "محصول جدید";
    
    public ProductEditViewModel(
        IApiDispatcher dispatcher,
        INavigator navigator,
        IToastService toast,
        IApiLogger logger,
        IApiResultPolicy resultPolicy)
        : base(dispatcher, navigator, toast, logger, resultPolicy)
    {
    }
    
    /// <summary>
    /// بارگذاری اطلاعات محصول برای ویرایش
    /// </summary>
    public async Task LoadProductAsync(Guid productId)
    {
        await RunBusyAsync(async () =>
        {
            var request = new GetProductByIdRequest { ProductId = productId };
            var product = await TryRequestAsync<GetProductByIdRequest, ProductDto>(request);
            
            if (product != null)
            {
                ProductId = product.Id;
                Name = product.Name;
                Description = product.Description;
                Price = product.Price;
                Stock = product.Stock;
                Category = product.Category;
                IsActive = product.IsActive;
                ImageUrl = product.ImageUrl;
                
                OnPropertyChanged(nameof(IsEditMode));
                OnPropertyChanged(nameof(Title));
            }
        });
    }
    
    /// <summary>
    /// ذخیره محصول (ساخت یا ویرایش)
    /// </summary>
    [RelayCommand]
    private async Task SaveAsync()
    {
        ValidationErrors.Clear();
        
        // اعتبارسنجی ساده
        if (string.IsNullOrWhiteSpace(Name))
        {
            ValidationErrors["Name"] = "نام محصول الزامی است";
            return;
        }
        
        if (Price <= 0)
        {
            ValidationErrors["Price"] = "قیمت باید بیشتر از صفر باشد";
            return;
        }
        
        await RunBusyAsync(async () =>
        {
            if (IsEditMode)
            {
                await UpdateProductAsync();
            }
            else
            {
                await CreateProductAsync();
            }
        });
    }
    
    private async Task CreateProductAsync()
    {
        var request = new CreateProductRequest
        {
            Name = Name,
            Description = Description,
            Price = Price,
            Stock = Stock,
            Category = Category,
            IsActive = IsActive,
            ImageFile = ImageFile
        };
        
        var result = await SendAsync<CreateProductRequest, ProductDto>(request);
        
        if (result.IsSuccess)
        {
            NotifySuccess("محصول با موفقیت ایجاد شد");
            NavigateToAsync("/products", replace: true);
        }
        else if (result.IsFailure && result.Error != null)
        {
            if (result.Error.ValidationErrors != null)
            {
                ValidationErrors = ApplyValidation(result.Error.ValidationErrors);
            }
            await ResultPolicy.HandleErrorAsync(result.Error);
        }
    }
    
    private async Task UpdateProductAsync()
    {
        if (!ProductId.HasValue) return;
        
        var request = new UpdateProductRequest
        {
            ProductId = ProductId.Value,
            Name = Name,
            Description = Description,
            Price = Price,
            Stock = Stock,
            Category = Category,
            IsActive = IsActive,
            ImageFile = ImageFile
        };
        
        var result = await SendAsync<UpdateProductRequest, ProductDto>(request);
        
        if (result.IsSuccess)
        {
            NotifySuccess("محصول با موفقیت به‌روزرسانی شد");
            NavigateToAsync("/products", replace: true);
        }
        else if (result.IsFailure && result.Error != null)
        {
            if (result.Error.ValidationErrors != null)
            {
                ValidationErrors = ApplyValidation(result.Error.ValidationErrors);
            }
            await ResultPolicy.HandleErrorAsync(result.Error);
        }
    }
    
    [RelayCommand]
    private void Cancel()
    {
        NavigateToAsync("/products");
    }
} 