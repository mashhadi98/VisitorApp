using Visitor.Model.Common;

namespace Visitor.ViewModel.Common.Services;

/// <summary>
/// سیاست مدیریت نتایج API (خطاها، 401، و غیره)
/// </summary>
public interface IApiResultPolicy
{
    /// <summary>
    /// پردازش خطای API و اعمال سیاست
    /// </summary>
    /// <returns>true اگر خطا پردازش شد و نیازی به اقدام بیشتر نیست</returns>
    Task<bool> HandleErrorAsync(ApiError error, string? returnUrl = null);
} 