namespace Visitor.ViewModel.Common.Services;

/// <summary>
/// سرویس مدیریت Navigation
/// </summary>
public interface INavigator
{
    /// <summary>
    /// انتقال به مسیر مشخص
    /// </summary>
    void NavigateTo(string route, bool replace = false);
    
    /// <summary>
    /// انتقال به صفحه لاگین با returnUrl
    /// </summary>
    void GoToLogin(string? returnUrl = null);
    
    /// <summary>
    /// بازگشت به صفحه قبل
    /// </summary>
    void GoBack();
} 