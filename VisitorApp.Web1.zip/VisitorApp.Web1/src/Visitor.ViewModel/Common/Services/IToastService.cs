namespace Visitor.ViewModel.Common.Services;

/// <summary>
/// سرویس نمایش پیام‌های Toast
/// </summary>
public interface IToastService
{
    /// <summary>
    /// نمایش پیام موفقیت
    /// </summary>
    void ShowSuccess(string message);
    
    /// <summary>
    /// نمایش پیام اطلاعاتی
    /// </summary>
    void ShowInfo(string message);
    
    /// <summary>
    /// نمایش پیام خطا
    /// </summary>
    void ShowError(string message);
    
    /// <summary>
    /// نمایش پیام هشدار
    /// </summary>
    void ShowWarning(string message);
} 