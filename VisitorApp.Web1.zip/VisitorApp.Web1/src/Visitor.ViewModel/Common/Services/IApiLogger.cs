using Visitor.Model.Common;

namespace Visitor.ViewModel.Common.Services;

/// <summary>
/// سرویس لاگ خطاهای API
/// </summary>
public interface IApiLogger
{
    /// <summary>
    /// لاگ خطای API
    /// </summary>
    void LogError(ApiError error, object? request = null, string? context = null);
    
    /// <summary>
    /// لاگ اطلاعات
    /// </summary>
    void LogInfo(string message, object? data = null);
} 