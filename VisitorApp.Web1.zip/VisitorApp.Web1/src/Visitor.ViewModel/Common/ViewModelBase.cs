using CommunityToolkit.Mvvm.ComponentModel;
using Visitor.Model.Common;
using Visitor.Model.Services.Common;
using Visitor.Model.Services.Dispatcher;
using Visitor.ViewModel.Common.Services;

namespace Visitor.ViewModel.Common;

/// <summary>
/// کلاس پایه برای تمام ViewModel ها
/// </summary>
public abstract partial class ViewModelBase : ObservableObject
{
    protected readonly IApiDispatcher Dispatcher;
    protected readonly INavigator Navigator;
    protected readonly IToastService Toast;
    protected readonly IApiLogger Logger;
    protected readonly IApiResultPolicy ResultPolicy;
    
    [ObservableProperty]
    private bool _isBusy;
    
    [ObservableProperty]
    private string? _errorMessage;
    
    protected ViewModelBase(
        IApiDispatcher dispatcher,
        INavigator navigator,
        IToastService toast,
        IApiLogger logger,
        IApiResultPolicy resultPolicy)
    {
        Dispatcher = dispatcher;
        Navigator = navigator;
        Toast = toast;
        Logger = logger;
        ResultPolicy = resultPolicy;
    }
    
    /// <summary>
    /// اجرای عملیات Async با مدیریت IsBusy
    /// </summary>
    protected async Task RunBusyAsync(Func<Task> action, bool showError = true)
    {
        if (IsBusy) return;
        
        try
        {
            IsBusy = true;
            ErrorMessage = null;
            await action();
        }
        catch (Exception ex)
        {
            ErrorMessage = ex.Message;
            if (showError)
            {
                Toast.ShowError($"خطا: {ex.Message}");
            }
            Logger.LogInfo($"Exception in RunBusyAsync: {ex.Message}");
        }
        finally
        {
            IsBusy = false;
        }
    }
    
    /// <summary>
    /// اجرای عملیات Async با مدیریت IsBusy و بازگشت مقدار
    /// </summary>
    protected async Task<T?> RunBusyAsync<T>(Func<Task<T>> action, bool showError = true)
    {
        if (IsBusy) return default;
        
        try
        {
            IsBusy = true;
            ErrorMessage = null;
            return await action();
        }
        catch (Exception ex)
        {
            ErrorMessage = ex.Message;
            if (showError)
            {
                Toast.ShowError($"خطا: {ex.Message}");
            }
            Logger.LogInfo($"Exception in RunBusyAsync<T>: {ex.Message}");
            return default;
        }
        finally
        {
            IsBusy = false;
        }
    }
    
    /// <summary>
    /// ارسال درخواست به API
    /// </summary>
    protected async Task<Result<TResponse>> SendAsync<TRequest, TResponse>(
        TRequest request,
        ApiRequestContext? context = null)
        where TRequest : IRequest<TResponse>
    {
        return await Dispatcher.SendAsync<TRequest, TResponse>(request, context);
    }
    
    /// <summary>
    /// تلاش برای اجرای درخواست و مدیریت خودکار خطاها
    /// </summary>
    protected async Task<TResponse?> TryRequestAsync<TRequest, TResponse>(
        TRequest request,
        string? returnUrl = null,
        ApiRequestContext? context = null)
        where TRequest : IRequest<TResponse>
    {
        var result = await SendAsync<TRequest, TResponse>(request, context);
        
        if (result.IsSuccess)
        {
            return result.Value;
        }
        
        // مدیریت خطا از طریق Policy
        await ResultPolicy.HandleErrorAsync(result.Error!, returnUrl);
        return default;
    }
    
    /// <summary>
    /// نمایش پیام موفقیت
    /// </summary>
    protected void NotifySuccess(string message)
    {
        Toast.ShowSuccess(message);
    }
    
    /// <summary>
    /// نمایش پیام اطلاعاتی
    /// </summary>
    protected void NotifyInfo(string message)
    {
        Toast.ShowInfo(message);
    }
    
    /// <summary>
    /// نمایش پیام خطا
    /// </summary>
    protected void NotifyError(string message)
    {
        Toast.ShowError(message);
        ErrorMessage = message;
    }
    
    /// <summary>
    /// انتقال به صفحه
    /// </summary>
    protected void NavigateToAsync(string route, bool replace = false)
    {
        Navigator.NavigateTo(route, replace);
    }
    
    /// <summary>
    /// اعمال خطاهای Validation به دیکشنری
    /// </summary>
    protected Dictionary<string, string> ApplyValidation(Dictionary<string, string[]>? validationErrors)
    {
        var result = new Dictionary<string, string>();
        
        if (validationErrors == null) return result;
        
        foreach (var (field, errors) in validationErrors)
        {
            result[field] = string.Join(", ", errors);
        }
        
        return result;
    }
    
    /// <summary>
    /// Debounce برای جلوگیری از فراخوانی‌های متوالی
    /// </summary>
    private CancellationTokenSource? _debounceCts;
    protected async Task DebounceAsync(Func<Task> action, int milliseconds = 500)
    {
        _debounceCts?.Cancel();
        _debounceCts = new CancellationTokenSource();
        
        try
        {
            await Task.Delay(milliseconds, _debounceCts.Token);
            await action();
        }
        catch (TaskCanceledException)
        {
            // Debounce cancelled - این طبیعی است
        }
    }
    
    /// <summary>
    /// فراخوانی هنگام نمایش صفحه
    /// </summary>
    public virtual Task OnAppearingAsync()
    {
        return Task.CompletedTask;
    }
    
    /// <summary>
    /// فراخوانی هنگام مخفی شدن صفحه
    /// </summary>
    public virtual Task OnDisappearingAsync()
    {
        _debounceCts?.Cancel();
        return Task.CompletedTask;
    }
} 