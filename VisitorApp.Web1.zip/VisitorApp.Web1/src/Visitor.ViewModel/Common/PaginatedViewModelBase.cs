using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Visitor.Model.Common;
using Visitor.Model.Services.Dispatcher;
using Visitor.ViewModel.Common.Services;

namespace Visitor.ViewModel.Common;

/// <summary>
/// کلاس پایه برای ViewModel های صفحه‌بندی شده
/// </summary>
/// <typeparam name="TItem">نوع آیتم</typeparam>
/// <typeparam name="TRequest">نوع درخواست</typeparam>
/// <typeparam name="TFilter">نوع فیلتر</typeparam>
public abstract partial class PaginatedViewModelBase<TItem, TRequest, TFilter> : ViewModelBase
    where TRequest : IPaginatedRequest<TFilter>, IRequest<PagedResult<TItem>>
    where TFilter : class, new()
{
    [ObservableProperty]
    private List<TItem> _items = new();
    
    [ObservableProperty]
    private int _page = 1;
    
    [ObservableProperty]
    private int _pageSize = 20;
    
    [ObservableProperty]
    private int _totalCount;
    
    [ObservableProperty]
    private int _totalPages;
    
    [ObservableProperty]
    private string? _sort;
    
    [ObservableProperty]
    private TFilter _filter = new();
    
    public bool HasNextPage => Page < TotalPages;
    public bool HasPreviousPage => Page > 1;
    
    protected PaginatedViewModelBase(
        IApiDispatcher dispatcher,
        INavigator navigator,
        IToastService toast,
        IApiLogger logger,
        IApiResultPolicy resultPolicy)
        : base(dispatcher, navigator, toast, logger, resultPolicy)
    {
    }
    
    /// <summary>
    /// ساخت Request از state فعلی
    /// </summary>
    protected abstract TRequest CreateRequest();
    
    /// <summary>
    /// بارگذاری صفحه
    /// </summary>
    [RelayCommand]
    public async Task LoadPageAsync()
    {
        await RunBusyAsync(async () =>
        {
            var request = CreateRequest();
            request.Page = Page;
            request.PageSize = PageSize;
            request.Sort = Sort;
            request.Filter = Filter;
            
            var result = await SendAsync<TRequest, PagedResult<TItem>>(request);
            
            if (result.IsSuccess && result.Value != null)
            {
                Items = result.Value.Items.ToList();
                TotalCount = result.Value.TotalCount;
                TotalPages = result.Value.TotalPages;
                Page = result.Value.Page;
                
                OnPropertyChanged(nameof(HasNextPage));
                OnPropertyChanged(nameof(HasPreviousPage));
            }
            else if (result.IsFailure)
            {
                await ResultPolicy.HandleErrorAsync(result.Error!);
            }
        });
    }
    
    /// <summary>
    /// رفرش داده‌ها (بازگشت به صفحه اول)
    /// </summary>
    [RelayCommand]
    public async Task RefreshAsync()
    {
        Page = 1;
        await LoadPageAsync();
    }
    
    /// <summary>
    /// صفحه بعدی
    /// </summary>
    [RelayCommand(CanExecute = nameof(HasNextPage))]
    public async Task NextPageAsync()
    {
        if (!HasNextPage) return;
        Page++;
        await LoadPageAsync();
    }
    
    /// <summary>
    /// صفحه قبلی
    /// </summary>
    [RelayCommand(CanExecute = nameof(HasPreviousPage))]
    public async Task PreviousPageAsync()
    {
        if (!HasPreviousPage) return;
        Page--;
        await LoadPageAsync();
    }
    
    /// <summary>
    /// رفتن به صفحه مشخص
    /// </summary>
    public async Task GoToPageAsync(int page)
    {
        if (page < 1 || page > TotalPages) return;
        Page = page;
        await LoadPageAsync();
    }
    
    /// <summary>
    /// اعمال فیلتر
    /// </summary>
    [RelayCommand]
    public async Task ApplyFilterAsync()
    {
        Page = 1; // بازگشت به صفحه اول
        await LoadPageAsync();
    }
    
    /// <summary>
    /// پاک کردن فیلتر
    /// </summary>
    [RelayCommand]
    public async Task ClearFilterAsync()
    {
        Filter = new TFilter();
        Page = 1;
        await LoadPageAsync();
    }
    
    /// <summary>
    /// اعمال مرتب‌سازی
    /// </summary>
    public async Task ApplySortAsync(string sort)
    {
        Sort = sort;
        Page = 1;
        await LoadPageAsync();
    }
    
    /// <summary>
    /// تغییر اندازه صفحه
    /// </summary>
    public async Task ChangePageSizeAsync(int pageSize)
    {
        PageSize = pageSize;
        Page = 1;
        await LoadPageAsync();
    }
    
    public override async Task OnAppearingAsync()
    {
        await base.OnAppearingAsync();
        
        // بارگذاری خودکار اگر داده‌ای نداریم
        if (Items.Count == 0)
        {
            await LoadPageAsync();
        }
    }
} 