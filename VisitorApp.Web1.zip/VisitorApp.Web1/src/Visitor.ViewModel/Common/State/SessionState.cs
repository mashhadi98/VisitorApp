using CommunityToolkit.Mvvm.ComponentModel;

namespace Visitor.ViewModel.Common.State;

/// <summary>
/// وضعیت جلسه کاربری (User + Token)
/// </summary>
public sealed partial class SessionState : ObservableObject
{
    [ObservableProperty]
    private string? _token;
    
    [ObservableProperty]
    private string? _userId;
    
    [ObservableProperty]
    private string? _userName;
    
    [ObservableProperty]
    private string? _userEmail;
    
    [ObservableProperty]
    private List<string> _roles = new();
    
    public bool IsAuthenticated => !string.IsNullOrEmpty(Token);
    
    /// <summary>
    /// ورود کاربر
    /// </summary>
    public void SignIn(string token, string userId, string userName, string? userEmail = null, List<string>? roles = null)
    {
        Token = token;
        UserId = userId;
        UserName = userName;
        UserEmail = userEmail;
        Roles = roles ?? new List<string>();
        
        OnPropertyChanged(nameof(IsAuthenticated));
    }
    
    /// <summary>
    /// خروج کاربر
    /// </summary>
    public void SignOut()
    {
        Token = null;
        UserId = null;
        UserName = null;
        UserEmail = null;
        Roles = new List<string>();
        
        OnPropertyChanged(nameof(IsAuthenticated));
    }
    
    /// <summary>
    /// بررسی دسترسی کاربر به نقش
    /// </summary>
    public bool HasRole(string role)
    {
        return Roles.Contains(role, StringComparer.OrdinalIgnoreCase);
    }
} 