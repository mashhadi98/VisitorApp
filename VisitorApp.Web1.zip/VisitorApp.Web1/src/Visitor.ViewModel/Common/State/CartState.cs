using CommunityToolkit.Mvvm.ComponentModel;

namespace Visitor.ViewModel.Common.State;

/// <summary>
/// وضعیت سبد خرید (برای App)
/// </summary>
public sealed partial class CartState : ObservableObject
{
    [ObservableProperty]
    private List<CartItem> _items = new();
    
    [ObservableProperty]
    private decimal _totalPrice;
    
    [ObservableProperty]
    private int _totalQuantity;
    
    public int ItemCount => Items.Count;
    
    /// <summary>
    /// اضافه کردن آیتم به سبد
    /// </summary>
    public void Add(string productId, string productName, decimal price, int quantity = 1)
    {
        var existingItem = Items.FirstOrDefault(x => x.ProductId == productId);
        
        if (existingItem != null)
        {
            existingItem.Quantity += quantity;
        }
        else
        {
            Items.Add(new CartItem
            {
                ProductId = productId,
                ProductName = productName,
                Price = price,
                Quantity = quantity
            });
        }
        
        ComputeTotals();
        OnPropertyChanged(nameof(ItemCount));
    }
    
    /// <summary>
    /// حذف آیتم از سبد
    /// </summary>
    public void Remove(string productId)
    {
        var item = Items.FirstOrDefault(x => x.ProductId == productId);
        if (item != null)
        {
            Items.Remove(item);
            ComputeTotals();
            OnPropertyChanged(nameof(ItemCount));
        }
    }
    
    /// <summary>
    /// به‌روزرسانی تعداد آیتم
    /// </summary>
    public void UpdateQuantity(string productId, int quantity)
    {
        var item = Items.FirstOrDefault(x => x.ProductId == productId);
        if (item != null)
        {
            if (quantity <= 0)
            {
                Remove(productId);
            }
            else
            {
                item.Quantity = quantity;
                ComputeTotals();
            }
        }
    }
    
    /// <summary>
    /// خالی کردن سبد
    /// </summary>
    public void Clear()
    {
        Items.Clear();
        ComputeTotals();
        OnPropertyChanged(nameof(ItemCount));
    }
    
    /// <summary>
    /// محاسبه مجموع
    /// </summary>
    private void ComputeTotals()
    {
        TotalPrice = Items.Sum(x => x.Price * x.Quantity);
        TotalQuantity = Items.Sum(x => x.Quantity);
    }
}

/// <summary>
/// آیتم سبد خرید
/// </summary>
public sealed partial class CartItem : ObservableObject
{
    [ObservableProperty]
    private string _productId = string.Empty;
    
    [ObservableProperty]
    private string _productName = string.Empty;
    
    [ObservableProperty]
    private decimal _price;
    
    [ObservableProperty]
    private int _quantity;
    
    public decimal Subtotal => Price * Quantity;
} 