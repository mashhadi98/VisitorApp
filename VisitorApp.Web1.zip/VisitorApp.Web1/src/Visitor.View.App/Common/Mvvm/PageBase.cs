using Microsoft.AspNetCore.Components;
using Visitor.ViewModel.Common;

namespace Visitor.View.App.Common.Mvvm;

/// <summary>
/// کلاس پایه برای صفحات PWA با ViewModel
/// </summary>
/// <typeparam name="TViewModel">نوع ViewModel</typeparam>
public abstract class PageBase<TViewModel> : ComponentBase, IDisposable
    where TViewModel : ViewModelBase
{
    [Parameter]
    public required TViewModel ViewModel { get; set; }
    
    protected bool IsFirstRender { get; private set; } = true;
    
    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        await base.OnAfterRenderAsync(firstRender);
        
        if (firstRender)
        {
            IsFirstRender = false;
            await ViewModel.OnAppearingAsync();
            await AfterFirstRenderAsync();
            StateHasChanged();
        }
    }
    
    protected virtual Task AfterFirstRenderAsync()
    {
        return Task.CompletedTask;
    }
    
    protected virtual void OnViewModelPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        InvokeAsync(StateHasChanged);
    }
    
    protected override void OnInitialized()
    {
        base.OnInitialized();
        
        if (ViewModel != null)
        {
            ViewModel.PropertyChanged += OnViewModelPropertyChanged;
        }
    }
    
    public virtual void Dispose()
    {
        if (ViewModel != null)
        {
            ViewModel.PropertyChanged -= OnViewModelPropertyChanged;
            _ = ViewModel.OnDisappearingAsync();
        }
    }
} 