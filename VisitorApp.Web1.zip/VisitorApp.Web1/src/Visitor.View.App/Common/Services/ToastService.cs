using Visitor.ViewModel.Common.Services;

namespace Visitor.View.App.Common.Services;

/// <summary>
/// پیاده‌سازی ToastService برای PWA
/// </summary>
public sealed class ToastService : IToastService
{
    public void ShowSuccess(string message)
    {
        Console.WriteLine($"[SUCCESS] {message}");
    }
    
    public void ShowInfo(string message)
    {
        Console.WriteLine($"[INFO] {message}");
    }
    
    public void ShowError(string message)
    {
        Console.WriteLine($"[ERROR] {message}");
    }
    
    public void ShowWarning(string message)
    {
        Console.WriteLine($"[WARNING] {message}");
    }
} 