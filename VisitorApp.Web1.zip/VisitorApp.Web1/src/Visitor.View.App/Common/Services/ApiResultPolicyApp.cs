using Visitor.Model.Common;
using Visitor.ViewModel.Common.Services;
using Visitor.ViewModel.Common.State;

namespace Visitor.View.App.Common.Services;

/// <summary>
/// سیاست مدیریت نتایج API برای App (PWA)
/// </summary>
public sealed class ApiResultPolicyApp : IApiResultPolicy
{
    private readonly SessionState _sessionState;
    private readonly INavigator _navigator;
    private readonly IToastService _toast;
    private readonly IApiLogger _logger;
    
    public ApiResultPolicyApp(
        SessionState sessionState,
        INavigator navigator,
        IToastService toast,
        IApiLogger logger)
    {
        _sessionState = sessionState;
        _navigator = navigator;
        _toast = toast;
        _logger = logger;
    }
    
    public Task<bool> HandleErrorAsync(ApiError error, string? returnUrl = null)
    {
        _logger.LogError(error, context: "ApiResultPolicy");
        
        bool result = error.Kind switch
        {
            ApiErrorKind.Unauthorized => HandleUnauthorized(returnUrl),
            ApiErrorKind.Forbidden => HandleForbidden(),
            ApiErrorKind.NotFound => HandleNotFound(error),
            ApiErrorKind.Validation => HandleValidation(error),
            ApiErrorKind.Conflict => HandleConflict(error),
            ApiErrorKind.Server => HandleServer(),
            ApiErrorKind.Network => HandleNetwork(),
            _ => HandleUnknown(error)
        };
        
        return Task.FromResult(result);
    }
    
    private bool HandleUnauthorized(string? returnUrl)
    {
        _sessionState.SignOut();
        _toast.ShowError("لطفاً مجدداً وارد شوید");
        _navigator.GoToLogin(returnUrl);
        return true;
    }
    
    private bool HandleForbidden()
    {
        _toast.ShowError("شما به این بخش دسترسی ندارید");
        return true;
    }
    
    private bool HandleNotFound(ApiError error)
    {
        _toast.ShowError(error.Message);
        return true;
    }
    
    private bool HandleValidation(ApiError error)
    {
        if (error.ValidationErrors != null && error.ValidationErrors.Any())
        {
            var firstError = error.ValidationErrors.First();
            _toast.ShowError($"{firstError.Key}: {string.Join(", ", firstError.Value)}");
        }
        else
        {
            _toast.ShowError(error.Message);
        }
        return true;
    }
    
    private bool HandleConflict(ApiError error)
    {
        _toast.ShowError(error.Message);
        return true;
    }
    
    private bool HandleServer()
    {
        _toast.ShowError("خطای سرور. لطفاً بعداً تلاش کنید");
        return true;
    }
    
    private bool HandleNetwork()
    {
        _toast.ShowError("خطای اتصال. لطفاً اتصال اینترنت خود را بررسی کنید");
        return true;
    }
    
    private bool HandleUnknown(ApiError error)
    {
        _toast.ShowError(error.Message);
        return true;
    }
} 