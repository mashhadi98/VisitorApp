using Microsoft.AspNetCore.Components;
using Visitor.ViewModel.Common.Services;

namespace Visitor.View.App.Common.Services;

/// <summary>
/// پیاده‌سازی Navigator برای Blazor PWA
/// </summary>
public sealed class Navigator : INavigator
{
    private readonly NavigationManager _navigationManager;
    
    public Navigator(NavigationManager navigationManager)
    {
        _navigationManager = navigationManager;
    }
    
    public void NavigateTo(string route, bool replace = false)
    {
        _navigationManager.NavigateTo(route, replace);
    }
    
    public void GoToLogin(string? returnUrl = null)
    {
        var route = string.IsNullOrEmpty(returnUrl) 
            ? "/login" 
            : $"/login?returnUrl={Uri.EscapeDataString(returnUrl)}";
        
        NavigateTo(route, replace: true);
    }
    
    public void GoBack()
    {
        NavigateTo("/");
    }
} 