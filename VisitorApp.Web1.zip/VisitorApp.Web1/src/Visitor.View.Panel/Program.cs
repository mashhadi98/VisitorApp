using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Visitor.Model.Common;
using Visitor.Model.Services.Common;
using Visitor.Model.Services.Dispatcher;
using Visitor.View.Panel;
using Visitor.View.Panel.Common.Services;
using Visitor.ViewModel.Common.Services;
using Visitor.ViewModel.Common.State;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// تنظیمات API
var apiOptions = new ApiOptions
{
    BaseUrl = builder.Configuration["ApiSettings:BaseUrl"] ?? "https://localhost:6070/api/",
    Version = "v1",
    DefaultTimeout = TimeSpan.FromSeconds(30)
};
builder.Services.AddSingleton(apiOptions);

// لاگ کردن BaseUrl برای اطمینان
Console.WriteLine($"API BaseUrl: {apiOptions.BaseUrl}");

// HttpClient
builder.Services.AddScoped(sp => 
{
    var http = new HttpClient { BaseAddress = new Uri(apiOptions.BaseUrl) };
    return http;
});

// Model Layer
builder.Services.AddScoped<ISessionTokenProvider, SessionTokenProvider>();
builder.Services.AddScoped<IApiClient, ApiClient>();
builder.Services.AddScoped<IApiDispatcher, ApiDispatcher>();

// ViewModel Layer - Services
builder.Services.AddScoped<INavigator, Navigator>();
builder.Services.AddScoped<IToastService, ToastService>();
builder.Services.AddScoped<IApiLogger, ApiLogger>();
builder.Services.AddScoped<IApiResultPolicy, ApiResultPolicyPanel>();

// ViewModel Layer - State
builder.Services.AddSingleton<SessionState>();
builder.Services.AddSingleton<CartState>();

// ViewModel Layer - Features
builder.Services.AddScoped<Visitor.ViewModel.Features.Products.ProductListViewModel>();
builder.Services.AddScoped<Visitor.ViewModel.Features.Products.ProductEditViewModel>();

await builder.Build().RunAsync();
