using Visitor.Model.Common;
using Visitor.ViewModel.Common.Services;

namespace Visitor.View.Panel.Common.Services;

/// <summary>
/// پیاده‌سازی ApiLogger برای لاگ خطاها
/// </summary>
public sealed class ApiLogger : IApiLogger
{
    private readonly ILogger<ApiLogger> _logger;
    
    public ApiLogger(ILogger<ApiLogger> logger)
    {
        _logger = logger;
    }
    
    public void LogError(ApiError error, object? request = null, string? context = null)
    {
        var contextInfo = !string.IsNullOrEmpty(context) ? $" [Context: {context}]" : "";
        var requestInfo = request != null ? $" [Request: {request.GetType().Name}]" : "";
        
        _logger.LogError(
            "API Error{Context}{Request}: [{Kind}] {Message} - Detail: {Detail}",
            contextInfo,
            requestInfo,
            error.Kind,
            error.Message,
            error.Detail ?? "N/A");
        
        if (error.ValidationErrors != null && error.ValidationErrors.Any())
        {
            foreach (var (field, errors) in error.ValidationErrors)
            {
                _logger.LogError("  Validation - {Field}: {Errors}", field, string.Join(", ", errors));
            }
        }
    }
    
    public void LogInfo(string message, object? data = null)
    {
        if (data != null)
        {
            _logger.LogInformation("{Message} - Data: {@Data}", message, data);
        }
        else
        {
            _logger.LogInformation("{Message}", message);
        }
    }
} 