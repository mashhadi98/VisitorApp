using Visitor.ViewModel.Common.Services;

namespace Visitor.View.Panel.Common.Services;

/// <summary>
/// پیاده‌سازی ساده ToastService (فعلاً Console - بعداً با کتابخانه UI)
/// </summary>
public sealed class ToastService : IToastService
{
    // TODO: بعداً با یک کتابخانه Toast UI جایگزین شود (مثل Blazored.Toast)
    
    public void ShowSuccess(string message)
    {
        Console.WriteLine($"[SUCCESS] {message}");
        // TODO: نمایش Toast UI
    }
    
    public void ShowInfo(string message)
    {
        Console.WriteLine($"[INFO] {message}");
        // TODO: نمایش Toast UI
    }
    
    public void ShowError(string message)
    {
        Console.WriteLine($"[ERROR] {message}");
        // TODO: نمایش Toast UI
    }
    
    public void ShowWarning(string message)
    {
        Console.WriteLine($"[WARNING] {message}");
        // TODO: نمایش Toast UI
    }
} 