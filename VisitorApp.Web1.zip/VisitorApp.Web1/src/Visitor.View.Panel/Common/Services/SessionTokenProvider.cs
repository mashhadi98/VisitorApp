using Visitor.Model.Services.Common;
using Visitor.ViewModel.Common.State;

namespace Visitor.View.Panel.Common.Services;

/// <summary>
/// ارائه‌دهنده توکن از SessionState
/// </summary>
public sealed class SessionTokenProvider : ISessionTokenProvider
{
    private readonly SessionState _sessionState;
    
    public SessionTokenProvider(SessionState sessionState)
    {
        _sessionState = sessionState;
    }
    
    public Task<string?> GetTokenAsync()
    {
        return Task.FromResult(_sessionState.Token);
    }
} 