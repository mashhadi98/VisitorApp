# Visitor.Model - لایه ارتباط با API

این لایه مسئول ارتباط با بک‌اند است و شامل:

## ساختار پوشه‌ها

```
Visitor.Model/
├── Common/                        # زیرساخت‌های مشترک
│   ├── ApiError.cs               # مدیریت خطاها
│   ├── ApiErrorKind.cs
│   ├── Result.cs                 # Result<T> pattern
│   ├── PagedResult.cs            # نتیجه صفحه‌بندی شده
│   ├── IRequest.cs               # اینترفیس پایه Request
│   ├── IPaginatedRequest.cs
│   ├── ApiOptions.cs
│   ├── StandardResponseDto.cs
│   └── ErrorDetailsDto.cs
│
├── Services/
│   ├── Common/
│   │   ├── IApiClient.cs         # wrapper روی HttpClient
│   │   ├── ApiClient.cs
│   │   ├── ApiRequestContext.cs  # Timeout, Token, Headers
│   │   └── ISessionTokenProvider.cs
│   │
│   ├── Dispatcher/
│   │   ├── IApiDispatcher.cs     # Dispatcher اصلی
│   │   ├── ApiDispatcher.cs
│   │   ├── ApiResponseMapper.cs  # StandardResponse → Result<T>
│   │   ├── RouteBuilder.cs       # جایگذاری {{param}} + snake_case
│   │   └── BodyBinder.cs         # GET→Query, POST→JSON/Multipart
│   │
│   └── Uploads/
│       ├── IUploadFile.cs
│       └── UploadFile.cs
│
├── Contracts/
│   └── Responses/
│       └── Common/
│           └── PaginatedResponseDto.cs
│
└── Features/                      # Request/Response های فیچرها
    └── Products/
        ├── Requests/
        │   ├── GetPaginatedProductsRequest.cs
        │   ├── GetProductByIdRequest.cs
        │   ├── CreateProductRequest.cs
        │   ├── UpdateProductRequest.cs
        │   ├── DeleteProductRequest.cs
        │   └── ProductFilter.cs
        └── Responses/
            └── ProductDto.cs
```

## استفاده

### ساخت یک Request

```csharp
public sealed class GetProductsRequest 
    : IPaginatedRequest<ProductFilter>, 
      IRequest<PagedResult<ProductDto>>
{
    public string Route => "/Products";
    public HttpMethod Method => HttpMethod.Get;
    
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
    public string? Sort { get; set; }
    public ProductFilter? Filter { get; set; }
}
```

### ارسال درخواست

```csharp
var dispatcher = serviceProvider.GetService<IApiDispatcher>();
var request = new GetProductsRequest { Page = 1, PageSize = 20 };

var result = await dispatcher.SendAsync<GetProductsRequest, PagedResult<ProductDto>>(request);

if (result.IsSuccess)
{
    var products = result.Value.Items;
}
else
{
    var error = result.Error; // ApiError با ValidationErrors
}
```

## ویژگی‌های کلیدی

### 1. RouteBuilder
- جایگذاری خودکار `{{param}}`
- تبدیل خودکار به snake_case
- مثال: `/Products/{{productId}}` → `/products/550e8400-...`

### 2. BodyBinder
- **GET**: Query String با `filter.*` prefix
- **POST/PUT/PATCH**: JSON یا Multipart (اگر فایل وجود دارد)

### 3. ApiResponseMapper
- نگاشت `StandardResponseDto` به `Result<T>`
- نگاشت StatusCode به `ApiErrorKind`
- پشتیبانی از `PagedResult<T>`

### 4. Result<T> Pattern
```csharp
var result = Result<Product>.Success(product, traceId, statusCode, timestamp);
var result = Result<Product>.Failure(ApiError.NotFound("یافت نشد"));
```

## نکات پیاده‌سازی

### Upload Files
```csharp
public sealed class CreateProductRequest : IRequest<ProductDto>
{
    // ... other properties
    
    [JsonIgnore]
    public IUploadFile? ImageFile { get; set; }
}
```

### Pagination
```csharp
var result = await dispatcher.SendAsync<GetProductsRequest, PagedResult<ProductDto>>(request);

Console.WriteLine($"Page {result.Value.Page} of {result.Value.TotalPages}");
Console.WriteLine($"Total: {result.Value.TotalCount}");
``` 