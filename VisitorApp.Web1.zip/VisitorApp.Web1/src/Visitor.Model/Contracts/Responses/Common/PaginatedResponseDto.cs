using System.Text.Json.Serialization;

namespace Visitor.Model.Contracts.Responses.Common;

/// <summary>
/// پاسخ صفحه‌بندی شده از سرور
/// </summary>
/// <typeparam name="T">نوع آیتم‌ها</typeparam>
public sealed class PaginatedResponseDto<T>
{
    [JsonPropertyName("list")]
    public ICollection<T> List { get; set; } = new List<T>();
    
    [JsonPropertyName("count")]
    public int Count { get; set; }
} 