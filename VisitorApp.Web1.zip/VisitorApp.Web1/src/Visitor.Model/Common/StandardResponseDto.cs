using System.Text.Json;
using System.Text.Json.Serialization;

namespace Visitor.Model.Common;

/// <summary>
/// پاسخ استاندارد سرور
/// </summary>
public sealed class StandardResponseDto
{
    [JsonPropertyName("traceId")]
    public string? TraceId { get; set; }
    
    [JsonPropertyName("statusCode")]
    public int StatusCode { get; set; }
    
    [JsonPropertyName("timestamp")]
    public DateTime Timestamp { get; set; }
    
    [JsonPropertyName("data")]
    public JsonElement? Data { get; set; }
    
    [JsonPropertyName("error")]
    public ErrorDetailsDto? Error { get; set; }
} 