namespace Visitor.Model.Common;

/// <summary>
/// تنظیمات API
/// </summary>
public sealed class ApiOptions
{
    public string BaseUrl { get; set; } = string.Empty;
    public string? Version { get; set; }
    public TimeSpan DefaultTimeout { get; set; } = TimeSpan.FromSeconds(30);
    public TimeSpan? UploadTimeout { get; set; } = TimeSpan.FromMinutes(5);
} 