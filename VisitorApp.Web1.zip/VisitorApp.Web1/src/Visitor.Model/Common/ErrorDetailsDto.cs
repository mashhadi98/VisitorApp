using System.Text.Json.Serialization;

namespace Visitor.Model.Common;

/// <summary>
/// جزئیات خطای استاندارد از سرور
/// </summary>
public sealed class ErrorDetailsDto
{
    [JsonPropertyName("message")]
    public string Message { get; set; } = string.Empty;
    
    [JsonPropertyName("detail")]
    public string? Detail { get; set; }
    
    [JsonPropertyName("validationErrors")]
    public Dictionary<string, string[]>? ValidationErrors { get; set; }
} 