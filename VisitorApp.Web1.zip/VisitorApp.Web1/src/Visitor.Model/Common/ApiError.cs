namespace Visitor.Model.Common;

/// <summary>
/// اطلاعات خطای API
/// </summary>
public sealed class ApiError
{
    public ApiErrorKind Kind { get; init; }
    public string Message { get; init; }
    public string? Detail { get; init; }
    public Dictionary<string, string[]>? ValidationErrors { get; init; }
    
    public ApiError(ApiErrorKind kind, string message, string? detail = null, Dictionary<string, string[]>? validationErrors = null)
    {
        Kind = kind;
        Message = message;
        Detail = detail;
        ValidationErrors = validationErrors;
    }
    
    public static ApiError Unauthorized(string message = "احراز هویت ناموفق") 
        => new(ApiErrorKind.Unauthorized, message);
    
    public static ApiError Forbidden(string message = "دسترسی ممنوع") 
        => new(ApiErrorKind.Forbidden, message);
    
    public static ApiError NotFound(string message = "یافت نشد") 
        => new(ApiErrorKind.NotFound, message);
    
    public static ApiError Validation(string message, Dictionary<string, string[]>? errors = null) 
        => new(ApiErrorKind.Validation, message, validationErrors: errors);
    
    public static ApiError Conflict(string message) 
        => new(ApiErrorKind.Conflict, message);
    
    public static ApiError Server(string message = "خطای سرور") 
        => new(ApiErrorKind.Server, message);
    
    public static ApiError Network(string message = "خطای شبکه") 
        => new(ApiErrorKind.Network, message);
    
    public static ApiError Unknown(string message = "خطای نامشخص") 
        => new(ApiErrorKind.Unknown, message);
} 