namespace Visitor.Model.Common;

/// <summary>
/// اینترفیس پایه برای تمام درخواست‌های API
/// </summary>
/// <typeparam name="TResponse">نوع پاسخ مورد انتظار</typeparam>
public interface IRequest<TResponse>
{
    /// <summary>
    /// مسیر API (مثلاً: /Products/{{id}})
    /// </summary>
    string Route { get; }
    
    /// <summary>
    /// متد HTTP (GET, POST, PUT, DELETE, PATCH)
    /// </summary>
    HttpMethod Method { get; }
} 