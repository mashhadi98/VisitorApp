namespace Visitor.Model.Common;

/// <summary>
/// انواع خطاهای API
/// </summary>
public enum ApiErrorKind
{
    /// <summary>
    /// خطای احراز هویت - 401
    /// </summary>
    Unauthorized,
    
    /// <summary>
    /// خطای عدم دسترسی - 403
    /// </summary>
    Forbidden,
    
    /// <summary>
    /// منبع یافت نشد - 404
    /// </summary>
    NotFound,
    
    /// <summary>
    /// خطای اعتبارسنجی - 400/422
    /// </summary>
    Validation,
    
    /// <summary>
    /// خطای تداخل - 409
    /// </summary>
    Conflict,
    
    /// <summary>
    /// خطای سرور - 5xx
    /// </summary>
    Server,
    
    /// <summary>
    /// خطای شبکه (اتصال قطع شده، timeout و غیره)
    /// </summary>
    Network,
    
    /// <summary>
    /// خطای نامشخص
    /// </summary>
    Unknown
} 