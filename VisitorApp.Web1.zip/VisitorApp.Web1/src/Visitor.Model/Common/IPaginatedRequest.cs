namespace Visitor.Model.Common;

/// <summary>
/// اینترفیس برای درخواست‌های صفحه‌بندی شده
/// </summary>
/// <typeparam name="TFilter">نوع فیلتر</typeparam>
public interface IPaginatedRequest<TFilter>
{
    int Page { get; set; }
    int PageSize { get; set; }
    string? Sort { get; set; }
    TFilter? Filter { get; set; }
} 