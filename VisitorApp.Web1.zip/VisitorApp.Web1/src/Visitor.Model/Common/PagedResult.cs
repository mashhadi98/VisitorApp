namespace Visitor.Model.Common;

/// <summary>
/// نتیجه صفحه‌بندی شده
/// </summary>
/// <typeparam name="T">نوع آیتم‌ها</typeparam>
public sealed class PagedResult<T>
{
    public IReadOnlyList<T> Items { get; }
    public int TotalCount { get; }
    public int Page { get; }
    public int PageSize { get; }
    public int TotalPages { get; }
    
    public bool HasNextPage => Page < TotalPages;
    public bool HasPreviousPage => Page > 1;
    
    public PagedResult(IEnumerable<T> items, int totalCount, int page, int pageSize)
    {
        Items = items.ToList().AsReadOnly();
        TotalCount = totalCount;
        Page = page;
        PageSize = pageSize;
        TotalPages = pageSize > 0 ? (int)Math.Ceiling(totalCount / (double)pageSize) : 0;
    }
    
    public static PagedResult<T> Empty(int page = 1, int pageSize = 20)
        => new(Enumerable.Empty<T>(), 0, page, pageSize);
} 