namespace Visitor.Model.Common;

/// <summary>
/// نتیجه یک عملیات API
/// </summary>
/// <typeparam name="T">نوع داده بازگشتی</typeparam>
public sealed class Result<T>
{
    public bool IsSuccess { get; }
    public T? Value { get; }
    public ApiError? Error { get; }
    
    // Meta information
    public string? TraceId { get; init; }
    public int? StatusCode { get; init; }
    public DateTime? Timestamp { get; init; }
    
    private Result(bool isSuccess, T? value, ApiError? error)
    {
        IsSuccess = isSuccess;
        Value = value;
        Error = error;
    }
    
    public static Result<T> Success(T value, string? traceId = null, int? statusCode = null, DateTime? timestamp = null)
        => new(true, value, null)
        {
            TraceId = traceId,
            StatusCode = statusCode,
            Timestamp = timestamp
        };
    
    public static Result<T> Failure(ApiError error, string? traceId = null, int? statusCode = null, DateTime? timestamp = null)
        => new(false, default, error)
        {
            TraceId = traceId,
            StatusCode = statusCode,
            Timestamp = timestamp
        };
    
    public bool IsFailure => !IsSuccess;
    
    /// <summary>
    /// نگاشت نتیجه به نوع دیگر
    /// </summary>
    public Result<TNew> Map<TNew>(Func<T, TNew> mapper)
    {
        if (IsSuccess && Value != null)
        {
            return Result<TNew>.Success(mapper(Value), TraceId, StatusCode, Timestamp);
        }
        
        return Result<TNew>.Failure(Error!, TraceId, StatusCode, Timestamp);
    }
} 