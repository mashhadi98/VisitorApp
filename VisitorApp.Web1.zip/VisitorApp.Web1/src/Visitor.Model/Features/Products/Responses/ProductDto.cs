using System.Text.Json.Serialization;

namespace Visitor.Model.Features.Products.Responses;

/// <summary>
/// DTO محصول
/// </summary>
public sealed class ProductDto
{
    [JsonPropertyName("id")]
    public Guid Id { get; set; }
    
    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;
    
    [JsonPropertyName("description")]
    public string? Description { get; set; }
    
    [JsonPropertyName("price")]
    public decimal Price { get; set; }
    
    [JsonPropertyName("imageUrl")]
    public string? ImageUrl { get; set; }
    
    [JsonPropertyName("stock")]
    public int Stock { get; set; }
    
    [JsonPropertyName("category")]
    public string? Category { get; set; }
    
    [JsonPropertyName("isActive")]
    public bool IsActive { get; set; }
    
    [JsonPropertyName("createDate")]
    public DateTime CreateDate { get; set; }
    
    [JsonPropertyName("updateDate")]
    public DateTime? UpdateDate { get; set; }
} 