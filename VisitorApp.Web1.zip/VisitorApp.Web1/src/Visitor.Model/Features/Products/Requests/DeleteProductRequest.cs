using System.Text.Json.Serialization;
using Visitor.Model.Common;

namespace Visitor.Model.Features.Products.Requests;

/// <summary>
/// درخواست حذف محصول
/// </summary>
public sealed class DeleteProductRequest : IRequest<bool>
{
    [JsonIgnore]
    public Guid ProductId { get; set; }
    
    public string Route => "/Products/{{productId}}";
    public HttpMethod Method => HttpMethod.Delete;
} 