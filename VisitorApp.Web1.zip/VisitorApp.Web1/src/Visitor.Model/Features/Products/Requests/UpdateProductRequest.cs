using System.Text.Json.Serialization;
using Visitor.Model.Common;
using Visitor.Model.Features.Products.Responses;
using Visitor.Model.Services.Uploads;

namespace Visitor.Model.Features.Products.Requests;

/// <summary>
/// درخواست به‌روزرسانی محصول
/// </summary>
public sealed class UpdateProductRequest : IRequest<ProductDto>
{
    [JsonIgnore]
    public Guid ProductId { get; set; }
    
    public string Route => "/Products/{{productId}}";
    public HttpMethod Method => HttpMethod.Put;
    
    [JsonPropertyName("name")]
    public string Name { get; set; } = string.Empty;
    
    [JsonPropertyName("description")]
    public string? Description { get; set; }
    
    [JsonPropertyName("price")]
    public decimal Price { get; set; }
    
    [JsonPropertyName("stock")]
    public int Stock { get; set; }
    
    [JsonPropertyName("category")]
    public string? Category { get; set; }
    
    [JsonPropertyName("isActive")]
    public bool IsActive { get; set; }
    
    [JsonIgnore]
    public IUploadFile? ImageFile { get; set; }
} 