using Visitor.Model.Common;
using Visitor.Model.Features.Products.Responses;

namespace Visitor.Model.Features.Products.Requests;

/// <summary>
/// درخواست دریافت لیست صفحه‌بندی شده محصولات
/// </summary>
public sealed class GetPaginatedProductsRequest : IPaginatedRequest<ProductFilter>, IRequest<PagedResult<ProductDto>>
{
    public string Route => "/Products";
    public HttpMethod Method => HttpMethod.Get;
    
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
    public string? Sort { get; set; }
    public ProductFilter? Filter { get; set; }
} 