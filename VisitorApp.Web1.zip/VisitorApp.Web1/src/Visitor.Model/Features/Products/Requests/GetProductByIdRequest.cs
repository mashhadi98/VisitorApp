using Visitor.Model.Common;
using Visitor.Model.Features.Products.Responses;

namespace Visitor.Model.Features.Products.Requests;

/// <summary>
/// درخواست دریافت محصول با ID
/// </summary>
public sealed class GetProductByIdRequest : IRequest<ProductDto>
{
    public Guid ProductId { get; set; }
    
    public string Route => "/Products/{{productId}}";
    public HttpMethod Method => HttpMethod.Get;
} 