using Visitor.Model.Common;
using Visitor.Model.Services.Common;

namespace Visitor.Model.Services.Dispatcher;

/// <summary>
/// Dispatcher اصلی برای ارسال درخواست‌های API
/// </summary>
public interface IApiDispatcher
{
    /// <summary>
    /// ارسال درخواست و دریافت نتیجه
    /// </summary>
    Task<Result<TResponse>> SendAsync<TRequest, TResponse>(TRequest request, ApiRequestContext? context = null)
        where TRequest : IRequest<TResponse>;
} 