using System.Net.Http.Json;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Web;
using Visitor.Model.Services.Uploads;

namespace Visitor.Model.Services.Dispatcher;

/// <summary>
/// بایند کردن بدنه درخواست به Query String یا Body
/// </summary>
public static class BodyBinder
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = false
    };
    
    /// <summary>
    /// بایند کردن Request به HttpContent
    /// </summary>
    public static HttpContent? Bind(object request, HttpMethod method, out string? queryString)
    {
        queryString = null;
        
        // GET: Query String
        if (method == HttpMethod.Get)
        {
            queryString = BuildQueryString(request);
            return null;
        }
        
        // POST/PUT/PATCH: بررسی وجود فایل
        if (method == HttpMethod.Post || method == HttpMethod.Put || method == HttpMethod.Patch)
        {
            var uploadFiles = GetUploadFiles(request);
            
            if (uploadFiles.Any())
            {
                // Multipart Form Data
                return BuildMultipartContent(request, uploadFiles);
            }
            
            // JSON
            return JsonContent.Create(request, options: JsonOptions);
        }
        
        return null;
    }
    
    private static string BuildQueryString(object request)
    {
        var queryParams = new List<string>();
        var type = request.GetType();
        var properties = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);
        
        foreach (var prop in properties)
        {
            var value = prop.GetValue(request);
            if (value == null) continue;
            
            var propName = ToCamelCase(prop.Name);
            
            // برای پراپرتی Filter، prefix اضافه می‌کنیم
            if (prop.Name.Equals("Filter", StringComparison.OrdinalIgnoreCase))
            {
                var filterParams = BuildFilterQueryParams(value);
                queryParams.AddRange(filterParams);
            }
            else
            {
                var valueString = value?.ToString() ?? string.Empty;
                queryParams.Add($"{propName}={HttpUtility.UrlEncode(valueString)}");
            }
        }
        
        return queryParams.Any() ? "?" + string.Join("&", queryParams) : string.Empty;
    }
    
    private static List<string> BuildFilterQueryParams(object filter)
    {
        var queryParams = new List<string>();
        var type = filter.GetType();
        var properties = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);
        
        foreach (var prop in properties)
        {
            var value = prop.GetValue(filter);
            if (value == null) continue;
            
            var propName = ToCamelCase(prop.Name);
            var valueString = value?.ToString() ?? string.Empty;
            queryParams.Add($"filter.{propName}={HttpUtility.UrlEncode(valueString)}");
        }
        
        return queryParams;
    }
    
    private static MultipartFormDataContent BuildMultipartContent(object request, List<IUploadFile> uploadFiles)
    {
        var content = new MultipartFormDataContent();
        
        // اضافه کردن فیلدهای ساده
        var type = request.GetType();
        var properties = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);
        
        foreach (var prop in properties)
        {
            if (typeof(IUploadFile).IsAssignableFrom(prop.PropertyType)) continue;
            
            var value = prop.GetValue(request);
            if (value == null) continue;
            
            var propName = ToCamelCase(prop.Name);
            var valueString = value?.ToString() ?? string.Empty;
            content.Add(new StringContent(valueString), propName);
        }
        
        // اضافه کردن فایل‌ها
        foreach (var file in uploadFiles)
        {
            var streamContent = new StreamContent(file.GetStream());
            streamContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(file.ContentType);
            content.Add(streamContent, "imageFile", file.FileName);
        }
        
        return content;
    }
    
    private static List<IUploadFile> GetUploadFiles(object request)
    {
        var files = new List<IUploadFile>();
        var type = request.GetType();
        var properties = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);
        
        foreach (var prop in properties)
        {
            if (typeof(IUploadFile).IsAssignableFrom(prop.PropertyType))
            {
                var value = prop.GetValue(request) as IUploadFile;
                if (value != null)
                {
                    files.Add(value);
                }
            }
        }
        
        return files;
    }
    
    private static string ToCamelCase(string input)
    {
        if (string.IsNullOrEmpty(input) || char.IsLower(input[0]))
            return input;
        
        return char.ToLowerInvariant(input[0]) + input[1..];
    }
} 