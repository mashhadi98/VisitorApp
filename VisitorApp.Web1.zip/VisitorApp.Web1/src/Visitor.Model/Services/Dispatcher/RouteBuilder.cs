using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

namespace Visitor.Model.Services.Dispatcher;

/// <summary>
/// سازنده مسیر نهایی از template و پارامترهای Request
/// </summary>
public static class RouteBuilder
{
    private static readonly Regex ParameterPattern = new(@"\{\{(\w+)\}\}", RegexOptions.Compiled);
    
    /// <summary>
    /// ساخت مسیر نهایی با جایگذاری پارامترها و snake_case کردن segments
    /// </summary>
    public static string Build(string routeTemplate, object request)
    {
        // جایگذاری پارامترها
        var result = ParameterPattern.Replace(routeTemplate, match =>
        {
            var paramName = match.Groups[1].Value;
            var value = GetPropertyValue(request, paramName);
            return value?.ToString() ?? throw new InvalidOperationException($"Parameter '{paramName}' not found or is null");
        });
        
        // snake_case کردن segments غیرپارامتری
        var segments = result.Split('/', StringSplitOptions.RemoveEmptyEntries);
        var processedSegments = new List<string>();
        
        foreach (var segment in segments)
        {
            // اگر segment حاوی کاراکترهای خاص URL (مثل ., -, یا GUID) است، تبدیل نمی‌شود
            if (IsUrlParameter(segment))
            {
                processedSegments.Add(segment);
            }
            else
            {
                processedSegments.Add(ToSnakeCase(segment));
            }
        }
        
        return "/" + string.Join("/", processedSegments);
    }
    
    private static object? GetPropertyValue(object obj, string propertyName)
    {
        var type = obj.GetType();
        var property = type.GetProperty(propertyName, BindingFlags.Public | BindingFlags.Instance | BindingFlags.IgnoreCase);
        return property?.GetValue(obj);
    }
    
    private static bool IsUrlParameter(string segment)
    {
        // اگر segment حاوی dash، GUID، number خالص، یا query string است
        return segment.Contains('-') || 
               Guid.TryParse(segment, out _) || 
               int.TryParse(segment, out _) ||
               segment.Contains('?') ||
               segment.Contains('=');
    }
    
    private static string ToSnakeCase(string input)
    {
        if (string.IsNullOrEmpty(input)) return input;
        
        var sb = new StringBuilder();
        sb.Append(char.ToLowerInvariant(input[0]));
        
        for (int i = 1; i < input.Length; i++)
        {
            char c = input[i];
            if (char.IsUpper(c))
            {
                sb.Append('_');
                sb.Append(char.ToLowerInvariant(c));
            }
            else
            {
                sb.Append(c);
            }
        }
        
        return sb.ToString();
    }
} 