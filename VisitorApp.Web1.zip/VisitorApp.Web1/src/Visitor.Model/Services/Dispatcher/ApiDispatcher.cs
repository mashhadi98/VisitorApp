using System.Text.Json;
using Visitor.Model.Common;
using Visitor.Model.Services.Common;

namespace Visitor.Model.Services.Dispatcher;

/// <summary>
/// پیاده‌سازی Dispatcher اصلی
/// </summary>
public sealed class ApiDispatcher : IApiDispatcher
{
    private readonly IApiClient _apiClient;
    
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true
    };
    
    public ApiDispatcher(IApiClient apiClient)
    {
        _apiClient = apiClient;
    }
    
    public async Task<Result<TResponse>> SendAsync<TRequest, TResponse>(TRequest request, ApiRequestContext? context = null)
        where TRequest : IRequest<TResponse>
    {
        try
        {
            // 1. ساخت مسیر نهایی
            var route = RouteBuilder.Build(request.Route, request);
            
            // 2. بایند کردن بدنه
            var content = BodyBinder.Bind(request, request.Method, out var queryString);
            
            // 3. ساخت درخواست HTTP
            var httpRequest = new HttpRequestMessage(request.Method, route + queryString)
            {
                Content = content
            };
            
            // 4. ارسال درخواست
            var httpResponse = await _apiClient.SendAsync(httpRequest, context);
            
            // 5. خواندن پاسخ
            var responseBody = await httpResponse.Content.ReadAsStringAsync();
            
            // اگر پاسخ خالی است
            if (string.IsNullOrWhiteSpace(responseBody))
            {
                if (httpResponse.IsSuccessStatusCode)
                {
                    return Result<TResponse>.Success(default!, statusCode: (int)httpResponse.StatusCode);
                }
                
                var error = ApiResponseMapper.MapToApiError((int)httpResponse.StatusCode, null);
                return Result<TResponse>.Failure(error, statusCode: (int)httpResponse.StatusCode);
            }
            
            // 6. Deserialize به StandardResponseDto
            StandardResponseDto? standardResponse;
            try
            {
                standardResponse = JsonSerializer.Deserialize<StandardResponseDto>(responseBody, JsonOptions);
            }
            catch (JsonException)
            {
                // اگر پاسخ به فرمت StandardResponse نیست
                if (httpResponse.IsSuccessStatusCode)
                {
                    // تلاش برای deserialize مستقیم به TResponse
                    try
                    {
                        var directData = JsonSerializer.Deserialize<TResponse>(responseBody, JsonOptions);
                        return Result<TResponse>.Success(directData!, statusCode: (int)httpResponse.StatusCode);
                    }
                    catch
                    {
                        var error = ApiError.Unknown("خطا در تجزیه پاسخ سرور");
                        return Result<TResponse>.Failure(error, statusCode: (int)httpResponse.StatusCode);
                    }
                }
                
                var err = ApiError.Server("پاسخ سرور نامعتبر است");
                return Result<TResponse>.Failure(err, statusCode: (int)httpResponse.StatusCode);
            }
            
            if (standardResponse == null)
            {
                var error = ApiError.Unknown("پاسخ سرور خالی است");
                return Result<TResponse>.Failure(error);
            }
            
            // 7. نگاشت به Result<TResponse>
            // بررسی اینکه آیا TResponse از نوع PagedResult<> است
            var responseType = typeof(TResponse);
            if (responseType.IsGenericType && responseType.GetGenericTypeDefinition() == typeof(PagedResult<>))
            {
                // استخراج نوع TItem از PagedResult<TItem>
                var itemType = responseType.GetGenericArguments()[0];
                
                // استخراج Page و PageSize از Request
                int page = 1, pageSize = 20;
                if (request is IPaginatedRequest<object> paginatedRequest)
                {
                    page = paginatedRequest.Page;
                    pageSize = paginatedRequest.PageSize;
                }
                
                // فراخوانی MapPaged با reflection
                var mapMethod = typeof(ApiResponseMapper)
                    .GetMethod(nameof(ApiResponseMapper.MapPaged))!
                    .MakeGenericMethod(itemType);
                
                var result = mapMethod.Invoke(null, new object[] { standardResponse, page, pageSize });
                return (Result<TResponse>)result!;
            }
            
            return ApiResponseMapper.Map<TResponse>(standardResponse);
        }
        catch (Exception ex)
        {
            // خطاهای شبکه و timeout
            return ApiResponseMapper.MapNetworkError<TResponse>(ex);
        }
    }
} 