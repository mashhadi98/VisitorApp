using System.Net;
using System.Text.Json;
using Visitor.Model.Common;
using Visitor.Model.Contracts.Responses.Common;

namespace Visitor.Model.Services.Dispatcher;

/// <summary>
/// نگاشت پاسخ سرور به Result<T>
/// </summary>
public static class ApiResponseMapper
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true
    };
    
    /// <summary>
    /// نگاشت StandardResponseDto به Result<TResponse>
    /// </summary>
    public static Result<TResponse> Map<TResponse>(StandardResponseDto standardResponse)
    {
        var statusCode = standardResponse.StatusCode;
        
        // موفقیت‌آمیز (2xx)
        if (statusCode >= 200 && statusCode < 300)
        {
            if (standardResponse.Data == null)
            {
                // اگر TResponse نوع مرجع باشد و Data نال باشد
                return Result<TResponse>.Success(default!, standardResponse.TraceId, statusCode, standardResponse.Timestamp);
            }
            
            try
            {
                var data = JsonSerializer.Deserialize<TResponse>(standardResponse.Data.Value.GetRawText(), JsonOptions);
                return Result<TResponse>.Success(data!, standardResponse.TraceId, statusCode, standardResponse.Timestamp);
            }
            catch (JsonException ex)
            {
                var error = ApiError.Unknown($"خطا در تجزیه داده: {ex.Message}");
                return Result<TResponse>.Failure(error, standardResponse.TraceId, statusCode, standardResponse.Timestamp);
            }
        }
        
        // خطا
        var apiError = MapToApiError(statusCode, standardResponse.Error);
        return Result<TResponse>.Failure(apiError, standardResponse.TraceId, statusCode, standardResponse.Timestamp);
    }
    
    /// <summary>
    /// نگاشت StatusCode و ErrorDetails به ApiError
    /// </summary>
    public static ApiError MapToApiError(int statusCode, ErrorDetailsDto? errorDetails)
    {
        var message = errorDetails?.Message ?? "خطای نامشخص";
        var detail = errorDetails?.Detail;
        var validationErrors = errorDetails?.ValidationErrors;
        
        return statusCode switch
        {
            401 => ApiError.Unauthorized(message),
            403 => ApiError.Forbidden(message),
            404 => ApiError.NotFound(message),
            400 or 422 => ApiError.Validation(message, validationErrors),
            409 => ApiError.Conflict(message),
            >= 500 and < 600 => ApiError.Server(message),
            _ => ApiError.Unknown(message)
        };
    }
    
    /// <summary>
    /// نگاشت StandardResponseDto به Result<PagedResult<TItem>> با استفاده از Page و PageSize
    /// </summary>
    public static Result<PagedResult<TItem>> MapPaged<TItem>(StandardResponseDto standardResponse, int page, int pageSize)
    {
        var statusCode = standardResponse.StatusCode;
        
        // موفقیت‌آمیز (2xx)
        if (statusCode >= 200 && statusCode < 300)
        {
            if (standardResponse.Data == null)
            {
                var emptyResult = PagedResult<TItem>.Empty(page, pageSize);
                return Result<PagedResult<TItem>>.Success(emptyResult, standardResponse.TraceId, statusCode, standardResponse.Timestamp);
            }
            
            try
            {
                // Deserialize به PaginatedResponseDto
                var paginatedDto = JsonSerializer.Deserialize<PaginatedResponseDto<TItem>>(
                    standardResponse.Data.Value.GetRawText(), JsonOptions);
                
                if (paginatedDto == null)
                {
                    var error = ApiError.Unknown("پاسخ صفحه‌بندی نامعتبر است");
                    return Result<PagedResult<TItem>>.Failure(error, standardResponse.TraceId, statusCode, standardResponse.Timestamp);
                }
                
                // نگاشت به PagedResult
                var pagedResult = new PagedResult<TItem>(paginatedDto.List, paginatedDto.Count, page, pageSize);
                return Result<PagedResult<TItem>>.Success(pagedResult, standardResponse.TraceId, statusCode, standardResponse.Timestamp);
            }
            catch (JsonException ex)
            {
                var error = ApiError.Unknown($"خطا در تجزیه داده صفحه‌بندی: {ex.Message}");
                return Result<PagedResult<TItem>>.Failure(error, standardResponse.TraceId, statusCode, standardResponse.Timestamp);
            }
        }
        
        // خطا
        var apiError = MapToApiError(statusCode, standardResponse.Error);
        return Result<PagedResult<TItem>>.Failure(apiError, standardResponse.TraceId, statusCode, standardResponse.Timestamp);
    }
    
    /// <summary>
    /// نگاشت خطای شبکه به Result
    /// </summary>
    public static Result<TResponse> MapNetworkError<TResponse>(Exception ex)
    {
        ApiError error = ex switch
        {
            TimeoutException => ApiError.Network("زمان درخواست به پایان رسید"),
            HttpRequestException => ApiError.Network($"خطای شبکه: {ex.Message}"),
            _ => ApiError.Unknown($"خطای نامشخص: {ex.Message}")
        };
        
        return Result<TResponse>.Failure(error);
    }
} 