namespace Visitor.Model.Services.Uploads;

/// <summary>
/// فایل برای آپلود
/// </summary>
public interface IUploadFile
{
    string FileName { get; }
    string ContentType { get; }
    Stream GetStream();
} 