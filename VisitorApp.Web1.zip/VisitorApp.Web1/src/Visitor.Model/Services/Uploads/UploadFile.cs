namespace Visitor.Model.Services.Uploads;

/// <summary>
/// پیاده‌سازی فایل آپلود
/// </summary>
public sealed class UploadFile : IUploadFile
{
    private readonly Func<Stream> _streamFactory;
    
    public string FileName { get; }
    public string ContentType { get; }
    
    public UploadFile(string fileName, string contentType, Func<Stream> streamFactory)
    {
        FileName = fileName;
        ContentType = contentType;
        _streamFactory = streamFactory;
    }
    
    public UploadFile(string fileName, string contentType, byte[] data)
        : this(fileName, contentType, () => new MemoryStream(data))
    {
    }
    
    public Stream GetStream() => _streamFactory();
} 