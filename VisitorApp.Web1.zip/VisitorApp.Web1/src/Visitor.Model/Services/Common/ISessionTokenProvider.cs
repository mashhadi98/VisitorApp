namespace Visitor.Model.Services.Common;

/// <summary>
/// ارائه‌دهنده توکن جلسه کاربری
/// </summary>
public interface ISessionTokenProvider
{
    /// <summary>
    /// دریافت توکن جاری کاربر
    /// </summary>
    Task<string?> GetTokenAsync();
} 