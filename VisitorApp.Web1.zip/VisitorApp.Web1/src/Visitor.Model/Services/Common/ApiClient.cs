using Visitor.Model.Common;

namespace Visitor.Model.Services.Common;

/// <summary>
/// پیاده‌سازی کلاینت API
/// </summary>
public sealed class ApiClient : IApiClient
{
    private readonly HttpClient _httpClient;
    private readonly ApiOptions _options;
    private readonly ISessionTokenProvider? _tokenProvider;
    
    public ApiClient(HttpClient httpClient, ApiOptions options, ISessionTokenProvider? tokenProvider = null)
    {
        _httpClient = httpClient;
        _options = options;
        _tokenProvider = tokenProvider;
        
        // تنظیم BaseAddress
        if (!string.IsNullOrEmpty(options.BaseUrl))
        {
            _httpClient.BaseAddress = new Uri(options.BaseUrl);
        }
        
        // تنظیم Timeout پیش‌فرض
        _httpClient.Timeout = options.DefaultTimeout;
    }
    
    public async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, ApiRequestContext? context = null)
    {
        context ??= ApiRequestContext.Default;
        
        try
        {
            // تنظیم توکن با اولویت: TokenOverride > TokenProvider
            string? token = context.BearerTokenOverride;
            if (string.IsNullOrEmpty(token) && _tokenProvider != null)
            {
                token = await _tokenProvider.GetTokenAsync();
            }
            
            if (!string.IsNullOrEmpty(token))
            {
                request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            }
            
            // اضافه کردن هدرهای اضافی
            if (context.ExtraHeaders != null)
            {
                foreach (var header in context.ExtraHeaders)
                {
                    request.Headers.TryAddWithoutValidation(header.Key, header.Value);
                }
            }
            
            // تنظیم Timeout اختصاصی
            if (context.Timeout.HasValue)
            {
                using var cts = CancellationTokenSource.CreateLinkedTokenSource(context.CancellationToken);
                cts.CancelAfter(context.Timeout.Value);
                return await _httpClient.SendAsync(request, cts.Token);
            }
            
            return await _httpClient.SendAsync(request, context.CancellationToken);
        }
        catch (HttpRequestException ex)
        {
            throw new HttpRequestException($"Network error: {ex.Message}", ex);
        }
        catch (TaskCanceledException ex)
        {
            throw new TimeoutException("Request timeout", ex);
        }
    }
} 