namespace Visitor.Model.Services.Common;

/// <summary>
/// کانتکست یک درخواست API - تنظیمات اختصاصی هر درخواست
/// </summary>
public sealed record ApiRequestContext
{
    public TimeSpan? Timeout { get; init; }
    public string? BearerTokenOverride { get; init; }
    public Dictionary<string, string>? ExtraHeaders { get; init; }
    public CancellationToken CancellationToken { get; init; } = default;
    public string? ReturnUrl { get; init; }
    
    public static ApiRequestContext Default => new();
    
    public ApiRequestContext WithTimeout(TimeSpan timeout)
        => this with { Timeout = timeout };
    
    public ApiRequestContext WithToken(string token)
        => this with { BearerTokenOverride = token };
    
    public ApiRequestContext WithCancellation(CancellationToken ct)
        => this with { CancellationToken = ct };
    
    public ApiRequestContext WithReturnUrl(string returnUrl)
        => this with { ReturnUrl = returnUrl };
} 