namespace Visitor.Model.Services.Common;

/// <summary>
/// کلاینت سطح پایین برای ارتباط با API
/// </summary>
public interface IApiClient
{
    /// <summary>
    /// ارسال درخواست HTTP و دریافت پاسخ
    /// </summary>
    Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, ApiRequestContext? context = null);
} 