# 🚀 راهنمای سریع اجرا

## پیش‌نیازها
- ✅ .NET 8 SDK نصب شده
- ✅ پروژه build شده

---

## 📦 اجرای Panel (Admin)

### روش 1: از ترمینال
```bash
cd src/Visitor.View.Panel
dotnet run
```

### روش 2: از Visual Studio
1. کلیک راست روی `Visitor.View.Panel`
2. انتخاب "Set as Startup Project"
3. F5 (یا Ctrl+F5 بدون debug)

### روش 3: از VS Code
1. باز کردن `src/Visitor.View.Panel`
2. F5 (یا Run > Start Debugging)

**URL:** `https://localhost:7xxx` یا `https://localhost:5001`

---

## 📱 اجرای App (PWA)

### روش 1: از ترمینال
```bash
cd src/Visitor.View.App
dotnet run
```

### روش 2: از Visual Studio
1. کلیک راست روی `Visitor.View.App`
2. انتخاب "Set as Startup Project"
3. F5

**URL:** `https://localhost:7xxx` یا `https://localhost:5002`

---

## 🔄 اجرای همزمان (Panel + App)

### روش 1: دو ترمینال
```bash
# ترمینال 1
cd src/Visitor.View.Panel
dotnet run

# ترمینال 2
cd src/Visitor.View.App
dotnet run
```

### روش 2: PowerShell
```powershell
# اجرای همزمان در Background
Start-Process pwsh -ArgumentList "-NoExit", "-Command", "cd src/Visitor.View.Panel; dotnet run"
Start-Process pwsh -ArgumentList "-NoExit", "-Command", "cd src/Visitor.View.App; dotnet run"
```

---

## 🛠️ Build و اجرا (از اول)

```bash
# 1. Clean
dotnet clean

# 2. Restore
dotnet restore

# 3. Build
dotnet build

# 4. Run Panel
cd src/Visitor.View.Panel
dotnet run
```

---

## 🔥 اجرا با Hot Reload

برای توسعه، استفاده از `watch` بهتر است:

```bash
cd src/Visitor.View.Panel
dotnet watch run
```

تغییرات شما به‌صورت خودکار اعمال می‌شوند!

---

## 🌐 آدرس‌ها

### Panel (Admin)
```
Local:  https://localhost:7xxx
```

### App (PWA)  
```
Local:  https://localhost:7xxx
```

### API Backend
```
https://localhost:6070/api/
```

---

## 🔍 بررسی صحت اجرا

بعد از اجرا، این چیزها را چک کنید:

### ✅ در ترمینال
```
Now listening on: https://localhost:XXXX
Application started. Press Ctrl+C to shut down.
```

### ✅ در Console (F12)
```
API BaseUrl: https://localhost:6070/api/
Blazor WebAssembly loaded successfully
```

### ✅ در مرورگر
- صفحه لود می‌شود (بدون خطای 404)
- Console خالی از خطا است
- Network Tab فایل‌های `_framework` را با 200 OK نشان می‌دهد

---

## ⚡ دستورات سریع

```bash
# Clean + Build + Run
dotnet clean && dotnet build && cd src/Visitor.View.Panel && dotnet run

# فقط Run (بدون build)
dotnet run --no-build

# Build Release
dotnet build -c Release

# Run Release
dotnet run -c Release --no-build
```

---

## 🐛 مشکل دارید؟

### خطای "Failed to load module"
```bash
# پاک کردن و اجرای مجدد
dotnet clean
Remove-Item -Recurse -Force src/*/bin, src/*/obj
dotnet build
cd src/Visitor.View.Panel
dotnet run
```

### Cache مرورگر
```
Ctrl + Shift + R  (Hard Refresh)
یا
Ctrl + Shift + Delete (Clear Cache)
```

### Certificate SSL
```bash
dotnet dev-certs https --trust
```

**📖 راهنمای کامل:** [`TROUBLESHOOTING.md`](TROUBLESHOOTING.md)

---

## 🎯 نکات مهم

1. **همیشه از داخل پوشه پروژه اجرا کنید**
   ```bash
   cd src/Visitor.View.Panel  # ✅ درست
   dotnet run
   ```

2. **نه از ریشه solution**
   ```bash
   dotnet run  # ❌ اشتباه
   ```

3. **برای توسعه از watch استفاده کنید**
   ```bash
   dotnet watch run  # Hot Reload
   ```

4. **Cache مرورگر را پاک کنید**
   - Ctrl + Shift + R

---

## 📱 نصب PWA

### Chrome/Edge
1. اجرای App
2. آیکون نصب در Address Bar
3. Install

### موبایل
1. باز کردن در Chrome/Safari
2. منوی مرورگر
3. "Add to Home Screen"

---

**🎉 آماده اجرا!**

```bash
cd src/Visitor.View.Panel
dotnet run
```

سپس مرورگر را باز کنید:
```
https://localhost:7xxx
``` 