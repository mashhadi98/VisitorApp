# VisitorSuite - سیستم مدیریت بازدیدکنندگان

یک سیستم جامع مدیریت بازدیدکنندگان با معماری **MVVM** و **Blazor WebAssembly** با رعایت کامل اصول **SOLID**.

---

## ⚡ شروع سریع

برای شروع سریع کار، از راهنمای زیر استفاده کنید:

**👉 [`QUICK-START.md`](QUICK-START.md) - راهنمای سریع شروع کار (3 دقیقه)**

یا به‌طور خلاصه:
```bash
dotnet build
cd src/Visitor.View.Panel
dotnet run
```

---

## 🏗️ معماری

این پروژه شامل 4 لایه اصلی است:

```
VisitorSuite.sln
├── src/
│   ├── Visitor.Model/             # لایه ارتباط با بک‌اند (Requests/Responses + Dispatcher + Http)
│   ├── Visitor.ViewModel/         # منطق MVVM مشترک (Base ها، State ها)
│   ├── Visitor.View.Panel/        # Blazor WASM - پنل دسکتاپ (Admin)
│   └── Visitor.View.App/          # Blazor WASM - PWA موبایل (Visitor)
└── tests/
    ├── Visitor.Model.Tests/
    └── Visitor.ViewModel.Tests/
```

### اصول طراحی

- ✅ **SOLID Principles**: تمام کدها با رعایت کامل اصول SOLID طراحی شده‌اند
- ✅ **Clean Architecture**: جداسازی کامل لایه‌ها
- ✅ **MVVM Pattern**: استفاده از `CommunityToolkit.Mvvm`
- ✅ **Feature-Based Structure**: پوشه‌بندی براساس فیچر در `Features/`
- ✅ **Common Infrastructure**: تمام زیرساخت‌ها در `Common/`

## 🎯 ویژگی‌های کلیدی

### Visitor.Model (لایه Data)
- **Dispatcher جنریک** با پشتیبانی کامل از `IRequest<TResponse>`
- **RouteBuilder** با snake_case خودکار و جایگذاری پارامترها `{{id}}`
- **BodyBinder** هوشمند: GET → Query String, POST/PUT → JSON یا Multipart
- **ApiResponseMapper** با نگاشت خودکار `StandardResponse` به `Result<T>`
- **PagedResult<T>** با محاسبه خودکار `TotalPages`
- **ApiError** با `ApiErrorKind` و پشتیبانی `ValidationErrors`
- **Upload Support** با `IUploadFile` و `UploadFile`

### Visitor.ViewModel (لایه Business Logic)
- **ViewModelBase** با:
  - `RunBusyAsync` - مدیریت خودکار `IsBusy`
  - `SendAsync` / `TryRequestAsync` - ارسال درخواست
  - `Debounce` - جلوگیری از فراخوانی‌های متوالی
  - `OnAppearing` / `OnDisappearing` - Lifecycle
  - Validation helpers
  
- **PaginatedViewModelBase<TItem, TRequest, TFilter>** با:
  - `LoadPageAsync`, `NextPageAsync`, `PreviousPageAsync`
  - `ApplyFilterAsync`, `ApplySortAsync`
  - Auto-refresh در `OnAppearing`
  
- **SessionState** - مدیریت Session و Token
- **CartState** - مدیریت سبد خرید (PWA)

### Visitor.View.Panel (پنل Admin)
- **PageBase<TViewModel>** با lifecycle management
- **Navigator** - مدیریت Navigation با `returnUrl`
- **ToastService** - نمایش پیام‌ها
- **ApiLogger** - لاگ خطاها با TraceId
- **ApiResultPolicy** با مدیریت خودکار:
  - 401 → پاک‌کردن Session + Redirect به Login
  - 403 → نمایش خطای دسترسی
  - 422 → نمایش ValidationErrors
  - 5xx → خطای سرور

### Visitor.View.App (PWA موبایل)
- تمام ویژگی‌های Panel
- **PWA Support** کامل:
  - `manifest.webmanifest`
  - `service-worker.js` با Cache Strategy
  - `offline-fallback.html`
- **Cart & Checkout** flow

## 🚀 نصب و راه‌اندازی

### پیش‌نیازها
- .NET 8 SDK
- Visual Studio 2022 یا VS Code

### مراحل نصب

```bash
# 1. Clone کردن repository
git clone <repository-url>
cd VisitorApp.Web1

# 2. Restore پکیج‌ها
dotnet restore

# 3. Build پروژه
dotnet build

# 4. اجرای Panel (Admin)
dotnet run --project src/Visitor.View.Panel

# 5. اجرای App (PWA)
dotnet run --project src/Visitor.View.App
```

## ⚙️ تنظیمات API

### آدرس API پیش‌فرض
```
https://localhost:6070/api/
```

### تغییر آدرس API
در فایل `appsettings.json` هر پروژه:

```json
{
  "ApiSettings": {
    "BaseUrl": "https://localhost:6070/api/"
  }
}
```

**📖 راهنمای کامل:** مستندات جزئی در فایل [`API-CONFIG.md`](API-CONFIG.md) موجود است.

### محیط‌های مختلف
```bash
# Development
dotnet run --environment Development

# Production
dotnet run --environment Production
```

## 📋 استفاده

### ساخت یک Feature جدید

#### 1. ایجاد Request/Response در Model

```csharp
// src/Visitor.Model/Features/YourFeature/Requests/GetItemsRequest.cs
public sealed class GetItemsRequest : IPaginatedRequest<ItemFilter>, IRequest<PagedResult<ItemDto>>
{
    public string Route => "/Items";
    public HttpMethod Method => HttpMethod.Get;
    
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
    public string? Sort { get; set; }
    public ItemFilter? Filter { get; set; }
}
```

#### 2. ایجاد ViewModel

```csharp
// src/Visitor.ViewModel/Features/YourFeature/ItemListViewModel.cs
public sealed partial class ItemListViewModel 
    : PaginatedViewModelBase<ItemDto, GetItemsRequest, ItemFilter>
{
    public ItemListViewModel(/*...*/) : base(/*...*/) { }
    
    protected override GetItemsRequest CreateRequest() => new();
}
```

#### 3. ایجاد صفحه Razor

```razor
@page "/items"
@using Visitor.View.Panel.Common.Mvvm
@inherits PageBase<ItemListViewModel>

<!-- UI شما -->
```

#### 4. ثبت در DI

```csharp
// در Program.cs
builder.Services.AddScoped<ItemListViewModel>();
```

## 🔄 Flow درخواست API

```
User Action (Razor)
    ↓
ViewModel Command
    ↓
SendAsync<TRequest, TResponse>
    ↓
ApiDispatcher
    ↓
RouteBuilder → /items → /items (snake_case)
BodyBinder → JSON/Query
    ↓
ApiClient (HttpClient + Token)
    ↓
HTTP Request → https://localhost:6070/api/...
    ↓
API Server
    ↓
StandardResponseDto
    ↓
ApiResponseMapper → Result<T>
    ↓
ApiResultPolicy (401/403/422/5xx handling)
    ↓
ViewModel State Update
    ↓
UI Update (MVVM)
```

## 📦 پکیج‌های استفاده شده

- `CommunityToolkit.Mvvm` 8.4.0
- `Microsoft.Extensions.Http` 9.0.9
- `Microsoft.AspNetCore.Components.WebAssembly` 10.0.0

## 🧪 تست‌ها

```bash
# اجرای تمام تست‌ها
dotnet test

# اجرای تست‌های یک پروژه خاص
dotnet test tests/Visitor.Model.Tests
```

## 📝 نکات مهم

### Route Template
- از `{{paramName}}` برای پارامترها استفاده کنید
- Segments به‌طور خودکار به snake_case تبدیل می‌شوند
- مثال: `/Products/{{productId}}` → `/products/550e8400-...`

### Filter در Query
- فیلترها به‌صورت `filter.<property>=value` ارسال می‌شوند
- مثال: `?page=1&pageSize=20&filter.name=test`

### File Upload
```csharp
var uploadFile = new UploadFile("image.jpg", "image/jpeg", fileBytes);
request.ImageFile = uploadFile;
```

### Validation Errors
```csharp
if (result.Error?.ValidationErrors != null)
{
    ValidationErrors = ApplyValidation(result.Error.ValidationErrors);
}
```

## 🎨 UI Components

صفحات از **Bootstrap 5** و **Bootstrap Icons** استفاده می‌کنند.

## 🔐 Authentication

- توکن در `SessionState` نگهداری می‌شود
- توکن به‌صورت خودکار به هدر `Authorization: Bearer` اضافه می‌شود
- در صورت 401، کاربر به صفحه Login هدایت می‌شود

## 📱 PWA

App به‌صورت PWA قابل نصب است:
- Offline support با Service Worker
- Caching strategy
- Add to Home Screen

## 👥 مشارکت

لطفاً از branch های feature استفاده کنید و Pull Request ایجاد کنید.

## 📄 مجوز

[مجوز پروژه]

---

**ساخته شده با ❤️ و رعایت اصول SOLID** 