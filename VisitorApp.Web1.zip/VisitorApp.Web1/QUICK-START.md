# 🚀 Quick Start - شروع سریع

این راهنما برای شروع سریع کار با پروژه VisitorSuite است.

---

## ⚡ اجرای سریع (3 دقیقه)

### گام 1: Build پروژه
```bash
dotnet build
```

### گام 2: اجرای Panel (Admin)
```bash
cd src/Visitor.View.Panel
dotnet run
```

یا با Hot Reload:
```bash
dotnet watch run
```

### گام 3: باز کردن مرورگر
بعد از اجرا، این پیام را خواهید دید:
```
Now listening on: https://localhost:XXXX
```

مرورگر را باز کنید و به آدرس بالا بروید.

---

## 🎯 چک لیست اولیه

قبل از شروع، این موارد را بررسی کنید:

- [x] ✅ .NET 8 SDK نصب شده
- [x] ✅ پروژه build شده بدون خطا
- [x] ✅ API Backend در `https://localhost:6070/api/` اجرا شده
- [ ] 🔧 Certificate SSL Trust شده: `dotnet dev-certs https --trust`

---

## 🌐 آدرس‌ها

| پروژه | آدرس | توضیحات |
|-------|------|---------|
| **API Backend** | `https://localhost:6070/api/` | بک‌اند شما |
| **Panel** | `https://localhost:7xxx` | پنل Admin |
| **App** | `https://localhost:7xxx` | PWA موبایل |

---

## 📂 ساختار پروژه

```
VisitorApp.Web1/
├── src/
│   ├── Visitor.Model/              # 🔹 API Communication Layer
│   │   ├── Common/                 # Dispatcher, Result, ApiError
│   │   ├── Services/               # ApiClient, RouteBuilder, BodyBinder
│   │   └── Features/               # Products, ...
│   │
│   ├── Visitor.ViewModel/          # 🔹 Business Logic (MVVM)
│   │   ├── Common/                 # ViewModelBase, State
│   │   └── Features/               # ProductListVM, ProductEditVM, ...
│   │
│   ├── Visitor.View.Panel/         # 🖥️ Admin Panel (Blazor WASM)
│   │   ├── Common/                 # Services, PageBase
│   │   ├── Features/               # Pages
│   │   └── wwwroot/                # Static files, appsettings.json
│   │
│   └── Visitor.View.App/           # 📱 PWA Mobile (Blazor WASM)
│       ├── Common/                 # Services, PageBase, PWA files
│       ├── Features/               # Pages
│       └── wwwroot/                # Static files, manifest, service-worker
│
├── README.md                       # 📖 مستندات کامل
├── RUN.md                          # 🚀 راهنمای اجرا
├── TROUBLESHOOTING.md              # 🔧 عیب‌یابی
├── API-CONFIG.md                   # ⚙️ تنظیمات API
└── QUICK-START.md                  # ⚡ این فایل
```

---

## 🛠️ ساخت یک Feature جدید

### مثال: ساخت Feature "Visitors"

#### 1️⃣ Model (Requests/Responses)
```bash
mkdir -p src/Visitor.Model/Features/Visitors/Requests
mkdir -p src/Visitor.Model/Features/Visitors/Responses
```

**Response DTO:**
```csharp
// src/Visitor.Model/Features/Visitors/Responses/VisitorDto.cs
namespace Visitor.Model.Features.Visitors.Responses;

public sealed class VisitorDto
{
    public Guid Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
}
```

**Request:**
```csharp
// src/Visitor.Model/Features/Visitors/Requests/GetVisitorsRequest.cs
using Visitor.Model.Common;
using Visitor.Model.Features.Visitors.Responses;

namespace Visitor.Model.Features.Visitors.Requests;

public sealed class GetVisitorsRequest : IPaginatedRequest<VisitorFilter>, IRequest<PagedResult<VisitorDto>>
{
    public string Route => "/Visitors";
    public HttpMethod Method => HttpMethod.Get;
    
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
    public string? Sort { get; set; }
    public VisitorFilter? Filter { get; set; }
}

public sealed class VisitorFilter
{
    public string? Name { get; set; }
    public string? Email { get; set; }
}
```

#### 2️⃣ ViewModel
```csharp
// src/Visitor.ViewModel/Features/Visitors/VisitorListViewModel.cs
using Visitor.Model.Common;
using Visitor.Model.Features.Visitors.Requests;
using Visitor.Model.Features.Visitors.Responses;
using Visitor.Model.Services.Dispatcher;
using Visitor.ViewModel.Common;
using Visitor.ViewModel.Common.Services;

namespace Visitor.ViewModel.Features.Visitors;

public sealed partial class VisitorListViewModel 
    : PaginatedViewModelBase<VisitorDto, GetVisitorsRequest, VisitorFilter>
{
    public VisitorListViewModel(
        IApiDispatcher dispatcher,
        INavigator navigator,
        IToastService toastService,
        IApiLogger logger,
        IApiResultPolicy policy)
        : base(dispatcher, navigator, toastService, logger, policy)
    {
    }

    protected override GetVisitorsRequest CreateRequest() => new();
}
```

#### 3️⃣ View (Razor Page)
```razor
@* src/Visitor.View.Panel/Features/Visitors/Pages/VisitorsList.razor *@
@page "/visitors"
@using Visitor.View.Panel.Common.Mvvm
@using Visitor.ViewModel.Features.Visitors
@inherits PageBase<VisitorListViewModel>

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>لیست بازدیدکنندگان</h3>
    </div>

    @if (ViewModel.IsBusy)
    {
        <p>در حال بارگذاری...</p>
    }
    else if (ViewModel.Items.Any())
    {
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>نام</th>
                    <th>ایمیل</th>
                </tr>
            </thead>
            <tbody>
                @foreach (var item in ViewModel.Items)
                {
                    <tr>
                        <td>@item.Name</td>
                        <td>@item.Email</td>
                    </tr>
                }
            </tbody>
        </table>

        <!-- Pagination -->
        <div class="d-flex justify-content-between">
            <button class="btn btn-secondary" 
                    @onclick="ViewModel.PreviousPageCommand.ExecuteAsync"
                    disabled="@(!ViewModel.HasPreviousPage)">
                قبلی
            </button>
            <span>صفحه @ViewModel.Page از @ViewModel.TotalPages</span>
            <button class="btn btn-secondary" 
                    @onclick="ViewModel.NextPageCommand.ExecuteAsync"
                    disabled="@(!ViewModel.HasNextPage)">
                بعدی
            </button>
        </div>
    }
    else
    {
        <p>موردی یافت نشد</p>
    }
</div>
```

#### 4️⃣ Register در DI
```csharp
// src/Visitor.View.Panel/Program.cs
builder.Services.AddScoped<VisitorListViewModel>();
```

---

## 🎓 مفاهیم کلیدی

### 1. Result<T> Pattern
```csharp
var result = await SendAsync<GetVisitorsRequest, PagedResult<VisitorDto>>(request);

if (result.IsSuccess)
{
    var visitors = result.Value;
}
else
{
    var error = result.Error; // ApiError
}
```

### 2. ApiError
```csharp
public enum ApiErrorKind
{
    Unauthorized,   // 401
    Forbidden,      // 403
    NotFound,       // 404
    Validation,     // 422
    Conflict,       // 409
    Server,         // 5xx
    Network,        // Connection failed
    Unknown
}
```

### 3. ViewModelBase Commands
```csharp
[RelayCommand]
private async Task LoadDataAsync()
{
    await RunBusyAsync(async () =>
    {
        var result = await SendAsync<GetVisitorsRequest, PagedResult<VisitorDto>>(request);
        // ...
    });
}
```

### 4. Route Template
```csharp
// با پارامتر
public string Route => "/Visitors/{{visitorId}}"; // → /visitors/550e8400-...

// بدون پارامتر
public string Route => "/Visitors"; // → /visitors?page=1&pageSize=20
```

### 5. Filter در Query
```csharp
request.Filter = new VisitorFilter 
{ 
    Name = "علی",
    Email = "test@example.com"
};

// → /visitors?page=1&pageSize=20&filter.name=علی&filter.email=test@example.com
```

---

## 🔥 ویژگی‌های پیشرفته

### 1. File Upload
```csharp
var uploadFile = new UploadFile("avatar.jpg", "image/jpeg", fileBytes);
request.AvatarFile = uploadFile; // IUploadFile

// به‌طور خودکار به Multipart تبدیل می‌شود
```

### 2. Debounce (جلوگیری از فراخوانی متوالی)
```csharp
await DebounceAsync(async () =>
{
    await LoadDataAsync();
}, milliseconds: 500);
```

### 3. Custom Timeout
```csharp
var context = new ApiRequestContext
{
    Timeout = TimeSpan.FromMinutes(5)
};

var result = await SendAsync<UploadRequest, UploadResponse>(request, context);
```

### 4. Custom Headers
```csharp
var context = new ApiRequestContext
{
    ExtraHeaders = new Dictionary<string, string>
    {
        ["X-Custom-Header"] = "value"
    }
};
```

---

## 📱 PWA Features

### نصب به‌عنوان App
```bash
cd src/Visitor.View.App
dotnet run
```

سپس در Chrome/Edge:
1. کلیک روی آیکون نصب در Address Bar
2. Install

### تست Offline
1. DevTools (F12) → Application → Service Workers
2. فعال کردن "Offline"
3. Refresh

---

## 🧪 تست

### تست ViewModel
```csharp
[Fact]
public async Task LoadPage_Should_Populate_Items()
{
    // Arrange
    var viewModel = CreateViewModel();

    // Act
    await viewModel.LoadPageCommand.ExecuteAsync(null);

    // Assert
    Assert.NotEmpty(viewModel.Items);
}
```

### تست API Request
```csharp
[Fact]
public async Task GetVisitors_Should_Return_PagedResult()
{
    // Arrange
    var request = new GetVisitorsRequest { Page = 1, PageSize = 10 };

    // Act
    var result = await _dispatcher.SendAsync<GetVisitorsRequest, PagedResult<VisitorDto>>(request);

    // Assert
    Assert.True(result.IsSuccess);
    Assert.NotNull(result.Value);
}
```

---

## 📚 مستندات بیشتر

| فایل | توضیحات |
|------|---------|
| [`README.md`](README.md) | مستندات کامل معماری |
| [`RUN.md`](RUN.md) | راهنمای دقیق اجرا |
| [`TROUBLESHOOTING.md`](TROUBLESHOOTING.md) | عیب‌یابی خطاها |
| [`API-CONFIG.md`](API-CONFIG.md) | تنظیمات API و محیط‌ها |
| [`src/Visitor.Model/README.md`](src/Visitor.Model/README.md) | مستندات لایه Model |

---

## 💡 نکات مهم

### ✅ Do's (انجام دهید)
- همیشه از `ViewModelBase` ارث‌بری کنید
- از `RunBusyAsync` برای مدیریت `IsBusy` استفاده کنید
- از `SendAsync` برای ارسال درخواست استفاده کنید
- Route Template ها را با `{{paramName}}` بنویسید
- از `IPaginatedRequest` برای لیست‌های صفحه‌بندی شده استفاده کنید

### ❌ Don'ts (انجام ندهید)
- مستقیماً `HttpClient` استفاده نکنید (از `IApiDispatcher` استفاده کنید)
- Session/Token را دستی مدیریت نکنید (خودکار است)
- از hard-coded URL استفاده نکنید (از `ApiOptions` استفاده کنید)
- Validation را در View انجام ندهید (در ViewModel انجام دهید)

---

## 🎉 شروع کنید!

```bash
# Build
dotnet build

# Run Panel
cd src/Visitor.View.Panel
dotnet watch run

# Open Browser
https://localhost:7xxx
```

**موفق باشید! 🚀**

---

## 🆘 نیاز به کمک؟

1. بررسی کنید: [`TROUBLESHOOTING.md`](TROUBLESHOOTING.md)
2. Console مرورگر را چک کنید (F12)
3. Network Tab را بررسی کنید
4. لاگ‌های بک‌اند را چک کنید

**تمام خطاها با `ApiResultPolicy` مدیریت می‌شوند!** 