# راهنمای عیب‌یابی (Troubleshooting)

## ❌ خطای "Failed to load module script" / "MIME type" 

### علت خطا
این خطا زمانی رخ می‌دهد که:
1. فایل‌های `_framework` به درستی build نشده‌اند
2. Cache مرورگر مشکل دارد
3. پورت اشتباه است یا پروژه اشتباه اجرا شده

### ✅ راه حل (مرحله به مرحله)

#### مرحله 1: پاک کردن کامل
```bash
# پاک کردن build قبلی
dotnet clean

# حذف پوشه‌های bin و obj
Remove-Item -Recurse -Force src/*/bin, src/*/obj
```

#### مرحله 2: Restore و Rebuild
```bash
# Restore پکیج‌ها
dotnet restore

# Build مجدد
dotnet build --no-incremental
```

#### مرحله 3: اجرای صحیح پروژه

**برای Panel (Admin):**
```bash
cd src/Visitor.View.Panel
dotnet run
```

**برای App (PWA):**
```bash
cd src/Visitor.View.App
dotnet run
```

⚠️ **مهم:** حتماً از داخل پوشه پروژه اجرا کنید، نه از ریشه solution!

#### مرحله 4: پاک کردن Cache مرورگر
1. باز کردن Developer Tools (F12)
2. کلیک راست روی دکمه Refresh
3. انتخاب "Empty Cache and Hard Reload"

یا:
```
Ctrl + Shift + Delete → Clear Cache
```

---

## 🔍 بررسی صحت اجرا

### چک کردن پورت
بعد از اجرا، پیام زیر را ببینید:
```
Now listening on: https://localhost:XXXX
```

**پورت پیش‌فرض:**
- Panel: معمولاً 5001 یا 7xxx
- App: معمولاً 5002 یا 7xxx

### چک کردن فایل‌های _framework
در مرورگر:
```
https://localhost:XXXX/_framework/blazor.webassembly.js
```

اگر این فایل 404 داد، مشکل از build است.

---

## 🚨 خطاهای رایج دیگر

### خطای CORS
```
Access to fetch at '...' has been blocked by CORS policy
```

**راه حل:**
در بک‌اند، CORS را فعال کنید:
```csharp
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowBlazor", policy =>
    {
        policy.WithOrigins("https://localhost:7187", "https://localhost:5001")
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

app.UseCors("AllowBlazor");
```

### خطای SSL/Certificate
```
The SSL connection could not be established
```

**راه حل:**
```bash
# Trust کردن certificate
dotnet dev-certs https --trust
```

### خطای "Failed to fetch"
```
Failed to fetch dynamically imported module
```

**راه حل:**
1. مطمئن شوید پروژه صحیح را اجرا کرده‌اید
2. Cache مرورگر را پاک کنید
3. پروژه را rebuild کنید

---

## 🔧 دستورات مفید

### پاک کردن کامل و اجرای مجدد
```bash
# پاک کردن
dotnet clean
Remove-Item -Recurse -Force src/*/bin, src/*/obj

# Restore
dotnet restore

# Build
dotnet build

# اجرا (از داخل پوشه پروژه)
cd src/Visitor.View.Panel
dotnet run
```

### اجرا با Watch (تغییرات خودکار)
```bash
cd src/Visitor.View.Panel
dotnet watch run
```

### بررسی پورت‌های در حال استفاده
```powershell
# Windows
netstat -ano | findstr :7187
netstat -ano | findstr :5001

# اگر پورت اشغال است، آن را آزاد کنید یا پورت دیگری استفاده کنید
```

---

## 📱 اجرای PWA (App)

### نصب به‌عنوان PWA
1. اجرای App: `cd src/Visitor.View.App && dotnet run`
2. باز کردن در Chrome
3. کلیک روی آیکون نصب در Address Bar
4. نصب PWA

### تست Offline
1. باز کردن DevTools (F12)
2. رفتن به Application → Service Workers
3. فعال کردن "Offline"
4. رفرش صفحه

---

## 🐛 Debug Mode

### فعال کردن لاگ‌های دقیق‌تر
در `index.html`:
```html
<script>
    Blazor.start({
        logLevel: 0 // 0 = Trace, 1 = Debug, 2 = Information
    });
</script>
```

### بررسی Console
Developer Tools (F12) → Console:
- بررسی خطاهای قرمز
- بررسی پیام `API BaseUrl: ...`

### بررسی Network
Developer Tools (F12) → Network:
- فیلتر روی "All" یا "Fetch/XHR"
- بررسی درخواست‌های به `_framework`
- بررسی Status Code

---

## ✅ Checklist قبل از اجرا

- [ ] `dotnet clean` اجرا شده
- [ ] `dotnet restore` اجرا شده  
- [ ] `dotnet build` موفق بوده
- [ ] از داخل پوشه پروژه اجرا می‌کنید (نه ریشه)
- [ ] Cache مرورگر پاک شده
- [ ] پورت درست است
- [ ] بک‌اند (در صورت نیاز) در حال اجرا است

---

## 📞 نیاز به کمک؟

اگر مشکل حل نشد:

1. **لاگ‌ها را بررسی کنید:**
   - Console مرورگر (F12)
   - Output ترمینال
   - Network Tab

2. **اطلاعات مورد نیاز:**
   ```
   - نسخه .NET: dotnet --version
   - سیستم‌عامل: Windows/Mac/Linux
   - مرورگر: Chrome/Edge/Firefox + نسخه
   - متن کامل خطا
   - آدرس URL کامل
   ```

3. **تست با پروژه خالی:**
   ```bash
   dotnet new blazorwasm -n TestApp
   cd TestApp
   dotnet run
   ```

---

## 🎯 نکات مهم

### ✅ درست
```bash
# اجرای Panel
cd src/Visitor.View.Panel
dotnet run

# URL: https://localhost:XXXX
```

### ❌ اشتباه
```bash
# از ریشه solution
dotnet run  # ⚠️ پروژه مشخص نیست!
```

---

**💡 نکته:** همیشه بعد از تغییرات بزرگ، یک `dotnet clean` و `dotnet build` انجام دهید.

**🚀 موفق باشید!** 