# 📝 تاریخچه تغییرات (Changelog)

## [1.1.0] - 2025-09-30

### 🔄 تغییرات اساسی
- **Downgrade به .NET 8:** تمام پروژه‌ها از .NET 10 به .NET 8 تغییر کردند

### 📦 تغییرات پکیج‌ها
- `Microsoft.Extensions.Http`: 9.0.9 → 8.0.0
- `Microsoft.AspNetCore.Components.WebAssembly`: 10.0.0-preview → 8.0.11
- `Microsoft.AspNetCore.Components.WebAssembly.DevServer`: 10.0.0-preview → 8.0.11

### 📚 مستندات
- به‌روزرسانی تمام مستندات برای .NET 8
- `README.md` به‌روزرسانی شد
- `QUICK-START.md` به‌روزرسانی شد
- `RUN.md` به‌روزرسانی شد
- `PROJECT-SUMMARY.md` به‌روزرسانی شد

### ✅ وضعیت
- Build موفق بدون خطا
- تمام Warnings رفع شده
- تمام پروژه‌ها کامپایل می‌شوند

---

## [1.0.0] - 2025-09-30

### 🎉 نسخه اولیه
- ایجاد Solution با 4 پروژه اصلی
- پیاده‌سازی معماری MVVM با SOLID principles
- ساخت API Communication Layer کامل
- پشتیبانی از Pagination و File Upload
- پیاده‌سازی PWA با Offline Support
- ایجاد Feature نمونه (Products)
- مستندات جامع (7 فایل)

### ویژگی‌های کلیدی
- ✅ Generic API Dispatcher
- ✅ Automatic Route Building
- ✅ Smart Body Binding
- ✅ Result<T> Pattern
- ✅ Error Handling Policy
- ✅ Session & Cart Management
- ✅ ViewModelBase و PaginatedViewModelBase

---

**راهنمای Versioning:**
- Major (X.0.0): تغییرات Breaking
- Minor (0.X.0): ویژگی‌های جدید
- Patch (0.0.X): Bug Fixes 