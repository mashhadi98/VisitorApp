# راهنمای کانفیگ API

## 📍 آدرس API فعلی

```
BaseUrl: https://localhost:6070/api/
```

## ⚙️ تنظیمات

### محیط Development (توسعه)
فایل: `src/Visitor.View.Panel/wwwroot/appsettings.Development.json`
```json
{
  "ApiSettings": {
    "BaseUrl": "https://localhost:6070/api/"
  }
}
```

### محیط Production (تولید)
فایل: `src/Visitor.View.Panel/wwwroot/appsettings.Production.json`
```json
{
  "ApiSettings": {
    "BaseUrl": "https://api.yourproduction.com/api/"
  }
}
```

## 🔧 نحوه تغییر آدرس API

### روش 1: تغییر در appsettings.json
برای **Panel** (Admin):
```
src/Visitor.View.Panel/wwwroot/appsettings.json
```

برای **App** (PWA):
```
src/Visitor.View.App/wwwroot/appsettings.json
```

### روش 2: تغییر در Program.cs
در صورت نیاز به تنظیمات پیشرفته:

```csharp
var apiOptions = new ApiOptions
{
    BaseUrl = "https://your-api-url.com/api/",
    Version = "v1",
    DefaultTimeout = TimeSpan.FromSeconds(30)
};
```

## 🌐 محیط‌های مختلف

### Development (محلی)
```bash
# اجرا با محیط Development
dotnet run --environment Development
```
→ از `appsettings.Development.json` استفاده می‌کند

### Production (تولید)
```bash
# اجرا با محیط Production
dotnet run --environment Production
```
→ از `appsettings.Production.json` استفاده می‌کند

## 🔍 بررسی آدرس API

هنگام اجرای برنامه، آدرس API در Console نمایش داده می‌شود:
```
API BaseUrl: https://localhost:6070/api/
```

## 📝 نکات مهم

### 1. Trailing Slash
✅ درست: `https://localhost:6070/api/`
❌ بدون slash: `https://localhost:6070/api`

### 2. HTTPS
- در محیط Development: می‌توانید از HTTP استفاده کنید
- در محیط Production: حتماً HTTPS استفاده کنید

### 3. CORS
مطمئن شوید بک‌اند شما CORS را برای آدرس فرانت‌اند تنظیم کرده است:

```csharp
// در بک‌اند ASP.NET Core
builder.Services.AddCors(options =>
{
    options.AddPolicy("BlazorPolicy", policy =>
    {
        policy.WithOrigins(
            "https://localhost:5001",  // Panel
            "https://localhost:5002"   // App
        )
        .AllowAnyMethod()
        .AllowAnyHeader();
    });
});
```

## 🧪 تست اتصال

### تست با Postman/cURL
```bash
curl -X GET "https://localhost:6070/api/products?page=1&pageSize=20"
```

### تست از برنامه
1. اجرای برنامه
2. رفتن به صفحه Products
3. چک کردن Console (F12) برای درخواست‌های HTTP

## 🚨 عیب‌یابی

### خطای CORS
```
Access to fetch at 'https://localhost:6070/api/...' has been blocked by CORS policy
```
**راه حل:** CORS را در بک‌اند فعال کنید

### خطای SSL/Certificate
```
The SSL connection could not be established
```
**راه حل:** 
- Trust کردن certificate محلی: `dotnet dev-certs https --trust`
- یا استفاده از HTTP در Development

### خطای Connection Refused
```
Failed to fetch
```
**راه حل:**
- مطمئن شوید بک‌اند در حال اجرا است
- آدرس و پورت را چک کنید

## 📦 ساختار فایل‌های کانفیگ

```
src/
├── Visitor.View.Panel/
│   └── wwwroot/
│       ├── appsettings.json              # تنظیمات پیش‌فرض
│       ├── appsettings.Development.json  # برای Development
│       └── appsettings.Production.json   # برای Production
│
└── Visitor.View.App/
    └── wwwroot/
        ├── appsettings.json
        ├── appsettings.Development.json
        └── appsettings.Production.json
```

## 🔐 امنیت

⚠️ **هشدار:** آدرس API در فایل‌های appsettings نگهداری می‌شود که در Client-Side قابل مشاهده است.
- اطلاعات حساس را در appsettings ذخیره نکنید
- از Authentication و Authorization در سمت سرور استفاده کنید
- توکن‌ها را در SessionStorage/LocalStorage ذخیره کنید (نه در appsettings)

## 📞 پشتیبانی

در صورت مشکل در اتصال به API:
1. بررسی Console مرورگر (F12)
2. بررسی Network Tab
3. بررسی لاگ‌های بک‌اند
4. چک کردن آدرس و پورت API

---

**✨ آدرس API شما: `https://localhost:6070/api/`** 