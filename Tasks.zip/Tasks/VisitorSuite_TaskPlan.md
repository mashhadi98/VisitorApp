
# VisitorSuite — Phased Task Plan (Blazor WASM + MVVM Toolkit)
**Last updated:** 2025-09-29T19:44:28Z

> دستورالعمل: تمام **فایل‌های زیرساختی** باید در پوشه‌ی **`Common/`** هر لایه/پروژه قرار بگیرند و **پوشه‌بندی‌های فیچر** در شاخه‌ی `Features/` انجام شود. این پلن به‌صورت **فازبندی** نوشته شده و هر تسک شامل توضیحات واضح و Acceptance Criteria است تا برای یک عامل AI (مثل Cursor) قابل‌اجرا باشد.

---

## ساختار کلان سلوشن (ریشه)
```
VisitorSuite.sln
src/
  Visitor.Model/             # لایه ارتباط با بک‌اند (Requests/Responses + Dispatcher + Http)
  Visitor.ViewModel/         # منطق MVVM مشترک (Base ها، State ها)
  Visitor.View.Panel/        # Blazor WASM - پنل دسکتاپ (Admin)
  Visitor.View.App/          # Blazor WASM - PWA موبایل (Visitor)
tests/
  Visitor.Model.Tests/
  Visitor.ViewModel.Tests/
```

> اصل ثابت: هر پروژه دو بخش کلیدی دارد: **Common/** برای زیرساخت و **Features/** برای فیچرها.

---

## Phase 0 — Bootstrap & Conventions
**هدف:** ساخت پروژه‌ها، پکیج‌ها، و استانداردهای نام‌گذاری/پوشه‌بندی.

### Tasks
1) **ایجاد پروژه‌ها و ارجاعات**
   - ساخت ۴ پروژه با نام‌های بالا.
   - ارجاعات:
     - `Visitor.ViewModel` → `Visitor.Model`
     - `Visitor.View.Panel` → `Visitor.ViewModel` و `Visitor.Model`
     - `Visitor.View.App` → `Visitor.ViewModel` و `Visitor.Model`
   - **AC:**
     - سلوشن build شود و خروجی بدون خطا باشد.

2) **استاندارد پوشه‌بندی**
   - در هر پروژه دو ریشه بساز:
     - `Common/` : تمام زیرساخت‌ها (Baseها، Serviceها، Options/Config، Mapperها، Helpers).
     - `Features/` : پوشه‌های هر فیچر (Products, Customers, Orders, Auth, ...).
   - **AC:**
     - هیچ فایل زیرساختی خارج از `Common/` نباشد.
     - هیچ فایل فیچر خارج از `Features/` نباشد.

3) **نصب پکیج‌ها**
   - همهٔ کلاینت‌ها و ViewModel: `CommunityToolkit.Mvvm`
   - Model: `Microsoft.Extensions.Http` و `System.Text.Json`
   - **AC:**
     - پکیج‌ها در csproj ثبت شده و restore موفق شود.

---

## Phase 1 — Model/Common (Dispatcher + Http + StandardResponse)
**هدف:** یک Dispatcher جنریک که با `RequestBase.Route` و `Method` کار کند و خروجی سرور (StandardResponse) را به `Result<T>` تبدیل نماید.

### درخت پوشهٔ Model
```
Visitor.Model/
  Common/
    Result.cs                 # Result<T>, ApiError, ApiErrorKind, meta
    ApiOptions.cs             # BaseUrl, Version, Timeouts
    StandardResponseDto.cs    # TraceId, StatusCode, Timestamp, Data(JsonElement?), Error
    ErrorDetailsDto.cs
  Services/
    Common/
      IApiClient.cs           # wrapper روی HttpClient
      ApiClient.cs
      ApiRequestContext.cs    # Timeout, TokenOverride, ExtraHeaders, CancellationToken, ReturnUrl?
      ISessionTokenProvider.cs
    Dispatcher/
      IApiDispatcher.cs
      ApiDispatcher.cs        # SendAsync<TReq,TRes>(req, ctx)
      ApiResponseMapper.cs    # Map(StandardResponseDto → Result<T>)
      RouteBuilder.cs         # جایگذاری {{id}} + snake_case روی segments
      BodyBinder.cs           # GET: Query; POST/PUT/PATCH: JSON | multipart (اگر فایل)
    Uploads/
      IUploadFile.cs
      UploadFile.cs
  Features/
    # فقط Request/Responseهای فیچرها، نه زیرساخت
```

### Tasks
1) **Common/Result.cs**
   - `Result<T>` با `IsSuccess`, `Value`, `Error(ApiError)`, و meta (TraceId/StatusCode/Timestamp).
   - `ApiErrorKind` شامل: Unauthorized, Forbidden, NotFound, Validation, Conflict, Server, Network, Unknown.
   - **AC:** ساخت نمونه‌های `Success/Failure` و نگاشت خطاها تست واحد داشته باشد.

2) **Common/StandardResponseDto.cs + ErrorDetailsDto.cs**
   - `StandardResponseDto`: `TraceId`, `StatusCode`, `Timestamp`, `JsonElement? Data`, `ErrorDetailsDto? Error`.
   - **AC:** دسیریالایز از JSON نمونهٔ سرور بدون خطا.

3) **Services/Common/ApiRequestContext.cs + ISessionTokenProvider.cs**
   - Context سبک: `Timeout?`, `BearerTokenOverride?`, `CancellationToken`, `ExtraHeaders`, `ReturnUrl?`.
   - Token Provider برای گرفتن توکن جاری (از کلاینت).
   - **AC:** در `ApiClient` اولویت TokenOverride>Provider رعایت شود.

4) **Services/Common/IApiClient.cs + ApiClient.cs**
   - توابع پایهٔ `SendAsync(HttpRequestMessage)`، utilities برای JSON/multipart.
   - **AC:** درخواست به BaseUrl+Route ارسال و پاسخ خام دریافت شود.

5) **Services/Dispatcher/RouteBuilder.cs**
   - جایگذاری `{{param}}` ها از روی پراپرتی‌های Request.
   - snake_case فقط روی **Segments غیرپارامتری**.
   - **AC:** واحد تست: ورودی `/Products/{{productId}}` + `ProductId` → خروجی `/products/<guid>`.

6) **Services/Dispatcher/BodyBinder.cs**
   - قواعد بایند:
     - GET ⇒ Query (Page/PageSize/Sort/Filter با prefix `filter.`)
     - POST/PUT/PATCH ⇒ JSON یا `multipart/form-data` اگر فایل وجود دارد.
   - **AC:** واحد تست: ۳ سناریوی GET/JSON/multipart.

7) **Services/Dispatcher/ApiResponseMapper.cs + IApiDispatcher.cs + ApiDispatcher.cs**
   - `SendAsync<TReq,TRes>`: ارسال، خواندن `StandardResponseDto`، نگاشت به `Result<TRes>`.
   - نگاشت StatusCode → `ApiErrorKind` و حفظ `TraceId`.
   - **AC:** 401 ⇒ `Result.Failure(Unauthorized)`؛ 422 ⇒ Validation با `ValidationErrors`؛ 5xx ⇒ Server.

---

## Phase 2 — Model/Common (Pagination & Mapping)
**هدف:** پشتیبانی از صفحه‌بندی با خروجی سرور `PaginatedResponse<T>` و مصرف یکنواخت در کلاینت.

### افزوده‌ها
```
Visitor.Model/
  Common/
    PagedResult.cs              # Items/TotalCount/(Page,PageSize,TotalPages)
  Contracts/Responses/Common/
    PaginatedResponseDto.cs     # آینهٔ سرور: List/Count
```

### Tasks
1) **Contracts/Responses/Common/PaginatedResponseDto.cs**
   - `ICollection<T> List`, `int Count`.
   - **AC:** دسیریالایز `StandardResponse.Data` به این DTO موفق باشد.

2) **Common/PagedResult.cs**
   - `IReadOnlyList<T> Items`, `int TotalCount`, `int Page`, `int PageSize`, `int TotalPages`.
   - **AC:** TotalPages = ceil(TotalCount / PageSize).

3) **ApiResponseMapper: پشتیبانی PagedResult**
   - اگر `TRes` از نوع `PagedResult<TItem>` باشد، `Data` را به `PaginatedResponseDto<TItem>` بخوان، سپس map به `PagedResult<TItem>` (Page/PageSize از Request فعلی).
   - **AC:** تست: ورودی List=37 و PageSize=20 ⇒ TotalPages=2.

4) **BodyBinder: بایند Query صفحه‌بندی**
   - `page`, `pageSize`, `sort`, و **`filter.*`**.
   - **AC:** خروجی Query مطابق نمونه باشد: `?page=1&pageSize=20&sort=CreateDate&filter.name=...`

---

## Phase 3 — ViewModel/Common (Base ها + State ها)
**هدف:** ارائهٔ Baseهای قابل‌استفادهٔ مجدد برای VMها با هماهنگی کامل با Model.

### درخت پوشهٔ ViewModel
```
Visitor.ViewModel/
  Common/
    ViewModelBase.cs
    PaginatedViewModelBase.cs
    State/
      SessionState.cs
      CartState.cs (برای App؛ فعلاً اسکلت)
```

### Tasks
1) **Common/ViewModelBase.cs**
   - ویژگی‌ها و متدها: `IsBusy`, `RunBusyAsync`, `SendAsync`, `TryRequestAsync`, `NotifySuccess/Info/Error`, `NavigateToAsync`, `ApplyValidation`, `DebounceAsync`, `OnAppearingAsync/OnDisappearingAsync`.
   - **AC:** بدون وابستگی به UI، فقط به اینترفیس‌های Model و سرویس‌های انتزاعی.

2) **Common/PaginatedViewModelBase.cs**
   - جنریک: `<TItem, TReq, TFilter>`؛ `TReq : IPaginatedRequest<TFilter>, IRequest<PagedResult<TItem>>`.
   - State: `Items`, `Page`, `PageSize`, `TotalCount`, `TotalPages`, `HasNext/HasPrevious`, `Filter`, `Sort`.
   - متدها: `LoadPageAsync`, `RefreshAsync`, `NextPageAsync`, `PreviousPageAsync`, `GoToPageAsync`, `ApplyFilterAsync`, `ApplySortAsync`.
   - **AC:** مصرف‌کنندهٔ `PagedResult<TItem>` از Model؛ تغییر state صحیح.

3) **Common/State/SessionState.cs (+ CartState.cs)**
   - `SessionState`: نگهداری کاربر/توکن.
   - `CartState`: اسکلت (در App بعدها تکمیل می‌شود).
   - **AC:** DI-ready و thread-safe سبک.

---

## Phase 4 — View.Panel/Common (Page Base + UI Policy + Services)
**هدف:** زیرساخت UI مشترک برای پنل دسکتاپ؛ هماهنگ با ViewModelBase.

### درخت پوشهٔ Panel
```
Visitor.View.Panel/
  Common/
    Mvvm/
      PageViewModelBase.cs
    Services/
      Navigator.cs   # INavigator
      ToastService.cs# IToastService
      ApiLogger.cs   # IApiLogger (Console)
      ApiResultPolicyPanel.cs # IApiResultPolicy
  Features/
    (بعداً)
```

### Tasks
1) **Common/Mvvm/PageViewModelBase.cs**
   - `ComponentBase` + `IDisposable`؛ پارامتر `[Parameter] required TViewModel ViewModel`.
   - lifecycle: `OnAfterRenderAsync(firstRender) => ViewModel.OnAppearingAsync(); Dispose() => OnDisappearingAsync()`.
   - `IsBusy` mirror، hooks `AfterFirstRenderAsync`, `OnViewModelPropertyChanged`.
   - **AC:** صفحهٔ نمونه بتواند فقط با ارث‌بری از Base کار کند.

2) **Common/Services/Navigator.cs (INavigator)**
   - متدهایی مثل `NavigateTo(string route, bool replace=false)`, `GoToLogin(string? returnUrl)`.
   - **AC:** مسیرها عمل کنند؛ returnUrl پاس شود.

3) **Common/Services/ToastService.cs (IToastService)**
   - `ShowSuccess/Info/Error(string msg)`—فعلاً console یا ساده.
   - **AC:** فراخوانی از VM نمایش پیام بدهد.

4) **Common/Services/ApiLogger.cs (IApiLogger)**
   - `LogError(ApiError error, object? request)` به Console با TraceId/Status.
   - **AC:** در خطاها لاگ شود.

5) **Common/Services/ApiResultPolicyPanel.cs (IApiResultPolicy)**
   - رفتار: 401 ⇒ پاک‌کردن Session، `Navigator.GoToLogin(returnUrl)`؛ غیر از آن ⇒ Toast + Log.
   - **AC:** اتصال سیاست به نتایج `SendAsync` عملیاتی باشد.

6) **Program.cs (Composition Root)**
   - رجیستر: `INavigator`, `IToastService`, `IApiLogger`, `IApiResultPolicy`, `ISessionTokenProvider`.
   - **AC:** اپ اجرا و DI بدون خطا.

---

## Phase 5 — View.App/Common (Page Base + UI Policy + PWA Bits)
**هدف:** زیرساخت مشابه برای اپ موبایل (PWA) + آماده‌سازی PWA پایه.

### درخت پوشهٔ App
```
Visitor.View.App/
  Common/
    Mvvm/
      PageViewModelBase.cs
    Services/
      Navigator.cs, ToastService.cs, ApiLogger.cs, ApiResultPolicyApp.cs
    Pwa/
      manifest.webmanifest
      service-worker.js
      offline-fallback.html
  Features/
    (بعداً)
```

### Tasks
1) **Common/Mvvm/PageViewModelBase.cs (نسخهٔ App)** — مشابه Panel.
2) **Common/Services/** — Navigator/Toast/Logger/Policy نسخهٔ App.
3) **Common/Pwa/** — فایل‌های پایه PWA.
   - **AC:** نصب به‌عنوان PWA ممکن باشد؛ در حالت آفلاین offline-fallback نمایش داده شود.

4) **Program.cs (Composition Root)**
   - رجیستر سرویس‌ها همانند Panel.
   - **AC:** اپ اجرا و DI بدون خطا.

---

## Phase 6 — Features Scaffolding (Admin + App)
**هدف:** فقط اسکلت فیچرها (بدون منطق پیچیده) تا مسیرها/DI تست شوند.

### درخت نمونهٔ Features
```
Visitor.Model/
  Features/
    Products/
      Requests/
        GetPaginatedProductRequest.cs
        CreateProductRequest.cs
        UpdateProductRequest.cs
        DeleteProductRequest.cs
      Responses/
        ProductDto.cs
        CreateProductResponse.cs
        UpdateProductResponse.cs

Visitor.ViewModel/
  Features/
    Products/
      ProductListViewModel.cs         # ارث‌بر از PaginatedViewModelBase<ProductDto, GetPaginatedProductRequest, ProductFilter>
      ProductEditViewModel.cs

Visitor.View.Panel/
  Features/
    Products/
      Pages/
        ProductsList.razor
        ProductEdit.razor
      Components/ (اختیاری)
Visitor.View.App/
  Features/
    Products/
      Pages/
        ProductBrowser.razor
      Components/
        ProductTile.razor
```

### Tasks
1) **Model/Features/Products (Requests/Responses)**
   - تعریف نمونه‌ها با `Route` و `Method` (از بک‌اند).
   - **AC:** `SendAsync` با API واقعی کار کند (یا با FakeHandler در تست).

2) **ViewModel/Features/Products**
   - `ProductListViewModel` از Base صفحه‌بندی ارث ببرد؛ فقط wiring.
   - `ProductEditViewModel` از ViewModelBase ارث ببرد.
   - **AC:** متد `LoadPageAsync` دادهٔ نمونه را دریافت و state را پر کند.

3) **View.Panel/Features/Products/Pages**
   - `ProductsList.razor` ارث از `PageViewModelBase<ProductListViewModel>`؛ فقط جدول ساده و دکمهٔ Refresh.
   - **AC:** صفحه render شود و روال صفحه‌بندی کار کند.

4) **View.App/Features/Products/Pages**
   - `ProductBrowser.razor` ارث از Base؛ Grid ساده با دکمهٔ Add (فعلاً no-op).
   - **AC:** صفحه render شود و فراخوانی لیست کار کند.

---

## Phase 7 — Error/401 Flow & Validation UX
**هدف:** تکمیل رفتارهای خطا براساس `StandardResponse.Error` و `ValidationErrors`.

### Tasks
1) **Model/Common/ApiResponseMapper**
   - اطمینان از نگاشت ValidationErrors به `Result.Error.ValidationErrors`.
   - **AC:** تست واحد با نمونهٔ 422/400.

2) **ViewModel/ViewModelBase.ApplyValidation**
   - نگاشت `ValidationErrors` به دیکشنری قابل‌مصرف توسط View.
   - **AC:** VM بتواند پیام فیلدی را expose کند.

3) **View.* (Policy)**
   - 401: پاک‌کردن Session + Login Redirect با returnUrl.
   - غیر از آن: Toast + Console Log با TraceId.
   - **AC:** شبیه‌سازی 401 و 422 در تست/دِو.

---

## Phase 8 — CartState & Checkout (App only; Skeleton)
**هدف:** آماده‌سازی اسکلت سبد خرید و ثبت سفارش در اپ موبایل.

### Tasks
1) **ViewModel/Common/State/CartState.cs**
   - API: Add, Remove, UpdateQty, Clear, ComputeTotals.
   - Persist (اختیاری) در LocalStorage (در فاز بعد).
   - **AC:** متدها state را درست به‌روزرسانی کنند.

2) **ViewModel/Features/Cart & Checkout VMs (اسکلت)**
   - `CartViewModel`, `ReviewAndSubmitViewModel` از ViewModelBase.
   - **AC:** متد Submit صدا زدن `CreateOrderRequest` (اسکلت).

3) **View.App/Features/Cart & Checkout Pages**
   - صفحات ساده‌ی سبد و بازبینی.
   - **AC:** Flow از ProductBrowser → Cart → ReviewAndSubmit قابل کلیک باشد.

---

## Phase 9 — Tests
**هدف:** تست‌های حیاتی برای پایداری.

### Tasks
1) **Visitor.Model.Tests**
   - `RouteBuilderTests`: snake_case و جایگذاری پارام‌ها.
   - `BodyBinderTests`: GET/JSON/multipart + filter prefix.
   - `ApiResponseMapperTests`: Standard→Result / PagedResult mapping.
   - **AC:** تمام تست‌ها پاس شوند.

2) **Visitor.ViewModel.Tests**
   - `PaginatedViewModelBaseTests`: LoadPage/Next/Prev/ApplyFilter/ApplySort.
   - **AC:** state نهایی مطابق انتظار.

---

## یادداشت‌های پیاده‌سازی
- **Prefix Filter:** طبق تصمیم، **`filter.<prop>`** در Query استفاده شود.
- **فایل‌ها (Upload):** در کلاینت از `UploadFile` استفاده شود و در multipart به فیلد `imageFile` مپ شود.
- **Enum Sort:** نام دقیق enum در Query (مثلاً `CreateDate`, `DescendingCreateDate`).

---

## Definition of Done (برای کل فاز زیرساخت)
- تمام زیرساخت‌ها فقط در `Common/` هر پروژه قرار دارند.
- فیچرها فقط در `Features/` هر پروژه قرار دارند.
- لیست محصولات (پنل و اپ) با صفحه‌بندی کار می‌کند.
- 401 به صفحهٔ لاگین هدایت می‌شود؛ سایر خطاها Toast + Console با TraceId.
- تست‌های Model و ViewModel پاس هستند.
