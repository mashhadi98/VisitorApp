using Microsoft.JSInterop;
using VisitorApp.Models.Services;

namespace VisitorApp.Web.Panel.Services;

public class TokenService : ITokenService
{
    private readonly IJSRuntime _jsRuntime;
    private const string ACCESS_TOKEN_KEY = "access_token";
    private const string REFRESH_TOKEN_KEY = "refresh_token";
    private const string TOKEN_EXPIRY_KEY = "token_expiry";

    public TokenService(IJSRuntime jsRuntime)
    {
        _jsRuntime = jsRuntime;
    }

    public async Task SetTokensAsync(string accessToken, string refreshToken, DateTime expiresAt)
    {
        await _jsRuntime.InvokeVoidAsync("localStorage.setItem", ACCESS_TOKEN_KEY, accessToken);
        await _jsRuntime.InvokeVoidAsync("localStorage.setItem", REFRESH_TOKEN_KEY, refreshToken);
        await _jsRuntime.InvokeVoidAsync("localStorage.setItem", TOKEN_EXPIRY_KEY, expiresAt.ToString("O"));
    }

    public async Task<string?> GetAccessTokenAsync()
    {
        try
        {
            return await _jsRuntime.InvokeAsync<string?>("localStorage.getItem", ACCESS_TOKEN_KEY);
        }
        catch
        {
            return null;
        }
    }

    public async Task<string?> GetRefreshTokenAsync()
    {
        try
        {
            return await _jsRuntime.InvokeAsync<string?>("localStorage.getItem", REFRESH_TOKEN_KEY);
        }
        catch
        {
            return null;
        }
    }

    public async Task<DateTime?> GetTokenExpirationAsync()
    {
        try
        {
            var expiryString = await _jsRuntime.InvokeAsync<string?>("localStorage.getItem", TOKEN_EXPIRY_KEY);
            if (string.IsNullOrEmpty(expiryString))
                return null;

            return DateTime.TryParse(expiryString, out var expiry) ? expiry : null;
        }
        catch
        {
            return null;
        }
    }

    public async Task<bool> IsTokenValidAsync()
    {
        var accessToken = await GetAccessTokenAsync();
        if (string.IsNullOrEmpty(accessToken))
            return false;

        var expiry = await GetTokenExpirationAsync();
        if (expiry == null)
            return false;

        // Check if token expires in the next 5 minutes (add buffer time)
        return expiry > DateTime.UtcNow.AddMinutes(5);
    }

    public async Task ClearTokensAsync()
    {
        await _jsRuntime.InvokeVoidAsync("localStorage.removeItem", ACCESS_TOKEN_KEY);
        await _jsRuntime.InvokeVoidAsync("localStorage.removeItem", REFRESH_TOKEN_KEY);
        await _jsRuntime.InvokeVoidAsync("localStorage.removeItem", TOKEN_EXPIRY_KEY);
    }

    public async Task<bool> HasValidTokenAsync()
    {
        return await IsTokenValidAsync();
    }
} 