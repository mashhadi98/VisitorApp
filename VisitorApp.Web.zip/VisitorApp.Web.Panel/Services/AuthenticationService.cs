using System.Text.Json;
using Microsoft.JSInterop;
using VisitorApp.Models.Identity;
using VisitorApp.Models.Repositories.Identity;
using VisitorApp.Models.Services;

namespace VisitorApp.Web.Panel.Services;

public class AuthenticationService : IAuthenticationService
{
    private readonly ITokenService _tokenService;
    private readonly IIdentityRepository _identityRepository;
    private readonly IJSRuntime _jsRuntime;
    private readonly JsonSerializerOptions _jsonOptions;
    private const string USER_INFO_KEY = "user_info";

    public event Action<bool>? AuthenticationStateChanged;

    public AuthenticationService(
        ITokenService tokenService,
        IIdentityRepository identityRepository,
        IJSRuntime jsRuntime)
    {
        _tokenService = tokenService;
        _identityRepository = identityRepository;
        _jsRuntime = jsRuntime;
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            PropertyNameCaseInsensitive = true
        };
    }

    public async Task<bool> IsAuthenticatedAsync()
    {
        return await _tokenService.HasValidTokenAsync();
    }

    public async Task<UserInfo?> GetCurrentUserAsync()
    {
        try
        {
            if (!await IsAuthenticatedAsync())
                return null;

            var userInfoJson = await _jsRuntime.InvokeAsync<string?>("localStorage.getItem", USER_INFO_KEY);
            if (string.IsNullOrEmpty(userInfoJson))
                return null;

            return JsonSerializer.Deserialize<UserInfo>(userInfoJson, _jsonOptions);
        }
        catch
        {
            return null;
        }
    }

    public async Task LoginAsync(LoginResponse loginResponse)
    {
        // Store tokens
        await _tokenService.SetTokensAsync(
            loginResponse.AccessToken,
            loginResponse.RefreshToken,
            loginResponse.ExpiresAt);

        // Store user info
        var userInfoJson = JsonSerializer.Serialize(loginResponse.User, _jsonOptions);
        await _jsRuntime.InvokeVoidAsync("localStorage.setItem", USER_INFO_KEY, userInfoJson);

        // Notify authentication state changed
        AuthenticationStateChanged?.Invoke(true);
    }

    public async Task LogoutAsync()
    {
        // Clear all authentication data
        await _tokenService.ClearTokensAsync();
        await _jsRuntime.InvokeVoidAsync("localStorage.removeItem", USER_INFO_KEY);

        // Try to call logout API endpoint (optional, even if it fails we clear local data)
        try
        {
            await _identityRepository.LogoutAsync();
        }
        catch
        {
            // Ignore logout API errors, local logout is more important
        }

        // Notify authentication state changed
        AuthenticationStateChanged?.Invoke(false);
    }

    public async Task<bool> TryRefreshTokenAsync()
    {
        try
        {
            var refreshToken = await _tokenService.GetRefreshTokenAsync();
            if (string.IsNullOrEmpty(refreshToken))
                return false;

            var refreshResponse = await _identityRepository.RefreshTokenAsync(refreshToken);
            if (refreshResponse.IsSuccess && refreshResponse.Data != null)
            {
                await LoginAsync(refreshResponse.Data);
                return true;
            }

            // If refresh fails, logout user
            await LogoutAsync();
            return false;
        }
        catch
        {
            // If refresh fails, logout user
            await LogoutAsync();
            return false;
        }
    }
} 