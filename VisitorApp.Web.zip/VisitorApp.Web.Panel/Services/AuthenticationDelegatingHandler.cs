using Microsoft.AspNetCore.Components;
using System.Net;
using System.Net.Http.Headers;
using VisitorApp.Models.Services;

namespace VisitorApp.Web.Panel.Services;

public class AuthenticationDelegatingHandler : DelegatingHandler
{
    private readonly ITokenService _tokenService;
    private readonly IAuthenticationService _authenticationService;
    private readonly NavigationManager _navigationManager;

    public AuthenticationDelegatingHandler(
        ITokenService tokenService,
        IAuthenticationService authenticationService,
        NavigationManager navigationManager)
    {
        _tokenService = tokenService;
        _authenticationService = authenticationService;
        _navigationManager = navigationManager;
    }

    protected override async Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request,
        CancellationToken cancellationToken)
    {
        // Add Authorization header if token exists and request is not to login/register endpoints
        if (!IsAuthEndpoint(request.RequestUri?.PathAndQuery))
        {
            var accessToken = await _tokenService.GetAccessTokenAsync();
            if (!string.IsNullOrEmpty(accessToken))
            {
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            }
        }

        // Send the request
        var response = await base.SendAsync(request, cancellationToken);

        // Handle 401 Unauthorized
        if (response.StatusCode == HttpStatusCode.Unauthorized)
        {
            return await HandleUnauthorizedAsync(request, cancellationToken);
        }

        return response;
    }

    private async Task<HttpResponseMessage> HandleUnauthorizedAsync(
        HttpRequestMessage originalRequest,
        CancellationToken cancellationToken)
    {
        // Try to refresh token first
        var refreshSuccess = await _authenticationService.TryRefreshTokenAsync();
        
        if (refreshSuccess)
        {
            // Retry original request with new token
            var newToken = await _tokenService.GetAccessTokenAsync();
            if (!string.IsNullOrEmpty(newToken))
            {
                originalRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", newToken);
                return await base.SendAsync(originalRequest, cancellationToken);
            }
        }

        // If refresh fails or no new token, logout and redirect to login
        await _authenticationService.LogoutAsync();
        
        // Redirect to login page
        _navigationManager.NavigateTo("/login", true);
        
        // Return the original 401 response
        return new HttpResponseMessage(HttpStatusCode.Unauthorized)
        {
            Content = new StringContent("Authentication required. Redirecting to login page.")
        };
    }

    private static bool IsAuthEndpoint(string? path)
    {
        if (string.IsNullOrEmpty(path))
            return false;

        var authEndpoints = new[] { "/identity/login", "/identity/register", "/identity/refresh-token" };
        return authEndpoints.Any(endpoint => path.Contains(endpoint, StringComparison.OrdinalIgnoreCase));
    }
} 