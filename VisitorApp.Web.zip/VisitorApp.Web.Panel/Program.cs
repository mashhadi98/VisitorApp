using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.Extensions.Configuration;
using VisitorApp.Web.Panel;
using VisitorApp.Web.Panel.Services;
using Radzen;

// Models layer
using VisitorApp.Models.Configuration;
using VisitorApp.Models.Services;
using VisitorApp.Models.Repositories.Identity;
using VisitorApp.Models.Repositories.Catalog;

// ViewModels layer
using VisitorApp.ViewModels;
using VisitorApp.ViewModels.Identity;
using VisitorApp.ViewModels.Catalog;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// Add Configuration
var appSettings = builder.Configuration.GetSection(AppSettings.SectionName).Get<AppSettings>() ?? new AppSettings();
builder.Services.AddSingleton(appSettings);
builder.Services.AddSingleton<IAppConfiguration>(sp => new AppConfiguration(sp.GetRequiredService<AppSettings>()));

// Configure HttpClient with Authentication Handler
builder.Services.AddHttpClient<HttpClient>(client =>
{
    var config = builder.Configuration.GetSection(AppSettings.SectionName).Get<AppSettings>() ?? new AppSettings();
    client.BaseAddress = new Uri(config.ApiBaseUrl);
    client.Timeout = TimeSpan.FromSeconds(config.RequestTimeoutSeconds);
})
.AddHttpMessageHandler<AuthenticationDelegatingHandler>();

builder.Services.AddScoped(sp => sp.GetRequiredService<IHttpClientFactory>().CreateClient(nameof(HttpClient)));

// Add Radzen services
builder.Services.AddRadzenComponents();

// Add Services
builder.Services.AddScoped<IErrorHandlingService, ErrorHandlingService>();
builder.Services.AddScoped<ITokenService, VisitorApp.Web.Panel.Services.TokenService>();
builder.Services.AddScoped<IAuthenticationService, VisitorApp.Web.Panel.Services.AuthenticationService>();
builder.Services.AddScoped<AuthenticationDelegatingHandler>();

// Add Repositories
builder.Services.AddScoped<IIdentityRepository, IdentityRepository>();
builder.Services.AddScoped<IProductRepository, ProductRepository>();
builder.Services.AddScoped<ICategoryRepository, CategoryRepository>();
builder.Services.AddScoped<IUserRepository, UserRepository>();
builder.Services.AddScoped<IRoleRepository, RoleRepository>();

// Add ViewModels
builder.Services.AddScoped<UserViewModel>();
builder.Services.AddScoped<RoleViewModel>();
builder.Services.AddScoped<LoginViewModel>();
builder.Services.AddScoped<RegisterViewModel>();
builder.Services.AddScoped<ProductListViewModel>();
builder.Services.AddScoped<ProductFormViewModel>();
builder.Services.AddScoped<CategoryListViewModel>();
builder.Services.AddScoped<CategoryFormViewModel>();

await builder.Build().RunAsync();
