# VisitorApp - MVVM Blazor Solution

یک پروژه Blazor WebAssembly با معماری MVVM که از MVVM Community Toolkit و Radzen Blazor Components استفاده می‌کند.

## 🏗️ ساختار پروژه

### 📁 لایه‌های اصلی

```
VisitorApp.Web/
├── src/
│   └── VisitorApp.Models/          # 📊 لایه Models
├── VisitorApp.ViewModels/          # 🎯 لایه ViewModels (MVVM)
├── VisitorApp.Views/               # 🎨 لایه Views (Razor Components)
├── VisitorApp.Web.Panel/           # 🌐 Admin Panel (WebAssembly)
├── VisitorApp.Web.PWA/             # 📱 PWA Application
└── VisitorApp.MAUI/                # 📱 MAUI Application (Android)
```

### 🎯 معماری MVVM

این پروژه از الگوی معماری **MVVM (Model-View-ViewModel)** استفاده می‌کند:

- **Model**: کلاس‌های داده و entities (`VisitorApp.Models`)
- **ViewModel**: منطق ارائه و binding (`VisitorApp.ViewModels`)
- **View**: رابط کاربری Razor Components (`VisitorApp.Views`)

### 📦 وابستگی‌ها

- **[CommunityToolkit.Mvvm](https://github.com/CommunityToolkit/dotnet)**: پیاده‌سازی MVVM pattern
- **[Radzen.Blazor](https://www.radzen.com/blazor-components/)**: کامپوننت‌های UI

## 🚀 راه‌اندازی

### پیش‌نیازها

- .NET 10 SDK
- Visual Studio 2022 یا VS Code

### اجرای پروژه‌ها

#### 🌐 Admin Panel (WebAssembly)
```bash
dotnet run --project VisitorApp.Web.Panel
```

#### 📱 PWA Application
```bash
dotnet run --project VisitorApp.Web.PWA
```

#### 📱 MAUI Application
```bash
dotnet run --project VisitorApp.MAUI
```

## 📋 نمونه‌های پیاده‌سازی شده

### Models
- `BaseEntity`: کلاس پایه برای تمام entities
- `User`: نمونه model برای کاربر
- `UserRole`: enum نقش‌های کاربری

### ViewModels
- `BaseViewModel`: کلاس پایه برای تمام ViewModels
- `UserViewModel`: نمونه ViewModel برای مدیریت کاربران

### Views
- `UserManagement`: نمونه component برای مدیریت کاربران

## 🎨 UI Components

پروژه از **Radzen Blazor Components** برای ساخت رابط کاربری استفاده می‌کند که شامل:

- DataGrid برای نمایش لیست‌ها
- Form Components برای ورودی‌های کاربر
- Layout Components برای چیدمان
- Theme Material Design

## 🏃‍♂️ Presentation Layers

### 1. **Admin Panel** (`VisitorApp.Web.Panel`)
- مناسب برای مدیریت و ادمین
- اجرا در مرورگر وب
- دسترسی کامل به تمام قابلیت‌ها

### 2. **PWA Application** (`VisitorApp.Web.PWA`)
- قابلیت نصب روی گوشی
- کار آفلاین
- مناسب برای کاربران عادی

### 3. **MAUI Application** (`VisitorApp.MAUI`)
- اپلیکیشن Native اندروید
- دسترسی به قابلیت‌های سیستم عامل
- عملکرد بهتر

## 🔧 توسعه

### اضافه کردن Model جدید

1. در `VisitorApp.Models` یک کلاس جدید بسازید:
```csharp
public class NewEntity : BaseEntity
{
    // Properties
}
```

### اضافه کردن ViewModel جدید

1. در `VisitorApp.ViewModels` یک ViewModel جدید بسازید:
```csharp
public partial class NewViewModel : BaseViewModel
{
    // ObservableProperty fields
    // RelayCommand methods
}
```

### اضافه کردن View جدید

1. در `VisitorApp.Views/Components` یک Razor Component جدید بسازید:
```razor
@using VisitorApp.ViewModels
@using Radzen.Blazor

<RadzenCard>
    <!-- UI Components -->
</RadzenCard>

@code {
    [Parameter] public NewViewModel ViewModel { get; set; } = default!;
}
```

## 📚 منابع یادگیری

- [Microsoft MVVM Documentation](https://docs.microsoft.com/en-us/dotnet/architecture/maui/mvvm)
- [CommunityToolkit.Mvvm Documentation](https://docs.microsoft.com/en-us/dotnet/communitytoolkit/mvvm/)
- [Radzen Blazor Components](https://blazor.radzen.com/)
- [Blazor Documentation](https://docs.microsoft.com/en-us/aspnet/core/blazor/)

---

## ✨ ویژگی‌های کلیدی

- ✅ **Clean Architecture**: جداسازی لایه‌ها
- ✅ **MVVM Pattern**: قابلیت تست و نگهداری بالا  
- ✅ **Multi-Platform**: وب، PWA، اندروید
- ✅ **Modern UI**: Radzen Components
- ✅ **Type-Safe**: استفاده از C# در تمام لایه‌ها
- ✅ **Reactive**: Community Toolkit MVVM

پروژه آماده برای توسعه و اضافه کردن قابلیت‌های جدید است! 🎉 