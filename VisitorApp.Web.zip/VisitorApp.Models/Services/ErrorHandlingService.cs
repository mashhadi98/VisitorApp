using System.Text.Json;
using VisitorApp.Models.Common;

namespace VisitorApp.Models.Services;

public class ErrorHandlingService : IErrorHandlingService
{
    private readonly JsonSerializerOptions _jsonOptions;
    
    public ErrorHandlingService()
    {
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            PropertyNameCaseInsensitive = true
        };
    }
    
    public async Task<ApiResponse<T>> HandleApiResponseAsync<T>(HttpResponseMessage response)
    {
        var content = await response.Content.ReadAsStringAsync();
        
        if (response.IsSuccessStatusCode)
        {
            try
            {
                if (typeof(T) == typeof(string))
                {
                    return new ApiResponse<T>
                    {
                        IsSuccess = true,
                        Data = (T)(object)content,
                        Message = "عملیات با موفقیت انجام شد"
                    };
                }
                
                var data = JsonSerializer.Deserialize<T>(content, _jsonOptions);
                return new ApiResponse<T>
                {
                    IsSuccess = true,
                    Data = data,
                    Message = "عملیات با موفقیت انجام شد"
                };
            }
            catch (JsonException)
            {
                return new ApiResponse<T>
                {
                    IsSuccess = false,
                    Message = "خطا در پردازش اطلاعات دریافتی از سرور",
                    Errors = new List<string> { "Invalid JSON response" }
                };
            }
        }
        
        // Handle error response
        var errorResponse = new ApiResponse<T>
        {
            IsSuccess = false,
            Message = GetUserFriendlyMessage($"HTTP {response.StatusCode}: {response.ReasonPhrase}")
        };
        
        try
        {
            // Try to parse backend error response
            var errorData = JsonSerializer.Deserialize<ApiResponse>(content, _jsonOptions);
            if (errorData != null)
            {
                errorResponse.Message = GetUserFriendlyMessage(errorData.Message ?? "خطای نامشخص");
                errorResponse.Errors = errorData.Errors?.Any() == true ? errorData.Errors : new List<string>();
            }
        }
        catch (JsonException)
        {
            // If can't parse error response, use HTTP status code
            errorResponse.Message = GetHttpStatusMessage(response.StatusCode);
        }
        
        LogError($"API Error: {response.StatusCode} - {content}");
        return errorResponse;
    }
    
    public string GetUserFriendlyMessage(string apiErrorMessage)
    {
        if (string.IsNullOrWhiteSpace(apiErrorMessage))
            return "خطای نامشخصی رخ داده است";
        
        // Map common API errors to Persian user-friendly messages
        var errorMappings = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            {"Unauthorized", "دسترسی غیرمجاز - لطفا مجدداً وارد شوید"},
            {"Forbidden", "عدم دسترسی کافی برای انجام این عملیات"},
            {"Not Found", "اطلاعات درخواستی یافت نشد"},
            {"Bad Request", "درخواست نامعتبر - لطفا اطلاعات را بررسی کنید"},
            {"Conflict", "تداخل در اطلاعات - این آیتم قبلاً وجود دارد"},
            {"Validation failed", "اطلاعات وارد شده صحیح نیست"},
            {"Invalid credentials", "نام کاربری یا رمز عبور اشتباه است"},
            {"Email already exists", "ایمیل وارد شده قبلاً ثبت شده است"},
            {"Internal Server Error", "خطای داخلی سرور - لطفا بعداً تلاش کنید"}
        };
        
        foreach (var mapping in errorMappings)
        {
            if (apiErrorMessage.Contains(mapping.Key, StringComparison.OrdinalIgnoreCase))
                return mapping.Value;
        }
        
        // If no specific mapping found, return the original message if it's in Persian or a generic message
        return ContainsPersianCharacters(apiErrorMessage) ? apiErrorMessage : "خطایی در انجام عملیات رخ داد";
    }
    
    public void LogError(string message, Exception? exception = null)
    {
        // TODO: Implement proper logging (Serilog, NLog, etc.)
        Console.WriteLine($"[ERROR] {DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}");
        if (exception != null)
        {
            Console.WriteLine($"Exception: {exception}");
        }
    }
    
    private string GetHttpStatusMessage(System.Net.HttpStatusCode statusCode)
    {
        return statusCode switch
        {
            System.Net.HttpStatusCode.BadRequest => "درخواست نامعتبر",
            System.Net.HttpStatusCode.Unauthorized => "دسترسی غیرمجاز",
            System.Net.HttpStatusCode.Forbidden => "عدم دسترسی کافی",
            System.Net.HttpStatusCode.NotFound => "یافت نشد",
            System.Net.HttpStatusCode.Conflict => "تداخل در اطلاعات",
            System.Net.HttpStatusCode.InternalServerError => "خطای داخلی سرور",
            System.Net.HttpStatusCode.BadGateway => "خطای ارتباط با سرور",
            System.Net.HttpStatusCode.ServiceUnavailable => "سرویس در دسترس نیست",
            System.Net.HttpStatusCode.RequestTimeout => "زمان درخواست به پایان رسید",
            _ => "خطای شبکه"
        };
    }
    
    private static bool ContainsPersianCharacters(string text)
    {
        return text.Any(c => c >= 0x0600 && c <= 0x06FF);
    }
} 