namespace VisitorApp.Models.Services;

public interface ITokenService
{
    Task SetTokensAsync(string accessToken, string refreshToken, DateTime expiresAt);
    Task<string?> GetAccessTokenAsync();
    Task<string?> GetRefreshTokenAsync();
    Task<DateTime?> GetTokenExpirationAsync();
    Task<bool> IsTokenValidAsync();
    Task ClearTokensAsync();
    Task<bool> HasValidTokenAsync();
} 