using VisitorApp.Models.Identity;

namespace VisitorApp.Models.Services;

public interface IAuthenticationService
{
    event Action<bool>? AuthenticationStateChanged;
    Task<bool> IsAuthenticatedAsync();
    Task<UserInfo?> GetCurrentUserAsync();
    Task LoginAsync(LoginResponse loginResponse);
    Task LogoutAsync();
    Task<bool> TryRefreshTokenAsync();
} 