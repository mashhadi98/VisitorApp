using System.Text;
using System.Text.Json;
using VisitorApp.Models.Catalog;
using VisitorApp.Models.Common;
using VisitorApp.Models.Configuration;
using VisitorApp.Models.Services;

namespace VisitorApp.Models.Repositories.Catalog;

public class ProductRepository : BaseRepository<ProductDto>, IProductRepository
{
    protected override string EndpointPath => "products";

    public ProductRepository(HttpClient httpClient, IErrorHandlingService errorHandlingService, IAppConfiguration configuration)
        : base(httpClient, errorHandlingService, configuration)
    {
    }

    public async Task<ApiResponse<List<DropdownDto>>> GetDropdownAsync()
    {
        try
        {
            var response = await _httpClient.GetAsync($"{EndpointPath}/dropdown");
            return await _errorHandlingService.HandleApiResponseAsync<List<DropdownDto>>(response);
        }
        catch (Exception ex)
        {
            _errorHandlingService.LogError("Exception in GetDropdownAsync for Products", ex);
            return new ApiResponse<List<DropdownDto>>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور",
                Data = new List<DropdownDto>()
            };
        }
    }

    public async Task<ApiResponse<string>> ChangeStateAsync(Guid id, bool isActive)
    {
        try
        {
            var request = new ChangeStateProductRequest { Id = id, IsActive = isActive };
            var json = JsonSerializer.Serialize(request, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PutAsync($"{EndpointPath}/change-state", content);
            return await _errorHandlingService.HandleApiResponseAsync<string>(response);
        }
        catch (Exception ex)
        {
            _errorHandlingService.LogError("Exception in ChangeStateAsync for Products", ex);
            return new ApiResponse<string>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }
} 