using VisitorApp.Models.Catalog;
using VisitorApp.Models.Common;

namespace VisitorApp.Models.Repositories.Catalog;

public interface IProductRepository : IBaseRepository<ProductDto>
{
    Task<ApiResponse<List<DropdownDto>>> GetDropdownAsync();
    Task<ApiResponse<string>> ChangeStateAsync(Guid id, bool isActive);
} 