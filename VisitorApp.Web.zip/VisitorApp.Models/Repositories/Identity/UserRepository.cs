using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using VisitorApp.Models.Identity;
using VisitorApp.Models.Common;
using VisitorApp.Models.Configuration;
using VisitorApp.Models.Services;

namespace VisitorApp.Models.Repositories.Identity;

public class UserRepository : IUserRepository
{
    protected readonly HttpClient HttpClient;
    protected readonly IErrorHandlingService ErrorHandler;
    protected readonly JsonSerializerOptions JsonOptions;
    protected readonly string ApiBaseUrl;

    public UserRepository(HttpClient httpClient, IAppConfiguration configuration, IErrorHandlingService errorHandler) 
    {
        HttpClient = httpClient;
        ErrorHandler = errorHandler;
        ApiBaseUrl = configuration.ApiBaseUrl;
        
        JsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            PropertyNameCaseInsensitive = true
        };
    }

    public async Task<ApiResponse<UserDto>> CreateAsync(CreateUserRequest request)
    {
        try
        {
            var json = JsonSerializer.Serialize(request, JsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await HttpClient.PostAsync($"{ApiBaseUrl}/users", content);
            
            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var user = JsonSerializer.Deserialize<UserDto>(responseContent, JsonOptions);
                return new ApiResponse<UserDto> { Data = user, IsSuccess = true };
            }
            
            return await ErrorHandler.HandleApiResponseAsync<UserDto>(response);
        }
        catch (Exception ex)
        {
            ErrorHandler.LogError($"Exception in CreateAsync for User", ex);
            return new ApiResponse<UserDto>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public async Task<ApiResponse<UserDto>> UpdateAsync(UpdateUserRequest request)
    {
        try
        {
            var json = JsonSerializer.Serialize(request, JsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await HttpClient.PutAsync($"{ApiBaseUrl}/users/{request.Id}", content);
            
            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var user = JsonSerializer.Deserialize<UserDto>(responseContent, JsonOptions);
                return new ApiResponse<UserDto> { Data = user, IsSuccess = true };
            }
            
            return await ErrorHandler.HandleApiResponseAsync<UserDto>(response);
        }
        catch (Exception ex)
        {
            ErrorHandler.LogError($"Exception in UpdateAsync for User", ex);
            return new ApiResponse<UserDto>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public async Task<ApiResponse> DeleteAsync(Guid id)
    {
        try
        {
            var response = await HttpClient.DeleteAsync($"{ApiBaseUrl}/users/{id}");
            
            if (response.IsSuccessStatusCode)
            {
                return new ApiResponse { IsSuccess = true, Message = "کاربر با موفقیت حذف شد" };
            }
            
            return await ErrorHandler.HandleApiResponseAsync<string>(response);
        }
        catch (Exception ex)
        {
            ErrorHandler.LogError($"Exception in DeleteAsync for User", ex);
            return new ApiResponse
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public async Task<ApiResponse<UserDto>> GetByIdAsync(Guid id)
    {
        try
        {
            var response = await HttpClient.GetAsync($"{ApiBaseUrl}/users/{id}");
            
            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var user = JsonSerializer.Deserialize<UserDto>(responseContent, JsonOptions);
                return new ApiResponse<UserDto> { Data = user, IsSuccess = true };
            }
            
            return await ErrorHandler.HandleApiResponseAsync<UserDto>(response);
        }
        catch (Exception ex)
        {
            ErrorHandler.LogError($"Exception in GetByIdAsync for User", ex);
            return new ApiResponse<UserDto>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public async Task<ApiResponse<PaginatedResponse<UserDto>>> GetPaginatedAsync(PaginatedRequest<UserFilter> request)
    {
        try
        {
            var queryParams = BuildQueryString(request);
            var response = await HttpClient.GetAsync($"{ApiBaseUrl}/users?{queryParams}");
            
            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var result = JsonSerializer.Deserialize<PaginatedResponse<UserDto>>(responseContent, JsonOptions);
                return new ApiResponse<PaginatedResponse<UserDto>> { Data = result, IsSuccess = true };
            }
            
            return await ErrorHandler.HandleApiResponseAsync<PaginatedResponse<UserDto>>(response);
        }
        catch (Exception ex)
        {
            ErrorHandler.LogError($"Exception in GetPaginatedAsync for User", ex);
            return new ApiResponse<PaginatedResponse<UserDto>>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public async Task<ApiResponse<UserDto>> ChangeStateAsync(ChangeUserStateRequest request)
    {
        try
        {
            var json = JsonSerializer.Serialize(request, JsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await HttpClient.PatchAsync($"{ApiBaseUrl}/users/{request.Id}/change-state", content);
            
            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var user = JsonSerializer.Deserialize<UserDto>(responseContent, JsonOptions);
                return new ApiResponse<UserDto> { Data = user, IsSuccess = true };
            }
            
            return await ErrorHandler.HandleApiResponseAsync<UserDto>(response);
        }
        catch (Exception ex)
        {
            ErrorHandler.LogError($"Exception in ChangeStateAsync for User", ex);
            return new ApiResponse<UserDto>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    private string BuildQueryString(PaginatedRequest<UserFilter> request)
    {
        var queryParams = new List<string>
        {
            $"Page={request.Page}",
            $"PageSize={request.PageSize}"
        };

        if (request.Filter != null)
        {
            if (!string.IsNullOrWhiteSpace(request.Filter.SearchTerm))
                queryParams.Add($"Filter.SearchTerm={Uri.EscapeDataString(request.Filter.SearchTerm)}");
            
            if (request.Filter.IsActive.HasValue)
                queryParams.Add($"Filter.IsActive={request.Filter.IsActive.Value}");
            
            if (!string.IsNullOrWhiteSpace(request.Filter.SortBy))
                queryParams.Add($"Filter.SortBy={request.Filter.SortBy}");
            
            queryParams.Add($"Filter.SortDescending={request.Filter.SortDescending}");
        }

        return string.Join("&", queryParams);
    }
} 