using VisitorApp.Models.Identity;
using VisitorApp.Models.Common;

namespace VisitorApp.Models.Repositories.Identity;

public interface IUserRepository
{
    Task<ApiResponse<UserDto>> CreateAsync(CreateUserRequest request);
    Task<ApiResponse<UserDto>> UpdateAsync(UpdateUserRequest request);
    Task<ApiResponse> DeleteAsync(Guid id);
    Task<ApiResponse<UserDto>> GetByIdAsync(Guid id);
    Task<ApiResponse<PaginatedResponse<UserDto>>> GetPaginatedAsync(PaginatedRequest<UserFilter> request);
    Task<ApiResponse<UserDto>> ChangeStateAsync(ChangeUserStateRequest request);
} 