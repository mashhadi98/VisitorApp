using System.Text;
using System.Text.Json;
using VisitorApp.Models.Common;
using VisitorApp.Models.Configuration;
using VisitorApp.Models.Identity;
using VisitorApp.Models.Services;

namespace VisitorApp.Models.Repositories.Identity;

public class IdentityRepository : IIdentityRepository
{
    private readonly HttpClient _httpClient;
    private readonly IErrorHandlingService _errorHandlingService;
    private readonly JsonSerializerOptions _jsonOptions;

    public IdentityRepository(HttpClient httpClient, IErrorHandlingService errorHandlingService, IAppConfiguration configuration)
    {
        _httpClient = httpClient;
        _errorHandlingService = errorHandlingService;
        
        // Configure HttpClient base address
        if (_httpClient.BaseAddress == null)
        {
            _httpClient.BaseAddress = new Uri(configuration.ApiBaseUrl);
        }
        
        // Set timeout
        _httpClient.Timeout = TimeSpan.FromSeconds(configuration.RequestTimeoutSeconds);
        
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            PropertyNameCaseInsensitive = true
        };
    }

    public async Task<ApiResponse<LoginResponse>> LoginAsync(LoginRequest request)
    {
        try
        {
            var json = JsonSerializer.Serialize(request, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync("identity/login", content);
            return await _errorHandlingService.HandleApiResponseAsync<LoginResponse>(response);
        }
        catch (Exception ex)
        {
            _errorHandlingService.LogError("Exception in LoginAsync", ex);
            return new ApiResponse<LoginResponse>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public async Task<ApiResponse<string>> RegisterAsync(RegisterRequest request)
    {
        try
        {
            var json = JsonSerializer.Serialize(request, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync("identity/register", content);
            return await _errorHandlingService.HandleApiResponseAsync<string>(response);
        }
        catch (Exception ex)
        {
            _errorHandlingService.LogError("Exception in RegisterAsync", ex);
            return new ApiResponse<string>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public async Task<ApiResponse<string>> LogoutAsync()
    {
        try
        {
            var response = await _httpClient.PostAsync("identity/logout", null);
            return await _errorHandlingService.HandleApiResponseAsync<string>(response);
        }
        catch (Exception ex)
        {
            _errorHandlingService.LogError("Exception in LogoutAsync", ex);
            return new ApiResponse<string>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public async Task<ApiResponse<LoginResponse>> RefreshTokenAsync(string refreshToken)
    {
        try
        {
            var json = JsonSerializer.Serialize(new { RefreshToken = refreshToken }, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync("identity/refresh-token", content);
            return await _errorHandlingService.HandleApiResponseAsync<LoginResponse>(response);
        }
        catch (Exception ex)
        {
            _errorHandlingService.LogError("Exception in RefreshTokenAsync", ex);
            return new ApiResponse<LoginResponse>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }
} 