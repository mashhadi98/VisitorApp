namespace VisitorApp.Models.Configuration;

public class AppSettings
{
    public const string SectionName = "AppSettings";
    
    public string ApiBaseUrl { get; set; } = "https://localhost:7001/api/";
    public int DefaultPageSize { get; set; } = 10;
    public int RequestTimeoutSeconds { get; set; } = 30;
}

public interface IAppConfiguration
{
    string ApiBaseUrl { get; }
    int DefaultPageSize { get; }
    int RequestTimeoutSeconds { get; }
}

public class AppConfiguration : IAppConfiguration
{
    private readonly AppSettings _settings;
    
    public AppConfiguration(AppSettings settings)
    {
        _settings = settings;
    }
    
    public string ApiBaseUrl => _settings.ApiBaseUrl;
    public int DefaultPageSize => _settings.DefaultPageSize;
    public int RequestTimeoutSeconds => _settings.RequestTimeoutSeconds;
} 