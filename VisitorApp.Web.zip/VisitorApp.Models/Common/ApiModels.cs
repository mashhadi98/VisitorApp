namespace VisitorApp.Models.Common;

public class ApiResponse
{
    public bool IsSuccess { get; set; }
    public string? Message { get; set; }
    public List<string> Errors { get; set; } = new();
}

public class ApiResponse<T> : ApiResponse
{
    public T? Data { get; set; }
}

public class PaginatedResponse<T>
{
    public List<T> Data { get; set; } = new();
    public int CurrentPage { get; set; }
    public int TotalPages { get; set; }
    public int TotalCount { get; set; }
    public int PageSize { get; set; }
    public bool HasNext { get; set; }
    public bool HasPrevious { get; set; }
}

public class DropdownDto
{
    public Guid Value { get; set; }
    public string Text { get; set; } = string.Empty;
}

public class PaginatedRequest
{
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 10;
}

public class PaginatedRequest<TFilter> : PaginatedRequest where TFilter : new()
{
    public TFilter Filter { get; set; } = new TFilter();
} 