using System.ComponentModel.DataAnnotations;
using VisitorApp.ViewModels.Common;
using VisitorApp.ViewModels.Common.Commands;
using VisitorApp.Models.Repositories.Catalog;
using VisitorApp.Models.Catalog;
using VisitorApp.Models.Common;

namespace VisitorApp.ViewModels.Catalog;

public class CategoryFormViewModel : BaseViewModel
{
    private readonly ICategoryRepository _categoryRepository;
    
    private Guid? _id;
    private string _name = string.Empty;
    private string? _description = string.Empty;
    private bool _isActive = true;
    private bool _isEditMode = false;

    public CategoryFormViewModel(ICategoryRepository categoryRepository)
    {
        _categoryRepository = categoryRepository;
        
        SaveCommand = new RelayCommand(async () => await SaveAsync(), () => !IsLoading && IsFormValid);
        CancelCommand = new RelayCommand(() => { /* Cancel logic will be handled in Razor component */ });
    }

    public Guid? Id
    {
        get => _id;
        set => SetProperty(ref _id, value);
    }

    [Required(ErrorMessage = "نام الزامی است")]
    [StringLength(200, ErrorMessage = "نام باید کمتر از 200 کاراکتر باشد")]
    public string Name
    {
        get => _name;
        set
        {
            SetProperty(ref _name, value);
            SaveCommand.NotifyCanExecuteChanged();
        }
    }

    [StringLength(1000, ErrorMessage = "توضیحات باید کمتر از 1000 کاراکتر باشد")]
    public string? Description
    {
        get => _description;
        set => SetProperty(ref _description, value);
    }

    public bool IsActive
    {
        get => _isActive;
        set => SetProperty(ref _isActive, value);
    }

    public bool IsEditMode
    {
        get => _isEditMode;
        set => SetProperty(ref _isEditMode, value);
    }

    public IRelayCommand SaveCommand { get; }
    public IRelayCommand CancelCommand { get; }

    private bool IsFormValid => !string.IsNullOrWhiteSpace(Name);

    public async Task InitializeAsync(Guid? categoryId = null)
    {
        if (categoryId.HasValue)
        {
            IsEditMode = true;
            await LoadCategoryAsync(categoryId.Value);
        }
    }

    private async Task LoadCategoryAsync(Guid categoryId)
    {
        try
        {
            IsLoading = true;
            ErrorMessage = string.Empty;

            var result = await _categoryRepository.GetByIdAsync(categoryId);
            
            if (result.IsSuccess && result.Data != null)
            {
                var category = result.Data;
                Id = category.Id;
                Name = category.Name;
                Description = category.Description;
                IsActive = category.IsActive;
            }
            else
            {
                ErrorMessage = result.Message ?? "دسته‌بندی یافت نشد";
            }
        }
        catch (Exception)
        {
            ErrorMessage = "خطا در بارگذاری اطلاعات دسته‌بندی";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task SaveAsync()
    {
        try
        {
            IsLoading = true;
            ErrorMessage = string.Empty;

            if (IsEditMode && Id.HasValue)
            {
                var updateRequest = new UpdateCategoryRequest
                {
                    Id = Id.Value,
                    Name = Name,
                    Description = Description,
                    IsActive = IsActive
                };

                var response = await _categoryRepository.UpdateAsync(Id.Value, updateRequest);
                if (!response.IsSuccess)
                {
                    ErrorMessage = response.Message ?? "خطا در بروزرسانی دسته‌بندی";
                }
            }
            else
            {
                var createRequest = new CreateCategoryRequest
                {
                    Name = Name,
                    Description = Description,
                    IsActive = IsActive
                };

                var response = await _categoryRepository.CreateAsync(createRequest);
                if (!response.IsSuccess)
                {
                    ErrorMessage = response.Message ?? "خطا در ایجاد دسته‌بندی";
                }
            }
        }
        catch (Exception)
        {
            ErrorMessage = "خطا در ذخیره اطلاعات دسته‌بندی";
        }
        finally
        {
            IsLoading = false;
        }
    }

    public void ResetForm()
    {
        Id = null;
        Name = string.Empty;
        Description = string.Empty;
        IsActive = true;
        IsEditMode = false;
        ErrorMessage = string.Empty;
    }
} 