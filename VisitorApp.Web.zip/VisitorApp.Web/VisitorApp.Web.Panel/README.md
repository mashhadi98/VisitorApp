# VisitorApp Panel - MVVM Blazor WebAssembly

یک پنل مدیریت مدرن برای VisitorApp که با استفاده از Blazor WebAssembly و معماری MVVM ساخته شده است.

## ویژگی‌های پروژه

### ✅ معماری و ساختار
- **معماری MVVM** (Model-View-ViewModel)
- **ساختار Feature-based** مشابه پروژه API
- **Dependency Injection** کامل
- **Command Pattern** برای اعمال کاربر
- **Separation of Concerns**

### ✅ UI/UX
- **Radzen Blazor Components** برای UI مدرن
- **Responsive Design** 
- **Sidebar Navigation** با منوی سلسله مراتبی
- **Loading States** و **Error Handling**
- **Confirmation Dialogs**

### ✅ ویژگی‌های پیاده‌سازی شده

#### 🔐 Identity Management
- **Login** - ورود کاربران
- **Register** - ثبت‌نام کاربران
- **Token Management** (آماده برای پیاده‌سازی)

#### 📦 Catalog Management
- **Products** - مدیریت محصولات
  - لیست محصولات با Pagination
  - ایجاد محصول جدید
  - ویرایش محصول
  - فعال/غیرفعال کردن محصول
  - حذف محصول
- **Categories** - مدیریت دسته‌بندی‌ها
  - لیست دسته‌بندی‌ها با Pagination
  - ایجاد دسته‌بندی جدید
  - ویرایش دسته‌بندی
  - فعال/غیرفعال کردن دسته‌بندی
  - حذف دسته‌بندی

#### 📊 Dashboard
- **نمای کلی** با آمار اصلی
- **Recent Activity Timeline**
- **Quick Actions** برای دسترسی سریع

## ساختار پروژه

```
VisitorApp.Web.Panel/
├── Common/                          # اجزای مشترک
│   ├── Commands/                    # Command Pattern Implementation
│   ├── Models/                      # مدل‌های مشترک (ApiResponse, PaginatedResponse)
│   ├── Services/                    # سرویس‌های مشترک (ApiService)
│   └── ViewModels/                  # BaseViewModel
├── Features/                        # Features اصلی (Feature-based)
│   ├── Identity/
│   │   ├── Login/
│   │   │   ├── LoginViewModel.cs
│   │   │   └── Login.razor
│   │   ├── Register/
│   │   │   ├── RegisterViewModel.cs
│   │   │   └── Register.razor
│   │   ├── Models/                  # مدل‌های Identity
│   │   └── Services/                # سرویس‌های Identity
│   └── Catalog/
│       ├── Products/
│       │   ├── ViewModels/
│       │   │   ├── ProductListViewModel.cs
│       │   │   └── ProductFormViewModel.cs
│       │   ├── ProductList.razor
│       │   ├── ProductForm.razor
│       │   ├── Models/
│       │   └── Services/
│       └── Categories/
│           ├── ViewModels/
│           │   ├── CategoryListViewModel.cs
│           │   └── CategoryFormViewModel.cs
│           ├── CategoryList.razor
│           ├── CategoryForm.razor
│           ├── Models/
│           └── Services/
├── Layout/                          # قالب‌ها و Layout
│   └── MainLayout.razor            # Layout اصلی با Radzen
├── Pages/                          # صفحات اصلی
│   ├── Home.razor                  # Dashboard
│   └── NotFound.razor              # صفحه 404
└── wwwroot/                        # فایل‌های استاتیک
```

## تنظیمات و راه‌اندازی

### پیش‌نیازها
- .NET 10.0 SDK
- Visual Studio 2025 یا VS Code
- پروژه API در حال اجرا

### تنظیم API Base URL
در فایل `Program.cs` آدرس API را تنظیم کنید:

```csharp
builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri("https://localhost:7001/api/") });
```

### اجرای پروژه
```bash
cd VisitorApp.Web/VisitorApp.Web.Panel
dotnet run
```

## استفاده از معماری MVVM

### ViewModel Pattern
```csharp
public class ProductListViewModel : BaseViewModel
{
    private readonly IProductService _productService;
    
    // Properties با INotifyPropertyChanged
    public string Title 
    { 
        get => _title;
        set => SetProperty(ref _title, value);
    }
    
    // Commands برای اعمال کاربر
    public IRelayCommand LoadDataCommand { get; }
    
    // Methods برای منطق کسب‌وکار
    private async Task LoadDataAsync() { ... }
}
```

### View (Razor Component)
```razor
@inject ProductListViewModel ViewModel

<RadzenDataGrid Data="@ViewModel.Products" 
                IsLoading="@ViewModel.IsLoading">
    <!-- Grid columns -->
</RadzenDataGrid>

@code {
    protected override async Task OnInitializedAsync()
    {
        await ViewModel.InitializeAsync();
    }
}
```

## API Integration

### Base URLs مطابق API
- **Products**: `/products` (GET, POST, PUT, DELETE, PATCH)
- **Categories**: `/categories` (GET, POST, PUT, DELETE, PATCH)
- **Identity**: `/identity/login`, `/identity/register`

### HTTP Methods مطابق Endpoint Types
- `PostEndpoint` → POST
- `GetEndpoint` → GET  
- `PutEndpoint` → PUT
- `DeleteEndpoint` → DELETE
- `PatchEndpoint` → PATCH
- `PaginatedEndpoint` → GET با Pagination

## کامپوننت‌های UI

### Radzen Components استفاده شده
- `RadzenDataGrid` - جداول داده
- `RadzenCard` - کارت‌ها
- `RadzenButton` - دکمه‌ها  
- `RadzenTextBox`, `RadzenPassword` - فیلدهای ورودی
- `RadzenDropDown` - لیست کشویی
- `RadzenAlert` - پیام‌های هشدار
- `RadzenDialog` - دیالوگ‌های تأیید
- `RadzenSidebar`, `RadzenPanelMenu` - منوی کناری

## نکات توسعه

### اضافه کردن Feature جدید
1. پوشه Feature را در `Features/` ایجاد کنید
2. مدل‌ها را در `Models/` تعریف کنید
3. سرویس Interface و Implementation ایجاد کنید
4. ViewModel(ها) را پیاده‌سازی کنید
5. Razor Component(ها) را ایجاد کنید
6. در `Program.cs` سرویس‌ها و ViewModel‌ها را Register کنید

### Command Pattern
```csharp
// در ViewModel
SaveCommand = new RelayCommand(async () => await SaveAsync(), () => IsFormValid);

// در Razor Component
<RadzenButton Click="@(async () => await ViewModel.SaveCommand.ExecuteAsync())" />
```

## مزایای معماری

### ✅ Testability
- ViewModel‌ها کاملاً قابل تست هستند
- جداسازی منطق کسب‌وکار از UI

### ✅ Maintainability  
- کد سازمان‌یافته و خوانا
- Separation of Concerns

### ✅ Reusability
- Component‌های قابل استفاده مجدد
- Base Classes مشترک

### ✅ Scalability
- ساختار Feature-based
- Dependency Injection

## لایسنس
© 2025 Visitor App. All rights reserved. 