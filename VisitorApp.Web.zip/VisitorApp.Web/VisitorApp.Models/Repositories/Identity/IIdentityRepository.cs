using VisitorApp.Models.Common;
using VisitorApp.Models.Identity;

namespace VisitorApp.Models.Repositories.Identity;

public interface IIdentityRepository
{
    Task<ApiResponse<LoginResponse>> LoginAsync(LoginRequest request);
    Task<ApiResponse<string>> RegisterAsync(RegisterRequest request);
    Task<ApiResponse<string>> LogoutAsync();
    Task<ApiResponse<LoginResponse>> RefreshTokenAsync(string refreshToken);
} 