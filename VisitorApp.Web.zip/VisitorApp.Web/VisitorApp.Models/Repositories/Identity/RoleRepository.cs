using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using VisitorApp.Models.Identity;
using VisitorApp.Models.Common;
using VisitorApp.Models.Configuration;
using VisitorApp.Models.Services;

namespace VisitorApp.Models.Repositories.Identity;

public class RoleRepository : IRoleRepository
{
    protected readonly HttpClient HttpClient;
    protected readonly IErrorHandlingService ErrorHandler;
    protected readonly JsonSerializerOptions JsonOptions;
    protected readonly string ApiBaseUrl;

    public RoleRepository(HttpClient httpClient, IAppConfiguration configuration, IErrorHandlingService errorHandler) 
    {
        HttpClient = httpClient;
        ErrorHandler = errorHandler;
        ApiBaseUrl = configuration.ApiBaseUrl;
        
        JsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            PropertyNameCaseInsensitive = true
        };
    }

    public async Task<ApiResponse<RoleDto>> CreateAsync(CreateRoleRequest request)
    {
        try
        {
            var json = JsonSerializer.Serialize(request, JsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await HttpClient.PostAsync($"{ApiBaseUrl}/roles", content);
            
            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var role = JsonSerializer.Deserialize<RoleDto>(responseContent, JsonOptions);
                return new ApiResponse<RoleDto> { Data = role, IsSuccess = true };
            }
            
            return await ErrorHandler.HandleApiResponseAsync<RoleDto>(response);
        }
        catch (Exception ex)
        {
            ErrorHandler.LogError($"Exception in CreateAsync for Role", ex);
            return new ApiResponse<RoleDto>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public async Task<ApiResponse<RoleDto>> UpdateAsync(UpdateRoleRequest request)
    {
        try
        {
            var json = JsonSerializer.Serialize(request, JsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await HttpClient.PutAsync($"{ApiBaseUrl}/roles/{request.Id}", content);
            
            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var role = JsonSerializer.Deserialize<RoleDto>(responseContent, JsonOptions);
                return new ApiResponse<RoleDto> { Data = role, IsSuccess = true };
            }
            
            return await ErrorHandler.HandleApiResponseAsync<RoleDto>(response);
        }
        catch (Exception ex)
        {
            ErrorHandler.LogError($"Exception in UpdateAsync for Role", ex);
            return new ApiResponse<RoleDto>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public async Task<ApiResponse> DeleteAsync(Guid id)
    {
        try
        {
            var response = await HttpClient.DeleteAsync($"{ApiBaseUrl}/roles/{id}");
            
            if (response.IsSuccessStatusCode)
            {
                return new ApiResponse { IsSuccess = true, Message = "نقش با موفقیت حذف شد" };
            }
            
            return await ErrorHandler.HandleApiResponseAsync<string>(response);
        }
        catch (Exception ex)
        {
            ErrorHandler.LogError($"Exception in DeleteAsync for Role", ex);
            return new ApiResponse
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public async Task<ApiResponse<RoleDto>> GetByIdAsync(Guid id)
    {
        try
        {
            var response = await HttpClient.GetAsync($"{ApiBaseUrl}/roles/{id}");
            
            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var role = JsonSerializer.Deserialize<RoleDto>(responseContent, JsonOptions);
                return new ApiResponse<RoleDto> { Data = role, IsSuccess = true };
            }
            
            return await ErrorHandler.HandleApiResponseAsync<RoleDto>(response);
        }
        catch (Exception ex)
        {
            ErrorHandler.LogError($"Exception in GetByIdAsync for Role", ex);
            return new ApiResponse<RoleDto>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public async Task<ApiResponse<PaginatedResponse<RoleDto>>> GetPaginatedAsync(PaginatedRequest<RoleFilter> request)
    {
        try
        {
            var queryParams = BuildQueryString(request);
            var response = await HttpClient.GetAsync($"{ApiBaseUrl}/roles?{queryParams}");
            
            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var result = JsonSerializer.Deserialize<PaginatedResponse<RoleDto>>(responseContent, JsonOptions);
                return new ApiResponse<PaginatedResponse<RoleDto>> { Data = result, IsSuccess = true };
            }
            
            return await ErrorHandler.HandleApiResponseAsync<PaginatedResponse<RoleDto>>(response);
        }
        catch (Exception ex)
        {
            ErrorHandler.LogError($"Exception in GetPaginatedAsync for Role", ex);
            return new ApiResponse<PaginatedResponse<RoleDto>>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public async Task<ApiResponse<RoleDto>> ChangeStateAsync(ChangeRoleStateRequest request)
    {
        try
        {
            var json = JsonSerializer.Serialize(request, JsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await HttpClient.PatchAsync($"{ApiBaseUrl}/roles/{request.Id}/change-state", content);
            
            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();
                var role = JsonSerializer.Deserialize<RoleDto>(responseContent, JsonOptions);
                return new ApiResponse<RoleDto> { Data = role, IsSuccess = true };
            }
            
            return await ErrorHandler.HandleApiResponseAsync<RoleDto>(response);
        }
        catch (Exception ex)
        {
            ErrorHandler.LogError($"Exception in ChangeStateAsync for Role", ex);
            return new ApiResponse<RoleDto>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    private string BuildQueryString(PaginatedRequest<RoleFilter> request)
    {
        var queryParams = new List<string>
        {
            $"Page={request.Page}",
            $"PageSize={request.PageSize}"
        };

        if (request.Filter != null)
        {
            if (!string.IsNullOrWhiteSpace(request.Filter.SearchTerm))
                queryParams.Add($"Filter.SearchTerm={Uri.EscapeDataString(request.Filter.SearchTerm)}");
            
            if (request.Filter.IsActive.HasValue)
                queryParams.Add($"Filter.IsActive={request.Filter.IsActive.Value}");
            
            if (!string.IsNullOrWhiteSpace(request.Filter.SortBy))
                queryParams.Add($"Filter.SortBy={request.Filter.SortBy}");
            
            queryParams.Add($"Filter.SortDescending={request.Filter.SortDescending}");
        }

        return string.Join("&", queryParams);
    }
} 