using VisitorApp.Models.Identity;
using VisitorApp.Models.Common;

namespace VisitorApp.Models.Repositories.Identity;

public interface IRoleRepository
{
    Task<ApiResponse<RoleDto>> CreateAsync(CreateRoleRequest request);
    Task<ApiResponse<RoleDto>> UpdateAsync(UpdateRoleRequest request);
    Task<ApiResponse> DeleteAsync(Guid id);
    Task<ApiResponse<RoleDto>> GetByIdAsync(Guid id);
    Task<ApiResponse<PaginatedResponse<RoleDto>>> GetPaginatedAsync(PaginatedRequest<RoleFilter> request);
    Task<ApiResponse<RoleDto>> ChangeStateAsync(ChangeRoleStateRequest request);
} 