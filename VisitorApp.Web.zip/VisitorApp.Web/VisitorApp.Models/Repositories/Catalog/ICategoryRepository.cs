using VisitorApp.Models.Catalog;
using VisitorApp.Models.Common;

namespace VisitorApp.Models.Repositories.Catalog;

public interface ICategoryRepository : IBaseRepository<CategoryDto>
{
    Task<ApiResponse<List<DropdownDto>>> GetDropdownAsync();
    Task<ApiResponse<string>> ChangeStateAsync(Guid id, bool isActive);
} 