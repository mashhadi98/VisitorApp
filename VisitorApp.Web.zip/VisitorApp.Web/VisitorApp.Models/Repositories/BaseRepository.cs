using System.Text;
using System.Text.Json;
using VisitorApp.Models.Common;
using VisitorApp.Models.Configuration;
using VisitorApp.Models.Services;

namespace VisitorApp.Models.Repositories;

public abstract class BaseRepository<T> : IBaseRepository<T> where T : class
{
    protected readonly HttpClient _httpClient;
    protected readonly IErrorHandlingService _errorHandlingService;
    protected readonly JsonSerializerOptions _jsonOptions;
    protected abstract string EndpointPath { get; }

    protected BaseRepository(HttpClient httpClient, IErrorHandlingService errorHandlingService, IAppConfiguration configuration)
    {
        _httpClient = httpClient;
        _errorHandlingService = errorHandlingService;
        
        // Configure HttpClient base address
        if (_httpClient.BaseAddress == null)
        {
            _httpClient.BaseAddress = new Uri(configuration.ApiBaseUrl);
        }
        
        // Set timeout
        _httpClient.Timeout = TimeSpan.FromSeconds(configuration.RequestTimeoutSeconds);
        
        _jsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
            PropertyNameCaseInsensitive = true
        };
    }

    public virtual async Task<PaginatedResponse<T>> GetPaginatedAsync(int page = 1, int pageSize = 10)
    {
        try
        {
            var url = $"{EndpointPath}?page={page}&pageSize={pageSize}";
            var response = await _httpClient.GetAsync(url);
            
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return JsonSerializer.Deserialize<PaginatedResponse<T>>(content, _jsonOptions) ?? new PaginatedResponse<T>();
            }
            
            _errorHandlingService.LogError($"Failed to get paginated {typeof(T).Name}: {response.StatusCode}");
            return new PaginatedResponse<T>();
        }
        catch (Exception ex)
        {
            _errorHandlingService.LogError($"Exception in GetPaginatedAsync for {typeof(T).Name}", ex);
            return new PaginatedResponse<T>();
        }
    }

    public virtual async Task<ApiResponse<T>> GetByIdAsync(Guid id)
    {
        try
        {
            var response = await _httpClient.GetAsync($"{EndpointPath}/{id}");
            return await _errorHandlingService.HandleApiResponseAsync<T>(response);
        }
        catch (Exception ex)
        {
            _errorHandlingService.LogError($"Exception in GetByIdAsync for {typeof(T).Name}", ex);
            return new ApiResponse<T>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public virtual async Task<ApiResponse<T>> CreateAsync(object request)
    {
        try
        {
            var json = JsonSerializer.Serialize(request, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PostAsync(EndpointPath, content);
            return await _errorHandlingService.HandleApiResponseAsync<T>(response);
        }
        catch (Exception ex)
        {
            _errorHandlingService.LogError($"Exception in CreateAsync for {typeof(T).Name}", ex);
            return new ApiResponse<T>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public virtual async Task<ApiResponse<T>> UpdateAsync(Guid id, object request)
    {
        try
        {
            var json = JsonSerializer.Serialize(request, _jsonOptions);
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            
            var response = await _httpClient.PutAsync($"{EndpointPath}/{id}", content);
            return await _errorHandlingService.HandleApiResponseAsync<T>(response);
        }
        catch (Exception ex)
        {
            _errorHandlingService.LogError($"Exception in UpdateAsync for {typeof(T).Name}", ex);
            return new ApiResponse<T>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }

    public virtual async Task<ApiResponse<string>> DeleteAsync(Guid id)
    {
        try
        {
            var response = await _httpClient.DeleteAsync($"{EndpointPath}/{id}");
            return await _errorHandlingService.HandleApiResponseAsync<string>(response);
        }
        catch (Exception ex)
        {
            _errorHandlingService.LogError($"Exception in DeleteAsync for {typeof(T).Name}", ex);
            return new ApiResponse<string>
            {
                IsSuccess = false,
                Message = "خطا در ارتباط با سرور"
            };
        }
    }
} 