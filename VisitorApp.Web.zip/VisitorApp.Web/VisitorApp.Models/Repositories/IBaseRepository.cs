using VisitorApp.Models.Common;

namespace VisitorApp.Models.Repositories;

public interface IBaseRepository<T, in TKey> where T : class
{
    Task<PaginatedResponse<T>> GetPaginatedAsync(int page = 1, int pageSize = 10);
    Task<ApiResponse<T>> GetByIdAsync(TKey id);
    Task<ApiResponse<T>> CreateAsync(object request);
    Task<ApiResponse<T>> UpdateAsync(TKey id, object request);
    Task<ApiResponse<string>> DeleteAsync(TKey id);
}

public interface IBaseRepository<T> : IBaseRepository<T, Guid> where T : class
{
} 