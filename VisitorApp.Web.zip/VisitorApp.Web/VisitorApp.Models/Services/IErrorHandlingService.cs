using VisitorApp.Models.Common;

namespace VisitorApp.Models.Services;

public interface IErrorHandlingService
{
    Task<ApiResponse<T>> HandleApiResponseAsync<T>(HttpResponseMessage response);
    string GetUserFriendlyMessage(string apiErrorMessage);
    void LogError(string message, Exception? exception = null);
} 