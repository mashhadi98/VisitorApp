using VisitorApp.ViewModels.Common;
using VisitorApp.ViewModels.Common.Commands;
using VisitorApp.Models.Identity;
using VisitorApp.Models.Repositories.Identity;
using VisitorApp.Models.Common;
using System.Collections.ObjectModel;

namespace VisitorApp.ViewModels;

public class UserViewModel : BaseViewModel
{
    private readonly IUserRepository _userRepository;
    
    private string _firstName = string.Empty;
    private string _lastName = string.Empty;
    private string _email = string.Empty;
    private string _phoneNumber = string.Empty;
    private bool _isActive = true;
    private string _searchTerm = string.Empty;
    private bool? _filterIsActive = null;
    private int _currentPage = 1;
    private int _pageSize = 10;
    private int _totalCount = 0;
    
    private ObservableCollection<UserDto> _users = new();
    private UserDto? _selectedUser;

    public UserViewModel(IUserRepository userRepository)
    {
        _userRepository = userRepository;
        
        LoadUsersCommand = new RelayCommand(async () => await LoadUsersAsync());
        SaveUserCommand = new RelayCommand(async () => await SaveUserAsync(), () => CanSaveUser());
        UpdateUserCommand = new RelayCommand<UserDto>(async (user) => await UpdateUserAsync(user));
        DeleteUserCommand = new RelayCommand<UserDto>(async (user) => await DeleteUserAsync(user));
        ToggleUserStateCommand = new RelayCommand<UserDto>(async (user) => await ToggleUserStateAsync(user));
        ClearFormCommand = new RelayCommand(() => ClearForm());
        SearchCommand = new RelayCommand(async () => await SearchUsersAsync());
        NextPageCommand = new RelayCommand(async () => await NextPageAsync(), () => CanGoNextPage());
        PrevPageCommand = new RelayCommand(async () => await PrevPageAsync(), () => CanGoPrevPage());
    }

    public string FirstName
    {
        get => _firstName;
        set => SetProperty(ref _firstName, value);
    }

    public string LastName
    {
        get => _lastName;
        set => SetProperty(ref _lastName, value);
    }

    public string Email
    {
        get => _email;
        set => SetProperty(ref _email, value);
    }

    public string PhoneNumber
    {
        get => _phoneNumber;
        set => SetProperty(ref _phoneNumber, value);
    }

    public bool IsActive
    {
        get => _isActive;
        set => SetProperty(ref _isActive, value);
    }

    public string SearchTerm
    {
        get => _searchTerm;
        set => SetProperty(ref _searchTerm, value);
    }

    public bool? FilterIsActive
    {
        get => _filterIsActive;
        set => SetProperty(ref _filterIsActive, value);
    }

    public int CurrentPage
    {
        get => _currentPage;
        set => SetProperty(ref _currentPage, value);
    }

    public int PageSize
    {
        get => _pageSize;
        set => SetProperty(ref _pageSize, value);
    }

    public int TotalCount
    {
        get => _totalCount;
        set => SetProperty(ref _totalCount, value);
    }

    public int TotalPages => (int)Math.Ceiling((double)TotalCount / PageSize);

    public ObservableCollection<UserDto> Users
    {
        get => _users;
        set => SetProperty(ref _users, value);
    }

    public UserDto? SelectedUser
    {
        get => _selectedUser;
        set 
        { 
            SetProperty(ref _selectedUser, value);
            if (value != null)
            {
                LoadUserForEdit(value);
            }
        }
    }

    // Commands
    public RelayCommand LoadUsersCommand { get; }
    public RelayCommand SaveUserCommand { get; }
    public RelayCommand<UserDto> UpdateUserCommand { get; }
    public RelayCommand<UserDto> DeleteUserCommand { get; }
    public RelayCommand<UserDto> ToggleUserStateCommand { get; }
    public RelayCommand ClearFormCommand { get; }
    public RelayCommand SearchCommand { get; }
    public RelayCommand NextPageCommand { get; }
    public RelayCommand PrevPageCommand { get; }

    private async Task LoadUsersAsync()
    {
        if (IsLoading) return;

        IsLoading = true;
        ErrorMessage = string.Empty;
        
        try
        {
            var request = new PaginatedRequest<UserFilter>
            {
                Page = CurrentPage,
                PageSize = PageSize,
                Filter = new UserFilter
                {
                    SearchTerm = SearchTerm,
                    IsActive = FilterIsActive
                }
            };

            var response = await _userRepository.GetPaginatedAsync(request);
            
            if (response.IsSuccess && response.Data != null)
            {
                Users.Clear();
                foreach (var user in response.Data.Data)
                {
                    Users.Add(user);
                }
                TotalCount = response.Data.TotalCount;
            }
            else
            {
                ErrorMessage = response.Message ?? "خطا در بارگذاری کاربران";
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = $"خطا در بارگذاری کاربران: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task SaveUserAsync()
    {
        if (IsLoading || !CanSaveUser()) 
            return;

        IsLoading = true;
        ErrorMessage = string.Empty;
        
        try
        {
            var request = new CreateUserRequest
            {
                Email = Email,
                FirstName = FirstName,
                LastName = LastName,
                PhoneNumber = PhoneNumber,
                IsActive = IsActive
            };

            var response = await _userRepository.CreateAsync(request);
            
            if (response.IsSuccess)
            {
                await LoadUsersAsync();
                ClearForm();
                SuccessMessage = "کاربر با موفقیت ایجاد شد";
            }
            else
            {
                ErrorMessage = response.Message ?? "خطا در ایجاد کاربر";
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = $"خطا در ایجاد کاربر: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task UpdateUserAsync(UserDto? user)
    {
        if (IsLoading || user == null) return;

        IsLoading = true;
        ErrorMessage = string.Empty;
        
        try
        {
            var request = new UpdateUserRequest
            {
                Id = user.Id,
                FirstName = FirstName,
                LastName = LastName,
                PhoneNumber = PhoneNumber,
                IsActive = IsActive
            };

            var response = await _userRepository.UpdateAsync(request);
            
            if (response.IsSuccess)
            {
                await LoadUsersAsync();
                ClearForm();
                SuccessMessage = "کاربر با موفقیت به‌روزرسانی شد";
            }
            else
            {
                ErrorMessage = response.Message ?? "خطا در به‌روزرسانی کاربر";
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = $"خطا در به‌روزرسانی کاربر: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task DeleteUserAsync(UserDto? user)
    {
        if (IsLoading || user == null) return;

        IsLoading = true;
        ErrorMessage = string.Empty;
        
        try
        {
            var response = await _userRepository.DeleteAsync(user.Id);
            
            if (response.IsSuccess)
            {
                await LoadUsersAsync();
                SuccessMessage = "کاربر با موفقیت حذف شد";
            }
            else
            {
                ErrorMessage = response.Message ?? "خطا در حذف کاربر";
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = $"خطا در حذف کاربر: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task ToggleUserStateAsync(UserDto? user)
    {
        if (IsLoading || user == null) return;

        IsLoading = true;
        ErrorMessage = string.Empty;
        
        try
        {
            var request = new ChangeUserStateRequest
            {
                Id = user.Id,
                IsActive = !user.IsActive
            };

            var response = await _userRepository.ChangeStateAsync(request);
            
            if (response.IsSuccess)
            {
                await LoadUsersAsync();
                SuccessMessage = user.IsActive ? "کاربر غیرفعال شد" : "کاربر فعال شد";
            }
            else
            {
                ErrorMessage = response.Message ?? "خطا در تغییر وضعیت کاربر";
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = $"خطا در تغییر وضعیت کاربر: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task SearchUsersAsync()
    {
        CurrentPage = 1;
        await LoadUsersAsync();
    }

    private async Task NextPageAsync()
    {
        if (CanGoNextPage())
        {
            CurrentPage++;
            await LoadUsersAsync();
        }
    }

    private async Task PrevPageAsync()
    {
        if (CanGoPrevPage())
        {
            CurrentPage--;
            await LoadUsersAsync();
        }
    }

    private bool CanSaveUser()
    {
        return !string.IsNullOrWhiteSpace(FirstName) && 
               !string.IsNullOrWhiteSpace(LastName) && 
               !string.IsNullOrWhiteSpace(Email);
    }

    private bool CanGoNextPage()
    {
        return CurrentPage < TotalPages;
    }

    private bool CanGoPrevPage()
    {
        return CurrentPage > 1;
    }

    private void LoadUserForEdit(UserDto user)
    {
        FirstName = user.FirstName;
        LastName = user.LastName;
        Email = user.Email;
        PhoneNumber = user.PhoneNumber ?? string.Empty;
        IsActive = user.IsActive;
    }

    private void ClearForm()
    {
        FirstName = string.Empty;
        LastName = string.Empty;
        Email = string.Empty;
        PhoneNumber = string.Empty;
        IsActive = true;
        SelectedUser = null;
    }
} 