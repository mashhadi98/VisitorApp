using System.ComponentModel.DataAnnotations;
using VisitorApp.ViewModels.Common;
using VisitorApp.ViewModels.Common.Commands;
using VisitorApp.Models.Repositories.Identity;
using VisitorApp.Models.Identity;

namespace VisitorApp.ViewModels.Identity;

public class RegisterViewModel : BaseViewModel
{
    private readonly IIdentityRepository _identityRepository;
    private string _email = string.Empty;
    private string _password = string.Empty;
    private string _confirmPassword = string.Empty;
    private string _firstName = string.Empty;
    private string _lastName = string.Empty;

    public RegisterViewModel(IIdentityRepository identityRepository)
    {
        _identityRepository = identityRepository;
        RegisterCommand = new RelayCommand(async () => await RegisterAsync(), () => !IsLoading && IsFormValid);
    }

    [Required(ErrorMessage = "ایمیل الزامی است")]
    [EmailAddress(ErrorMessage = "فرمت ایمیل نامعتبر است")]
    public string Email
    {
        get => _email;
        set
        {
            SetProperty(ref _email, value);
            RegisterCommand.NotifyCanExecuteChanged();
        }
    }

    [Required(ErrorMessage = "رمز عبور الزامی است")]
    [MinLength(6, ErrorMessage = "رمز عبور باید حداقل 6 کاراکتر باشد")]
    public string Password
    {
        get => _password;
        set
        {
            SetProperty(ref _password, value);
            RegisterCommand.NotifyCanExecuteChanged();
        }
    }

    [Required(ErrorMessage = "تایید رمز عبور الزامی است")]
    public string ConfirmPassword
    {
        get => _confirmPassword;
        set
        {
            SetProperty(ref _confirmPassword, value);
            RegisterCommand.NotifyCanExecuteChanged();
        }
    }

    [Required(ErrorMessage = "نام الزامی است")]
    public string FirstName
    {
        get => _firstName;
        set
        {
            SetProperty(ref _firstName, value);
            RegisterCommand.NotifyCanExecuteChanged();
        }
    }

    [Required(ErrorMessage = "نام خانوادگی الزامی است")]
    public string LastName
    {
        get => _lastName;
        set
        {
            SetProperty(ref _lastName, value);
            RegisterCommand.NotifyCanExecuteChanged();
        }
    }

    public IRelayCommand RegisterCommand { get; }

    private bool IsFormValid => 
        !string.IsNullOrWhiteSpace(Email) && 
        !string.IsNullOrWhiteSpace(Password) && 
        !string.IsNullOrWhiteSpace(ConfirmPassword) &&
        !string.IsNullOrWhiteSpace(FirstName) &&
        !string.IsNullOrWhiteSpace(LastName) &&
        Password.Length >= 6 &&
        Password == ConfirmPassword;

    private async Task RegisterAsync()
    {
        try
        {
            IsLoading = true;
            ErrorMessage = string.Empty;

            if (Password != ConfirmPassword)
            {
                ErrorMessage = "رمز عبور و تایید آن یکسان نیستند";
                return;
            }

            var request = new RegisterRequest
            {
                Email = Email,
                Password = Password,
                ConfirmPassword = ConfirmPassword,
                FirstName = FirstName,
                LastName = LastName
            };

            var response = await _identityRepository.RegisterAsync(request);
            
            if (!response.IsSuccess)
            {
                ErrorMessage = response.Message ?? "خطا در ثبت‌نام";
            }
        }
        catch (Exception)
        {
            ErrorMessage = "خطای نامشخص در ثبت‌نام";
        }
        finally
        {
            IsLoading = false;
        }
    }
    
    public bool CanRegister => !IsLoading && IsFormValid;
} 