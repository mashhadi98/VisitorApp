using VisitorApp.ViewModels.Common;
using VisitorApp.ViewModels.Common.Commands;
using VisitorApp.Models.Identity;
using VisitorApp.Models.Repositories.Identity;
using VisitorApp.Models.Common;
using System.Collections.ObjectModel;

namespace VisitorApp.ViewModels.Identity;

public class RoleViewModel : BaseViewModel
{
    private readonly IRoleRepository _roleRepository;
    
    private string _name = string.Empty;
    private string _description = string.Empty;
    private bool _isActive = true;
    private string _searchTerm = string.Empty;
    private bool? _filterIsActive = null;
    private int _currentPage = 1;
    private int _pageSize = 10;
    private int _totalCount = 0;
    
    private ObservableCollection<RoleDto> _roles = new();
    private RoleDto? _selectedRole;

    public RoleViewModel(IRoleRepository roleRepository)
    {
        _roleRepository = roleRepository;
        
        LoadRolesCommand = new RelayCommand(async () => await LoadRolesAsync());
        SaveRoleCommand = new RelayCommand(async () => await SaveRoleAsync(), () => CanSaveRole());
        UpdateRoleCommand = new RelayCommand<RoleDto>(async (role) => await UpdateRoleAsync(role));
        DeleteRoleCommand = new RelayCommand<RoleDto>(async (role) => await DeleteRoleAsync(role));
        ToggleRoleStateCommand = new RelayCommand<RoleDto>(async (role) => await ToggleRoleStateAsync(role));
        ClearFormCommand = new RelayCommand(() => ClearForm());
        SearchCommand = new RelayCommand(async () => await SearchRolesAsync());
        NextPageCommand = new RelayCommand(async () => await NextPageAsync(), () => CanGoNextPage());
        PrevPageCommand = new RelayCommand(async () => await PrevPageAsync(), () => CanGoPrevPage());
    }

    public string Name
    {
        get => _name;
        set => SetProperty(ref _name, value);
    }

    public string Description
    {
        get => _description;
        set => SetProperty(ref _description, value);
    }

    public bool IsActive
    {
        get => _isActive;
        set => SetProperty(ref _isActive, value);
    }

    public string SearchTerm
    {
        get => _searchTerm;
        set => SetProperty(ref _searchTerm, value);
    }

    public bool? FilterIsActive
    {
        get => _filterIsActive;
        set => SetProperty(ref _filterIsActive, value);
    }

    public int CurrentPage
    {
        get => _currentPage;
        set => SetProperty(ref _currentPage, value);
    }

    public int PageSize
    {
        get => _pageSize;
        set => SetProperty(ref _pageSize, value);
    }

    public int TotalCount
    {
        get => _totalCount;
        set => SetProperty(ref _totalCount, value);
    }

    public int TotalPages => (int)Math.Ceiling((double)TotalCount / PageSize);

    public ObservableCollection<RoleDto> Roles
    {
        get => _roles;
        set => SetProperty(ref _roles, value);
    }

    public RoleDto? SelectedRole
    {
        get => _selectedRole;
        set 
        { 
            SetProperty(ref _selectedRole, value);
            if (value != null)
            {
                LoadRoleForEdit(value);
            }
        }
    }

    // Commands
    public RelayCommand LoadRolesCommand { get; }
    public RelayCommand SaveRoleCommand { get; }
    public RelayCommand<RoleDto> UpdateRoleCommand { get; }
    public RelayCommand<RoleDto> DeleteRoleCommand { get; }
    public RelayCommand<RoleDto> ToggleRoleStateCommand { get; }
    public RelayCommand ClearFormCommand { get; }
    public RelayCommand SearchCommand { get; }
    public RelayCommand NextPageCommand { get; }
    public RelayCommand PrevPageCommand { get; }

    private async Task LoadRolesAsync()
    {
        if (IsLoading) return;

        IsLoading = true;
        ErrorMessage = string.Empty;
        
        try
        {
            var request = new PaginatedRequest<RoleFilter>
            {
                Page = CurrentPage,
                PageSize = PageSize,
                Filter = new RoleFilter
                {
                    SearchTerm = SearchTerm,
                    IsActive = FilterIsActive
                }
            };

            var response = await _roleRepository.GetPaginatedAsync(request);
            
            if (response.IsSuccess && response.Data != null)
            {
                Roles.Clear();
                foreach (var role in response.Data.Data)
                {
                    Roles.Add(role);
                }
                TotalCount = response.Data.TotalCount;
            }
            else
            {
                ErrorMessage = response.Message ?? "خطا در بارگذاری نقش‌ها";
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = $"خطا در بارگذاری نقش‌ها: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task SaveRoleAsync()
    {
        if (IsLoading || !CanSaveRole()) 
            return;

        IsLoading = true;
        ErrorMessage = string.Empty;
        
        try
        {
            var request = new CreateRoleRequest
            {
                Name = Name,
                Description = Description,
                IsActive = IsActive
            };

            var response = await _roleRepository.CreateAsync(request);
            
            if (response.IsSuccess)
            {
                await LoadRolesAsync();
                ClearForm();
                SuccessMessage = "نقش با موفقیت ایجاد شد";
            }
            else
            {
                ErrorMessage = response.Message ?? "خطا در ایجاد نقش";
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = $"خطا در ایجاد نقش: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task UpdateRoleAsync(RoleDto? role)
    {
        if (IsLoading || role == null) return;

        IsLoading = true;
        ErrorMessage = string.Empty;
        
        try
        {
            var request = new UpdateRoleRequest
            {
                Id = role.Id,
                Name = Name,
                Description = Description,
                IsActive = IsActive
            };

            var response = await _roleRepository.UpdateAsync(request);
            
            if (response.IsSuccess)
            {
                await LoadRolesAsync();
                ClearForm();
                SuccessMessage = "نقش با موفقیت به‌روزرسانی شد";
            }
            else
            {
                ErrorMessage = response.Message ?? "خطا در به‌روزرسانی نقش";
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = $"خطا در به‌روزرسانی نقش: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task DeleteRoleAsync(RoleDto? role)
    {
        if (IsLoading || role == null) return;

        IsLoading = true;
        ErrorMessage = string.Empty;
        
        try
        {
            var response = await _roleRepository.DeleteAsync(role.Id);
            
            if (response.IsSuccess)
            {
                await LoadRolesAsync();
                SuccessMessage = "نقش با موفقیت حذف شد";
            }
            else
            {
                ErrorMessage = response.Message ?? "خطا در حذف نقش";
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = $"خطا در حذف نقش: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task ToggleRoleStateAsync(RoleDto? role)
    {
        if (IsLoading || role == null) return;

        IsLoading = true;
        ErrorMessage = string.Empty;
        
        try
        {
            var request = new ChangeRoleStateRequest
            {
                Id = role.Id,
                IsActive = !role.IsActive
            };

            var response = await _roleRepository.ChangeStateAsync(request);
            
            if (response.IsSuccess)
            {
                await LoadRolesAsync();
                SuccessMessage = role.IsActive ? "نقش غیرفعال شد" : "نقش فعال شد";
            }
            else
            {
                ErrorMessage = response.Message ?? "خطا در تغییر وضعیت نقش";
            }
        }
        catch (Exception ex)
        {
            ErrorMessage = $"خطا در تغییر وضعیت نقش: {ex.Message}";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task SearchRolesAsync()
    {
        CurrentPage = 1;
        await LoadRolesAsync();
    }

    private async Task NextPageAsync()
    {
        if (CanGoNextPage())
        {
            CurrentPage++;
            await LoadRolesAsync();
        }
    }

    private async Task PrevPageAsync()
    {
        if (CanGoPrevPage())
        {
            CurrentPage--;
            await LoadRolesAsync();
        }
    }

    private bool CanSaveRole()
    {
        return !string.IsNullOrWhiteSpace(Name) && 
               !string.IsNullOrWhiteSpace(Description);
    }

    private bool CanGoNextPage()
    {
        return CurrentPage < TotalPages;
    }

    private bool CanGoPrevPage()
    {
        return CurrentPage > 1;
    }

    private void LoadRoleForEdit(RoleDto role)
    {
        Name = role.Name;
        Description = role.Description;
        IsActive = role.IsActive;
    }

    private void ClearForm()
    {
        Name = string.Empty;
        Description = string.Empty;
        IsActive = true;
        SelectedRole = null;
    }
} 