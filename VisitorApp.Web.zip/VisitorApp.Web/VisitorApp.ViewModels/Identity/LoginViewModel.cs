using System.ComponentModel.DataAnnotations;
using VisitorApp.ViewModels.Common;
using VisitorApp.ViewModels.Common.Commands;
using VisitorApp.Models.Repositories.Identity;
using VisitorApp.Models.Identity;

namespace VisitorApp.ViewModels.Identity;

public class LoginViewModel : BaseViewModel
{
    private readonly IIdentityRepository _identityRepository;
    private string _email = string.Empty;
    private string _password = string.Empty;
    private bool _rememberMe = false;
    
    public LoginViewModel(IIdentityRepository identityRepository)
    {
        _identityRepository = identityRepository;
        LoginCommand = new RelayCommand(async () => await LoginAsync(), () => !IsLoading && IsFormValid);
    }

    [Required(ErrorMessage = "ایمیل الزامی است")]
    [EmailAddress(ErrorMessage = "فرمت ایمیل نامعتبر است")]
    public string Email
    {
        get => _email;
        set
        {
            SetProperty(ref _email, value);
            LoginCommand.NotifyCanExecuteChanged();
        }
    }

    [Required(ErrorMessage = "رمز عبور الزامی است")]
    [MinLength(6, ErrorMessage = "رمز عبور باید حداقل 6 کاراکتر باشد")]
    public string Password
    {
        get => _password;
        set
        {
            SetProperty(ref _password, value);
            LoginCommand.NotifyCanExecuteChanged();
        }
    }

    public bool RememberMe
    {
        get => _rememberMe;
        set => SetProperty(ref _rememberMe, value);
    }

    public IRelayCommand LoginCommand { get; }

    private bool IsFormValid => 
        !string.IsNullOrWhiteSpace(Email) && 
        !string.IsNullOrWhiteSpace(Password) && 
        Password.Length >= 6;

    private async Task LoginAsync()
    {
        try
        {
            IsLoading = true;
            ErrorMessage = string.Empty;

            var request = new LoginRequest
            {
                Email = Email,
                Password = Password,
                RememberMe = RememberMe
            };

            var response = await _identityRepository.LoginAsync(request);
            
            if (response.IsSuccess)
            {
                // Store login result (token, user info) - will be handled by authentication service
                // Navigation will be handled by the View
            }
            else
            {
                ErrorMessage = response.Message ?? "خطا در ورود";
            }
        }
        catch (Exception)
        {
            ErrorMessage = "خطای نامشخص در ورود";
        }
        finally
        {
            IsLoading = false;
        }
    }
    
    public bool CanLogin => !IsLoading && IsFormValid;
} 