using System.ComponentModel.DataAnnotations;
using VisitorApp.ViewModels.Common;
using VisitorApp.ViewModels.Common.Commands;
using VisitorApp.Models.Repositories.Catalog;
using VisitorApp.Models.Catalog;
using VisitorApp.Models.Common;

namespace VisitorApp.ViewModels.Catalog;

public class ProductFormViewModel : BaseViewModel
{
    private readonly IProductRepository _productRepository;
    private readonly ICategoryRepository _categoryRepository;
    
    private Guid? _id;
    private string _title = string.Empty;
    private string _description = string.Empty;
    private decimal _price = 0;
    private bool _isActive = true;
    private Guid? _categoryId;
    private List<DropdownDto> _categories = new();
    private bool _isEditMode = false;

    public ProductFormViewModel(IProductRepository productRepository, ICategoryRepository categoryRepository)
    {
        _productRepository = productRepository;
        _categoryRepository = categoryRepository;
        
        SaveCommand = new RelayCommand(async () => await SaveAsync(), () => !IsLoading && IsFormValid);
        LoadCategoriesCommand = new RelayCommand(async () => await LoadCategoriesAsync());
        CancelCommand = new RelayCommand(() => { /* Cancel logic will be handled in Razor component */ });
    }

    public Guid? Id
    {
        get => _id;
        set => SetProperty(ref _id, value);
    }

    [Required(ErrorMessage = "عنوان الزامی است")]
    [StringLength(200, ErrorMessage = "عنوان باید کمتر از 200 کاراکتر باشد")]
    public string Title
    {
        get => _title;
        set
        {
            SetProperty(ref _title, value);
            SaveCommand.NotifyCanExecuteChanged();
        }
    }

    [StringLength(1000, ErrorMessage = "توضیحات باید کمتر از 1000 کاراکتر باشد")]
    public string Description
    {
        get => _description;
        set => SetProperty(ref _description, value);
    }

    [Required(ErrorMessage = "قیمت الزامی است")]
    [Range(0.01, double.MaxValue, ErrorMessage = "قیمت باید بزرگتر از صفر باشد")]
    public decimal Price
    {
        get => _price;
        set
        {
            SetProperty(ref _price, value);
            SaveCommand.NotifyCanExecuteChanged();
        }
    }

    public bool IsActive
    {
        get => _isActive;
        set => SetProperty(ref _isActive, value);
    }

    public Guid? CategoryId
    {
        get => _categoryId;
        set => SetProperty(ref _categoryId, value);
    }

    public List<DropdownDto> Categories
    {
        get => _categories;
        set => SetProperty(ref _categories, value);
    }

    public bool IsEditMode
    {
        get => _isEditMode;
        set => SetProperty(ref _isEditMode, value);
    }

    public IRelayCommand SaveCommand { get; }
    public IRelayCommand LoadCategoriesCommand { get; }
    public IRelayCommand CancelCommand { get; }

    private bool IsFormValid => !string.IsNullOrWhiteSpace(Title) && Price > 0;

    public async Task InitializeAsync(Guid? productId = null)
    {
        await LoadCategoriesAsync();
        
        if (productId.HasValue)
        {
            IsEditMode = true;
            await LoadProductAsync(productId.Value);
        }
    }

    private async Task LoadProductAsync(Guid productId)
    {
        try
        {
            IsLoading = true;
            var response = await _productRepository.GetByIdAsync(productId);
            
            if (response.IsSuccess && response.Data != null)
            {
                var product = response.Data;
                Id = product.Id;
                Title = product.Title;
                Description = product.Description ?? string.Empty;
                Price = product.Price;
                IsActive = product.IsActive;
                CategoryId = product.CategoryId;
            }
            else
            {
                ErrorMessage = response.Message ?? "محصول یافت نشد";
            }
        }
        catch (Exception)
        {
            ErrorMessage = "خطا در بارگذاری محصول";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task LoadCategoriesAsync()
    {
        try
        {
            var response = await _categoryRepository.GetDropdownAsync();
            if (response.IsSuccess && response.Data != null)
            {
                Categories = response.Data;
            }
        }
        catch (Exception)
        {
            // Categories loading error doesn't affect form functionality
        }
    }

    private async Task SaveAsync()
    {
        try
        {
            IsLoading = true;
            ErrorMessage = string.Empty;

            if (IsEditMode && Id.HasValue)
            {
                var updateRequest = new UpdateProductRequest
                {
                    Id = Id.Value,
                    Title = Title,
                    Description = string.IsNullOrWhiteSpace(Description) ? null : Description,
                    Price = Price,
                    IsActive = IsActive,
                    CategoryId = CategoryId
                };

                var response = await _productRepository.UpdateAsync(Id.Value, updateRequest);
                if (!response.IsSuccess)
                {
                    ErrorMessage = response.Message ?? "خطا در بروزرسانی محصول";
                }
            }
            else
            {
                var createRequest = new CreateProductRequest
                {
                    Title = Title,
                    Description = string.IsNullOrWhiteSpace(Description) ? null : Description,
                    Price = Price,
                    IsActive = IsActive,
                    CategoryId = CategoryId
                };

                var response = await _productRepository.CreateAsync(createRequest);
                if (!response.IsSuccess)
                {
                    ErrorMessage = response.Message ?? "خطا در ایجاد محصول";
                }
            }
        }
        catch (Exception)
        {
            ErrorMessage = "خطا در ذخیره محصول";
        }
        finally
        {
            IsLoading = false;
        }
    }
    
    public bool CanSave => !IsLoading && IsFormValid;
} 