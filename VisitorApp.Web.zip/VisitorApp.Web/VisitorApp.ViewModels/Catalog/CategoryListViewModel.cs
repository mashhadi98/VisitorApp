using System.Collections.ObjectModel;
using VisitorApp.ViewModels.Common;
using VisitorApp.ViewModels.Common.Commands;
using VisitorApp.Models.Repositories.Catalog;
using VisitorApp.Models.Catalog;
using VisitorApp.Models.Common;

namespace VisitorApp.ViewModels.Catalog;

public class CategoryListViewModel : BaseViewModel
{
    private readonly ICategoryRepository _categoryRepository;
    private ObservableCollection<CategoryDto> _categories = new();
    private int _currentPage = 1;
    private int _totalPages = 1;
    private int _totalCount = 0;
    private int _pageSize = 10;

    public CategoryListViewModel(ICategoryRepository categoryRepository)
    {
        _categoryRepository = categoryRepository;
        
        LoadCategoriesCommand = new RelayCommand(async () => await LoadCategoriesAsync());
        DeleteCategoryCommand = new RelayCommand<Guid>(async id => await DeleteCategoryAsync(id));
        ToggleActiveCommand = new RelayCommand<CategoryDto>(async category => { if (category != null) await ToggleActiveAsync(category); });
        NextPageCommand = new RelayCommand(async () => await NextPageAsync(), () => CurrentPage < TotalPages);
        PreviousPageCommand = new RelayCommand(async () => await PreviousPageAsync(), () => CurrentPage > 1);
    }

    public ObservableCollection<CategoryDto> Categories
    {
        get => _categories;
        set => SetProperty(ref _categories, value);
    }

    public int CurrentPage
    {
        get => _currentPage;
        set
        {
            SetProperty(ref _currentPage, value);
            NextPageCommand.NotifyCanExecuteChanged();
            PreviousPageCommand.NotifyCanExecuteChanged();
        }
    }

    public int TotalPages
    {
        get => _totalPages;
        set
        {
            SetProperty(ref _totalPages, value);
            NextPageCommand.NotifyCanExecuteChanged();
            PreviousPageCommand.NotifyCanExecuteChanged();
        }
    }

    public int TotalCount
    {
        get => _totalCount;
        set => SetProperty(ref _totalCount, value);
    }

    public int PageSize
    {
        get => _pageSize;
        set => SetProperty(ref _pageSize, value);
    }

    public IRelayCommand LoadCategoriesCommand { get; }
    public IRelayCommand<Guid> DeleteCategoryCommand { get; }
    public IRelayCommand<CategoryDto> ToggleActiveCommand { get; }
    public IRelayCommand NextPageCommand { get; }
    public IRelayCommand PreviousPageCommand { get; }

    public async Task InitializeAsync()
    {
        await LoadCategoriesAsync();
    }

    private async Task LoadCategoriesAsync()
    {
        try
        {
            IsLoading = true;
            ErrorMessage = string.Empty;

            var result = await _categoryRepository.GetPaginatedAsync(
                CurrentPage, 
                PageSize);

            if (result != null)
            {
                Categories.Clear();
                foreach (var category in result.Data)
                {
                    Categories.Add(category);
                }

                TotalCount = result.TotalCount;
                TotalPages = result.TotalPages;
            }
        }
        catch (Exception)
        {
            ErrorMessage = "خطا در بارگذاری لیست دسته‌بندی‌ها";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task DeleteCategoryAsync(Guid categoryId)
    {
        try
        {
            IsLoading = true;
            ErrorMessage = string.Empty;

            var result = await _categoryRepository.DeleteAsync(categoryId);
            
            if (result?.IsSuccess == true)
            {
                await LoadCategoriesAsync();
            }
        }
        catch (Exception)
        {
            ErrorMessage = "خطا در حذف دسته‌بندی";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task ToggleActiveAsync(CategoryDto category)
    {
        try
        {
            IsLoading = true;
            ErrorMessage = string.Empty;

            var result = await _categoryRepository.ChangeStateAsync(category.Id, !category.IsActive);
            
            if (result?.IsSuccess == true)
            {
                category.IsActive = !category.IsActive;
            }
        }
        catch (Exception)
        {
            ErrorMessage = "خطا در تغییر وضعیت دسته‌بندی";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task NextPageAsync()
    {
        if (CurrentPage < TotalPages)
        {
            CurrentPage++;
            await LoadCategoriesAsync();
        }
    }

    private async Task PreviousPageAsync()
    {
        if (CurrentPage > 1)
        {
            CurrentPage--;
            await LoadCategoriesAsync();
        }
    }
} 