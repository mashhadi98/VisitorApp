using System.Collections.ObjectModel;
using VisitorApp.ViewModels.Common;
using VisitorApp.ViewModels.Common.Commands;
using VisitorApp.Models.Repositories.Catalog;
using VisitorApp.Models.Catalog;
using VisitorApp.Models.Common;

namespace VisitorApp.ViewModels.Catalog;

public class ProductListViewModel : BaseViewModel
{
    private readonly IProductRepository _productRepository;
    private readonly ICategoryRepository _categoryRepository;
    private ObservableCollection<ProductDto> _products = new();
    private int _currentPage = 1;
    private int _totalPages = 1;
    private int _totalCount = 0;
    private int _pageSize = 10;
    private List<DropdownDto> _categories = new();

    public ProductListViewModel(IProductRepository productRepository, ICategoryRepository categoryRepository)
    {
        _productRepository = productRepository;
        _categoryRepository = categoryRepository;
        
        LoadProductsCommand = new RelayCommand(async () => await LoadProductsAsync());
        DeleteProductCommand = new RelayCommand<Guid>(async id => await DeleteProductAsync(id));
        ToggleActiveCommand = new RelayCommand<ProductDto>(async product => { if (product != null) await ToggleActiveAsync(product); });
        NextPageCommand = new RelayCommand(async () => await NextPageAsync(), () => CurrentPage < TotalPages);
        PreviousPageCommand = new RelayCommand(async () => await PreviousPageAsync(), () => CurrentPage > 1);
    }

    public ObservableCollection<ProductDto> Products
    {
        get => _products;
        set => SetProperty(ref _products, value);
    }

    public List<DropdownDto> Categories
    {
        get => _categories;
        set => SetProperty(ref _categories, value);
    }

    public int CurrentPage
    {
        get => _currentPage;
        set
        {
            SetProperty(ref _currentPage, value);
            NextPageCommand.NotifyCanExecuteChanged();
            PreviousPageCommand.NotifyCanExecuteChanged();
        }
    }

    public int TotalPages
    {
        get => _totalPages;
        set
        {
            SetProperty(ref _totalPages, value);
            NextPageCommand.NotifyCanExecuteChanged();
        }
    }

    public int TotalCount
    {
        get => _totalCount;
        set => SetProperty(ref _totalCount, value);
    }

    public int PageSize
    {
        get => _pageSize;
        set => SetProperty(ref _pageSize, value);
    }

    public IRelayCommand LoadProductsCommand { get; }
    public IRelayCommand<Guid> DeleteProductCommand { get; }
    public IRelayCommand<ProductDto> ToggleActiveCommand { get; }
    public IRelayCommand NextPageCommand { get; }
    public IRelayCommand PreviousPageCommand { get; }

    public async Task InitializeAsync()
    {
        await LoadCategoriesAsync();
        await LoadProductsAsync();
    }

    private async Task LoadProductsAsync()
    {
        try
        {
            IsLoading = true;
            ErrorMessage = string.Empty;
            
            var response = await _productRepository.GetPaginatedAsync(CurrentPage, PageSize);
            
            Products.Clear();
            foreach (var product in response.Data)
            {
                Products.Add(product);
            }

            TotalPages = response.TotalPages;
            TotalCount = response.TotalCount;
            CurrentPage = response.CurrentPage;
        }
        catch (Exception)
        {
            ErrorMessage = "خطا در بارگذاری محصولات";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task LoadCategoriesAsync()
    {
        try
        {
            var response = await _categoryRepository.GetDropdownAsync();
            if (response.IsSuccess && response.Data != null)
            {
                Categories = response.Data;
            }
        }
        catch (Exception)
        {
            // Categories loading error doesn't need to be shown to user
        }
    }

    private async Task DeleteProductAsync(Guid id)
    {
        try
        {
            IsLoading = true;
            ErrorMessage = string.Empty;
            
            var response = await _productRepository.DeleteAsync(id);
            
            if (response.IsSuccess)
            {
                await LoadProductsAsync();
            }
            else
            {
                ErrorMessage = response.Message ?? "خطا در حذف محصول";
            }
        }
        catch (Exception)
        {
            ErrorMessage = "خطا در حذف محصول";
        }
        finally
        {
            IsLoading = false;
        }
    }

    private async Task ToggleActiveAsync(ProductDto product)
    {
        try
        {
            ErrorMessage = string.Empty;
            
            var response = await _productRepository.ChangeStateAsync(product.Id, !product.IsActive);
            
            if (response.IsSuccess)
            {
                product.IsActive = !product.IsActive;
            }
            else
            {
                ErrorMessage = response.Message ?? "خطا در تغییر وضعیت محصول";
            }
        }
        catch (Exception)
        {
            ErrorMessage = "خطا در تغییر وضعیت محصول";
        }
    }

    private async Task NextPageAsync()
    {
        if (CurrentPage < TotalPages)
        {
            CurrentPage++;
            await LoadProductsAsync();
        }
    }

    private async Task PreviousPageAsync()
    {
        if (CurrentPage > 1)
        {
            CurrentPage--;
            await LoadProductsAsync();
        }
    }
} 